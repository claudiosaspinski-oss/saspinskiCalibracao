/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;



public class Tratador implements ItemListener {
    
    /*Essa classe abre um painel com perguntas
     *sobre os dados da se��o de entrada.
     *O painel � diferente de acordo com o tipo
     *de se��o. Ex: se for um redondo basta
     *informar o di�metro. Se for um chato n�o
     *h� di�metro e sim largura, espessura e raio de canto.
     */
    
    InterfaceInicialRedondo janela1;
    InterfaceInicialChato janela2;
    InterfaceInicialOval janela3;
    InterfaceInicialLosango janela4;    
    
    /** Creates a new instance of Tratador */
    public Tratador() {
        
    }
        
        public void itemStateChanged(ItemEvent e){  
        
        
        if( e.getSource() == OpcoesEntrada.getRedondoEntrada()){
                
                descarteEntrada();          
                janela1 = new InterfaceInicialRedondo();             
                
            }
            
            else if ( e.getSource() == OpcoesEntrada.getChatoEntrada()){                              
                
                descarteEntrada(); 
                janela2 = new InterfaceInicialChato();           
                  
            }
            
            else if ( e.getSource() == OpcoesEntrada.getOvalEntrada()){                
                
                descarteEntrada(); 
                janela3 = new InterfaceInicialOval();          
                 
            }
            
            else if ( e.getSource() == OpcoesEntrada.getLosangoEntrada()) {                
                
                descarteEntrada(); 
                janela4 = new InterfaceInicialLosango();       
                
       }
        
  }
    
    public void descarteEntrada(){         
          
          
          if ( janela1 != null )  
              Main.getJanelaBasica().removeComponent(janela1.getCaixa());
          
          if ( janela2 != null )       
            //janelaBasica.remove(caixas[0]);
              Main.getJanelaBasica().removeComponent(janela2.getCaixa());
          
          if ( janela3 != null )  
            //janelaBasica.remove(caixas[6]);
              Main.getJanelaBasica().removeComponent(janela3.getCaixa());
          
          if ( janela4 != null ) 
            ///janelaBasica.remove(caixas[7]);
              Main.getJanelaBasica().removeComponent(janela4.getCaixa()); 
             
          
    }
    
}