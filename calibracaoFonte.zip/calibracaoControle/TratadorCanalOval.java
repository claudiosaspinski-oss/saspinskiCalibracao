/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;
import calibracaoModelo.*;

public class TratadorCanalOval implements ActionListener {
    
    /*Essa classe armazena os dados introduzidos
     *para o canal oval e abre um novo painel,
     *onde ser� perguntado ao usu�rio as demais
     *informa��es necess�rias para o c�lculo do
     *alargamento e esfor�os do passe.     
     */
    
    private static double  profundidadeCanalOval, larguraCanalOval;
    
    private static Canal canal;    
    private static DadosFisicosPasse escolha1;
    
    /** Creates a new instance of TratadorCanalOval */
    public TratadorCanalOval() {
    }
    
     public void actionPerformed ( ActionEvent e ){
        
        try {
            
        
               profundidadeCanalOval = Double.parseDouble(TratadorEscolhaPasse.getJanela13().getProfundidadeCanalOvalText());
               larguraCanalOval = Double.parseDouble(TratadorEscolhaPasse.getJanela13().getLarguraCanalOvalText());            
               
               canal = new CanalOval ( larguraCanalOval, profundidadeCanalOval );
               
           if ( escolha1 == null && TratadorCanalRedondo.getEscolha() == null 
                && TratadorCanalCaixa.getEscolha() == null && TratadorCanalLosango.getEscolha() == null)    
           escolha1 = new DadosFisicosPasse(); 
           
        }
        
       catch ( NumberFormatException numberFormatException ) {
               
               JOptionPane.showMessageDialog(null,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
           }
            
            
        }
     
     public static Canal getCanal(){
        
        return canal;
        
    }
     
     public static DadosFisicosPasse getEscolha(){
        
        return escolha1;
    }
    
}