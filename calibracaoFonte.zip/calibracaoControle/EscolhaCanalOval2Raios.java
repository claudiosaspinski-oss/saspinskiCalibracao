package calibracaoControle;

/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;


public class EscolhaCanalOval2Raios {
    
    /*Essa classe � um painel com perguntas sobre
     *os par�metros necess�rios para definir um canal
     *oval.
     */
    
    private JLabel profundidadeCanalOvalLabel, larguraCanalOvalLabel, larguraFundoCanalOvalLabel, segundoRaioCanalOvalLabel;  
    private JTextField profundidadeCanalOvalField, larguraCanalOvalField, larguraFundoCanalOvalField, segundoRaioCanalOvalField;  
    private JPanel panel10;
    private JButton ok7;
    
    private static TratadorCanalOval2Raios tratadorCanalOval2Raios;
    
    private static Box caixa;    
    
    
    /** Creates a new instance of EscolhaCanalOval */
    public EscolhaCanalOval2Raios() {
        
        try{
        
        Main.tipoCanal = 5;
      
        panel10 = new JPanel();
        panel10.setLayout ( new GridLayout( 4 , 2 ));
        
        profundidadeCanalOvalLabel = new JLabel( " profundidadeCanalOval (mm) ");
        panel10.add (profundidadeCanalOvalLabel);
        profundidadeCanalOvalField = new JTextField(          );
        panel10.add (profundidadeCanalOvalField); 
        
        larguraCanalOvalLabel = new JLabel( " larguraCanalOval (mm) ");
        panel10.add (larguraCanalOvalLabel);
        larguraCanalOvalField = new JTextField(          );
        panel10.add (larguraCanalOvalField);
        
        larguraFundoCanalOvalLabel = new JLabel( " larguraFundoCanalOval (mm) ");
        panel10.add (larguraFundoCanalOvalLabel);
        larguraFundoCanalOvalField = new JTextField(          );
        panel10.add (larguraFundoCanalOvalField);
        
        segundoRaioCanalOvalLabel = new JLabel( " segundoRaioCanalOval (mm) ");
        panel10.add (segundoRaioCanalOvalLabel);
        segundoRaioCanalOvalField = new JTextField(          );
        panel10.add (segundoRaioCanalOvalField);
        
        ok7 = new JButton ( "OK" );
      
        tratadorCanalOval2Raios = new TratadorCanalOval2Raios();        
        ok7.addActionListener ( tratadorCanalOval2Raios );       
        
        caixa = Box.createVerticalBox();
        caixa.add (panel10);
        caixa.add (ok7);
        
        Main.getJanelaBasica().addComponent ( caixa, 3, 0, 2, 1, 1, 1 );
        
        }
        
         catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em EscolhaCanalOval() ","Erro em EscolhaCanalOval.java",JOptionPane.ERROR_MESSAGE);
            
        }
    }
    
    public String getProfundidadeCanalOvalText(){
        
        return profundidadeCanalOvalField.getText();
    }
    
    public String getLarguraCanalOvalText(){
        
        return larguraCanalOvalField.getText();
    }  
    
     public String getLarguraFundoCanalOvalText(){
        
        return larguraFundoCanalOvalField.getText();
    } 
     
     public String getSegundoRaioCanalOvalText(){
        
        return segundoRaioCanalOvalField.getText();
    } 
     
     public static Box getCaixa(){
        
        return caixa;
    }
     
     public static TratadorCanalOval2Raios getTratadorCanalOval2Raios(){
        
        return tratadorCanalOval2Raios;
    }
     
     public static int getTipoCanal(){
        
        return Main.tipoCanal;
    }
    
    
}