/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.*;
import calibracaoModelo.*;

public class TratadorCanalOval2Raios implements ActionListener {
    
    /*Essa classe armazena os dados introduzidos
     *para o canal oval e abre um novo painel,
     *onde ser� perguntado ao usu�rio as demais
     *informa��es necess�rias para o c�lculo do
     *alargamento e esfor�os do passe.     
     */
    
    private static double  profundidadeCanalOval, larguraCanalOval, larguraFundoCanalOval, segundoRaioCanalOval;
    private static double  raioFundo, diametro, anguloSaida, minRaio, maxRaio, aux2;
    private static Canal canal;    
    private static DadosFisicosPasse escolha1;
    
    /** Creates a new instance of TratadorCanalOval */
    public TratadorCanalOval2Raios() {
    }
    
     public void actionPerformed ( ActionEvent e ){
        
        try {
            
        
               profundidadeCanalOval = Double.parseDouble(TratadorEscolhaPasse.getJanela15().getProfundidadeCanalOvalText());
               larguraCanalOval = Double.parseDouble(TratadorEscolhaPasse.getJanela15().getLarguraCanalOvalText());
               larguraFundoCanalOval = Double.parseDouble(TratadorEscolhaPasse.getJanela15().getLarguraFundoCanalOvalText());
               segundoRaioCanalOval = Double.parseDouble(TratadorEscolhaPasse.getJanela15().getSegundoRaioCanalOvalText());
               
               checkSegundoRaio();
               calculoDiametro();
               calculoAnguloSaida();
               
               
               
               canal = new CanalRedondo ( diametro, profundidadeCanalOval, anguloSaida, segundoRaioCanalOval );
               
           if ( escolha1 == null && TratadorCanalRedondo.getEscolha() == null 
                && TratadorCanalCaixa.getEscolha() == null && TratadorCanalLosango.getEscolha() == null &&
                TratadorCanalOval.getEscolha() == null)    
           escolha1 = new DadosFisicosPasse(); 
           
        }
        
       catch ( NumberFormatException numberFormatException ) {
               
               JOptionPane.showMessageDialog(null,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
           }
            
            
        }
     
     public static Canal getCanal(){
        
        return canal;
        
    }
     
     public static DadosFisicosPasse getEscolha(){
        
        return escolha1;
    }    
     
     public static void calculoDiametro(){
         
         try{            
         
         int i=0;
         for ( raioFundo = larguraFundoCanalOval / 2; raioFundo < 10000; raioFundo+=0.01 ){
         double aux1 = larguraCanalOval / 2 - ( raioFundo - segundoRaioCanalOval ) * larguraFundoCanalOval / 2 / raioFundo;
         aux2 = Math.sqrt( 1 - Math.pow(( larguraFundoCanalOval / 2 / raioFundo) , 2 ));
         double aux3 = raioFundo - profundidadeCanalOval - ( raioFundo - segundoRaioCanalOval ) * aux2;
         double aux4 = aux1*aux1 + aux3*aux3 - segundoRaioCanalOval * segundoRaioCanalOval;
         if ( Math.abs( aux4 ) < 1 )
             break;
         }
         if ( raioFundo < 9999 && (raioFundo - segundoRaioCanalOval) * aux2 < raioFundo - profundidadeCanalOval){
            diametro = 2 * raioFundo;
            JOptionPane.showMessageDialog ( null, (int)raioFundo, "raio de fundo do oval", JOptionPane.INFORMATION_MESSAGE );
         }
         else
            i = 1/0;
     }
     
     catch ( Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Aumente o segundoRaio", "Raio de fundo muito grande", JOptionPane.ERROR_MESSAGE );
            
        }
     
     }
     
     public static void calculoAnguloSaida(){
         
         anguloSaida = Math.acos( larguraFundoCanalOval / 2 / raioFundo);
         anguloSaida = anguloSaida * 180 / Math.PI;
     }
     
     public static void checkSegundoRaio(){
         
         try{
             
         int flag = 0;
         //maxRaio = Math.pow(profundidadeCanalOval , 2) + Math.pow((larguraCanalOval/2) , 2) / 2 / profundidadeCanalOval;
         //maxRaio = (int) maxRaio;
         minRaio = 2.0 / 3 * ( larguraCanalOval - larguraFundoCanalOval );
         minRaio = (int) minRaio;
         maxRaio = (int) 6 * minRaio;
         
         if((segundoRaioCanalOval < minRaio) || (segundoRaioCanalOval > maxRaio)){
             flag = 1/0;
         }
         }
         
         catch (Exception exception){
             
             JOptionPane.showMessageDialog ( null, "min="+minRaio+" max="+maxRaio, "Intervalo para o segundo raio", JOptionPane.ERROR_MESSAGE );
         }
         
         
     }
    
}