/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;
import calibracaoModelo.*;

public class TratadorEntradaOval implements ActionListener{
    
    /*Essa classe armazena o valor das vari�veis
     *introduzidas para o caso da se��o ser um oval
     *e abre um novo painel, perguntando sobre
     *qual � o tipo do passe onde essa se��o 
     *ir� ser laminada
     */
    
    private static double larguraOval, espessuraOval, raioFundoOval, raioLuzOval; 
    private static PerfilOval perfilEntrada;
    private static EscolhaPasse escolha;
    
    /** Creates a new instance of TratadorEntradaOval */
    public TratadorEntradaOval() {
    }
    
     public void actionPerformed ( ActionEvent e ){
           
           try {
           larguraOval = Double.parseDouble(InterfaceInicialOval.getLarguraOvalText());
           espessuraOval = Double.parseDouble(InterfaceInicialOval.getEspessuraOvalText());
           raioFundoOval = Double.parseDouble(InterfaceInicialOval.getRaioFundoOvalText());
           raioLuzOval = Double.parseDouble(InterfaceInicialOval.getRaioLuzOvalText());
           
           perfilEntrada = new PerfilOval ( espessuraOval, larguraOval, raioFundoOval, raioLuzOval );          
           
         if ( escolha == null && TratadorEntradaChato.getEscolha() == null && TratadorEntradaRedondo.getEscolha() == null && 
                   TratadorEntradaLosango.getEscolha() == null )                          
           
                  
           escolha = new EscolhaPasse();
           
           }
           
           catch ( NumberFormatException numberFormatException ) {
               
               JOptionPane.showMessageDialog(escolha,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
           }
           
       } 
     
      public static double getLargura(){
        
        return larguraOval;
    }
    
    public static double getEspessura(){
        
        return espessuraOval;
    }
    
    public static double getRaioFundo(){
        
        return raioFundoOval;
    }
    
    public static double getRaioLuz(){
        
        return raioLuzOval;
    }
    
    public static Perfil getPerfilEntrada(){
        
        return perfilEntrada;
    }
    public static EscolhaPasse getEscolha(){
        
        return escolha;
        
    }
    
    
}