/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JApplet { 
   
    /*Essa classe inicia o applet, perguntando ao usu�rio
     *se o trem laminador � cont�nuo ou aberto. A resposta
     *� dada numa JRadioBox.     
     */
    
    public static int tipoCanal;
    public static int tipoPerfil;    
    private TratadorInicial tratador0;   
    private Container container;  
    private static JRadioButton tremContinuo, tremAberto;
    private ButtonGroup producaoGroup;    
    private JPanel panel2,panel3;    
    private static JanelaBasica janelaBasica;
    private JLabel titulo1;
    private JTextField[] disclaimer;  
    private Border border;
    
    /** Creates a new instance of Main */
    public Main() { 
        
        container = getContentPane();
        container.setLayout (new FlowLayout());
        
        panel2 = new JPanel();
        titulo1 = new JLabel (" Escolha o tipo de laminador: " ); 
        
        tremContinuo = new JRadioButton ("Trem cont�nuo ", false );
        panel2.add (tremContinuo);
        tremAberto = new JRadioButton ("Trem aberto ", false );
        panel2.add (tremAberto);
        
        
        tratador0 = new TratadorInicial();
        tremContinuo.addItemListener ( tratador0 );
        tremAberto.addItemListener ( tratador0 );
        
        producaoGroup = new ButtonGroup();
        producaoGroup.add (tremContinuo);
        producaoGroup.add (tremAberto);
        
        container.add(titulo1);
        container.add(panel2);
        
        disclaimer = new JTextField [17];
        panel3 = new JPanel();
        panel3.setLayout(new GridLayout(17,1));
        border = BorderFactory.createEmptyBorder();
        
        
        for (int i = 0;i<17;i++){
            disclaimer[i] = new JTextField();
            disclaimer[i].setEditable(false);
            disclaimer[i].setBorder(border);
            disclaimer[i].setText(copyright(i));
            panel3.add(disclaimer[i]);
        }
        container.add(panel3);     
        
        
        
        try{
        janelaBasica = new JanelaBasica();
        janelaBasica.setLocation(10, 10);
        
        
        }
        
        catch (java.security.AccessControlException exception){
            JOptionPane.showMessageDialog ( null, "Erro em init()", "Erro em Main.java", JOptionPane.ERROR_MESSAGE );
            
        }
    }   
    
    public static JanelaBasica getJanelaBasica(){
        
        return janelaBasica;
    }   
     
    
    public static JRadioButton getTremAberto(){
        
        return tremAberto;
    }
    
    public static JRadioButton getTremContinuo(){
        
        return tremContinuo;
    }
    
    public String copyright(int i){
    
        if (i==0 || i==1 || i==2 || i==3 || i==5 || i==10)
                return 
                "";        
        if (i==4)
                return 
                "Copyright 2007 Jose C. Bandeira R. Cardoso";         
        else if (i==6)
                return
                "This program is free software: you can redistribute it and/or modify";         
        else if (i==7)
                return       
                "it under the terms of the GNU General Public License as published by"; 
        else if (i==8)
                return
                "the Free Software Foundation, either version 3 of the License, or"; 
        else if (i==9)
                return        
                "(at your option) any later version.";         
        else if (i==11)
                return
                "This program is distributed in the hope that it will be useful,"; 
        else if (i==12)
                return
                "but WITHOUT ANY WARRANTY; without even the implied warranty of"; 
        else if (i==13)
                return
                "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"; 
        else if (i==14)
                return
                 "GNU General Public License for more details"; 
        else if (i==15)
                return
                "You should have received a copy of the GNU General Public License"; 
        else 
                return
                "along with this program.  If not, see <http://www.gnu.org/licenses/>.";                                                                   
    
    }
}