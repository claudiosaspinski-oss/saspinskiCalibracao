/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;


public class OpcoesEntrada extends JPanel{
    
    /*Essa classe � um painel com um JRadioButtom,
     *onde o usu�rio deve escolher se a se��o de entrada
     *� um chato (ou quadrado), redondo, oval ou los�ngo.
     */
    
    private JPanel panel1;
    private JLabel titulo, titulo2;
    private static JRadioButton redondoEntrada, chatoEntrada, ovalEntrada, losangoEntrada;
    private ButtonGroup radioGroup;
    private Box caixa;
    Tratador tratador1;
    
    
    
    /** Creates a new instance of OpcoesEntrada */
    public OpcoesEntrada() {   
        
        try{            
        
        panel1 = new JPanel();
        panel1.setLayout(new FlowLayout());       
        
        titulo2 = new JLabel (" Escolha o tipo de se��o de entrada " ); 
        titulo = new JLabel ( "        " );      
       
        redondoEntrada = new JRadioButton ("redondo", false);
        panel1.add (redondoEntrada); 
        chatoEntrada = new JRadioButton ("chato", false );
        panel1.add (chatoEntrada);              
        ovalEntrada = new JRadioButton ("oval", false);
        panel1.add (ovalEntrada);
        losangoEntrada = new JRadioButton ("losango", false);
        panel1.add (losangoEntrada);
        
        if ( tratador1 == null )
        tratador1 = new Tratador ();   
        
        redondoEntrada.addItemListener ( tratador1 );
        chatoEntrada.addItemListener ( tratador1 );
        ovalEntrada.addItemListener ( tratador1 );
        losangoEntrada.addItemListener ( tratador1 );        
        
        radioGroup = new ButtonGroup();
        radioGroup.add ( redondoEntrada );
        radioGroup.add ( chatoEntrada );        
        radioGroup.add ( ovalEntrada );
        radioGroup.add ( losangoEntrada );       
        
        caixa = Box.createVerticalBox();      
       
        caixa.add(titulo2);        
        caixa.add(panel1);    
        
        Main.getJanelaBasica().addComponent ( caixa , 0, 0, 1, 1, 1, 1 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em OpcoesEntrada() ","Erro em OpcoesEntrada.java",JOptionPane.ERROR_MESSAGE);
           
        }
          
    }
    
    public static JRadioButton getRedondoEntrada(){
        
        return redondoEntrada;
    }
    
    public static JRadioButton getChatoEntrada(){
        
        return chatoEntrada;
    }
    
    public static JRadioButton getOvalEntrada(){
        
        return ovalEntrada;
    }
    
    public static JRadioButton getLosangoEntrada(){
        
        return losangoEntrada;
    }
    
}