/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;


public class EscolhaCanalRedondo {
    
    /*Essa classe � um painel com perguntas sobre
     *os par�metros necess�rios para definir um canal
     *redondo.
     */
    
    private JLabel diametroCanalLabel, anguloSaidaLabel, profundidadeRedondoLabel, raioSaidaLabel;   
    private JTextField diametroCanalField, anguloSaidaField, profundidadeRedondoField, raioSaidaField; 
    private JPanel panel9;
    private JButton ok6;
    
    private static TratadorCanalRedondo tratadorCanalRedondo;
    
    private static Box caixa;    
    
    
    /** Creates a new instance of EscolhaCanalRedondo */
    public EscolhaCanalRedondo() {
        
        try{
       
        Main.tipoCanal = 2;
        panel9 = new JPanel();
        panel9.setLayout ( new GridLayout( 4 , 2 ));
        
        diametroCanalLabel = new JLabel( " diametroCanal (mm) ");
        panel9.add (diametroCanalLabel);
        diametroCanalField = new JTextField(          );
        panel9.add (diametroCanalField); 
        
        anguloSaidaLabel = new JLabel( " anguloSaida (mm) ");
        panel9.add (anguloSaidaLabel);
        anguloSaidaField = new JTextField(          );
        panel9.add (anguloSaidaField); 
        
        profundidadeRedondoLabel = new JLabel( " profundidadeRedondo (mm) ");
        panel9.add (profundidadeRedondoLabel);
        profundidadeRedondoField = new JTextField(          );
        panel9.add (profundidadeRedondoField);
        
        raioSaidaLabel = new JLabel( " raioSaida(mm) ");
        panel9.add (raioSaidaLabel);
        raioSaidaField = new JTextField(          );
        panel9.add (raioSaidaField);
        
        ok6 = new JButton ( "OK" );
      
        tratadorCanalRedondo = new TratadorCanalRedondo();
        ok6.addActionListener ( tratadorCanalRedondo );       
        
        caixa = Box.createVerticalBox();
        caixa.add (panel9);
        caixa.add (ok6);
        Main.getJanelaBasica().addComponent ( caixa, 3, 0, 2, 1, 1, 1 );
        
        }
        
         catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em EscolhaCanalRedondo() ","Erro em EscolhaCanalRedondo.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public String getDiametroCanalText(){
        
        return diametroCanalField.getText();
    }
    
    public String getAnguloSaidaText(){
        
        return anguloSaidaField.getText();
    }
    
    
    public String getProfundidadeRedondoText(){
        
        return profundidadeRedondoField.getText();
    }
    
    public String getRaioSaidaText(){
        
        return raioSaidaField.getText();
    }    
    
     public static Box getCaixa(){
        
        return caixa;
    }
     
     public static TratadorCanalRedondo getTratadorCanalRedondo(){
        
        return tratadorCanalRedondo;
    }
     
     public static int getTipoCanal(){
        
        return Main.tipoCanal;
    }
    

}