/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import java.awt.event.*;

 public class TratadorInicial implements ItemListener{
    
     /*Essa classe armazena as informa��es sobre o tipo de trem
      *laminador (cont�nuo ou aberto) e abre um painel com 
      *perguntas sobre a se��o de entrada.
      */
     
    private static boolean opcaoTremAberto;
    private static OpcoesEntrada opcoesEntrada;
    
    
    public void itemStateChanged(ItemEvent e){  
        
        
        if (e.getSource() == Main.getTremAberto()){
            opcaoTremAberto = true;
            if (opcoesEntrada == null)
            opcoesEntrada = new OpcoesEntrada();     
        }        
        
        if (e.getSource() == Main.getTremContinuo()){            
            opcaoTremAberto = false;
            if (opcoesEntrada == null)
            opcoesEntrada = new OpcoesEntrada();               
            
        }        
    } 
    
    public static boolean getOpcaoTremAberto(){
        
        return opcaoTremAberto;
    }
  }