/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;


public class EscolhaCanalLosango {
    
    /*Essa classe � um painel com perguntas sobre
     *os par�metros necess�rios para definir um canal
     *los�ngo.
     */
    
    private JLabel anguloCanalLosangoLabel, profundidadeCanalLosangoLabel, raioCanalLosangoLabel;   
    private JTextField anguloCanalLosangoField, profundidadeCanalLosangoField, raioCanalLosangoField;   
    private JPanel panel11;
    private JButton ok8;    
    
    private static TratadorCanalLosango tratadorCanalLosango;
    
    private static Box caixa;
    
    
    
    /** Creates a new instance of EscolhaCanalLosango */
    public EscolhaCanalLosango() {
        
        try{
        
        Main.tipoCanal = 4;
        
        panel11 = new JPanel();
        panel11.setLayout ( new GridLayout( 4 , 2 ));
        
        anguloCanalLosangoLabel = new JLabel( " �ngulo do canal los�ngo (mm) ");
        panel11.add (anguloCanalLosangoLabel);
        anguloCanalLosangoField = new JTextField(          );
        panel11.add (anguloCanalLosangoField); 
        
        profundidadeCanalLosangoLabel = new JLabel( " Profundidade do canal los�ngo (mm) ");
        panel11.add (profundidadeCanalLosangoLabel);
        profundidadeCanalLosangoField = new JTextField(          );
        panel11.add (profundidadeCanalLosangoField); 
        
        raioCanalLosangoLabel = new JLabel( " Raio do canal losango (mm) ");
        panel11.add (raioCanalLosangoLabel);
        raioCanalLosangoField = new JTextField(          );
        panel11.add (raioCanalLosangoField);       
        
        ok8 = new JButton ( "OK" );
       
        tratadorCanalLosango = new TratadorCanalLosango();       
        ok8.addActionListener ( tratadorCanalLosango );
        
        caixa = Box.createVerticalBox();
        caixa.add (panel11);
        caixa.add (ok8);
        Main.getJanelaBasica().addComponent ( caixa, 3, 0, 2, 1, 1, 1 );
        
        }
        
         catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em EscolhaCanalLosango() ","Erro em EscolhaCanalLosango.java",JOptionPane.ERROR_MESSAGE);
            
        }
    }
    
    public String getAnguloCanalLosangoText(){
        
        return anguloCanalLosangoField.getText();
    }
    
    public String getProfundidadeCanalLosangoText(){
        
        return profundidadeCanalLosangoField.getText();
    }
    
    
    public String getRaioCanalLosangoText(){
        
        return raioCanalLosangoField.getText();
    }  
    
     public static Box getCaixa(){
        
        return caixa;
    }
     
     public static TratadorCanalLosango getTratadorCanalLosango(){
        
        return tratadorCanalLosango;
    }
     
     public static int getTipoCanal(){
        
        return Main.tipoCanal;
    }
     
   
    
}