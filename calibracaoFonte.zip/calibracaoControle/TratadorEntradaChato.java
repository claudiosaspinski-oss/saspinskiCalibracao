/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;
import calibracaoModelo.*;

public class TratadorEntradaChato implements ActionListener {    
    
    /*Essa classe armazena o valor das vari�veis
     *introduzidas para o caso da se��o ser um chato
     *e abre um novo painel, perguntando sobre
     *qual � o tipo do passe onde essa se��o 
     *ir� ser laminada
     */
    
    private static double largura, espessura, raio; 
    private static PerfilChato perfilEntrada;
    private static EscolhaPasse escolha;
    
    /** Creates a new instance of TratadorEntradaChato */
    public TratadorEntradaChato() {
    }
    
    public void actionPerformed ( ActionEvent e ){
           
           try {
           largura = Double.parseDouble(InterfaceInicialChato.getLarguraChatoText());
           espessura = Double.parseDouble(InterfaceInicialChato.getEspessuraChatoText());
           raio = Double.parseDouble(InterfaceInicialChato.getRaioChatoText());
           
           perfilEntrada = new PerfilChato ( largura, espessura, raio );
           
           if  ( escolha == null && TratadorEntradaLosango.getEscolha() == null && TratadorEntradaRedondo.getEscolha() == null && 
                   TratadorEntradaOval.getEscolha() == null )                    
                  
           escolha = new EscolhaPasse();                  
           }
           
           catch ( NumberFormatException numberFormatException ) {
               
               JOptionPane.showMessageDialog(escolha,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
           }
           
       }   
    
    public static double getLargura(){
        
        return largura;
    }
    
    public static double getEspessura(){
        
        return espessura;
    }
    
    public static double getRaio(){
        
        return raio;
    }
    
    public static Perfil getPerfilEntrada(){
        
        return perfilEntrada;
    }
    
    public static EscolhaPasse getEscolha(){
        
        return escolha;
        
    }
    
}