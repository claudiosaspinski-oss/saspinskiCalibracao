/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;



public class DadosFisicosPasse extends JPanel{
    
    /*Essa classe � um painel onde se pergunta ao usu�rio
     *sobre o tipo de material, de cilindro, a temperatura do material,
     *a luz entre os cilindros, em suma tudo de relevante para os
     *c�lculos da deforma��o e esfor�os no passe.     
     */
    
    private TratadorDadosFisicosPasse tratadorDadosFisicosPasse1;    
    private JPanel panel12;
    private JLabel diametroCilindroLabel, temperaturaLabel, rotacaoCilindroLabel, producaoHorariaLabel,
            tipoCilindroLabel, carbonoEquivalenteLabel, rotacaoPerfilEntradaLabel,
            metodoAlargamentoLabel, metodoEsforcosLabel, luzLabel, fatorAlargamentoLabel;
    private static JTextField  diametroCilindroField, temperaturaField, rotacaoCilindroField, producaoHorariaField,
            tipoCilindroField, carbonoEquivalenteField, rotacaoPerfilEntradaField,
            metodoAlargamentoField, metodoEsforcosField, luzField, fatorAlargamentoField; 
    private String tipoCilindro$ [], carbonoEquivalente$ [], rotacaoPerfilEntrada$ [], metodoAlargamento$ [], metodoEsforcos$ [];
    private static JComboBox tipoCilindroBox, rotacaoPerfilEntradaBox, carbonoEquivalenteBox, metodoAlargamentoBox, metodoEsforcosBox;
    private JButton ok9;
    private Box caixa;
    
    /** Creates a new instance of DadosFisicosPasse */
    public DadosFisicosPasse() {        
               
        try{
            
        
        panel12 = new JPanel();
        panel12.setLayout ( new GridLayout( 11 , 1 ));
        
        entraDiametroCilindro();
        entraTemperatura();    
        
        if ( TratadorInicial.getOpcaoTremAberto()){           
            
            rotacaoCilindroLabel = new JLabel( " Rotacao do cilindro (RPM) ");
            panel12.add (rotacaoCilindroLabel);
            rotacaoCilindroField = new JTextField(          );
            panel12.add (rotacaoCilindroField);
           
        }
        
        else {            
           
            producaoHorariaLabel = new JLabel( " ProducaoHoraria (t/h) ");
            panel12.add (producaoHorariaLabel);
            producaoHorariaField = new JTextField(          );
            panel12.add (producaoHorariaField);     
            
        }
        
        entraTipoCilindro();
        entraCarbonoEquivalente();
        entraRotacaoPerfilEntrada();
        entraMetodoAlargamento();
        entraMetodoEsforcos();
        entraLuz();  
        entraFatorAlargamento();           
        
        ok9 = new JButton ( "OK" );        
        ok9.addActionListener ( tratadorDadosFisicosPasse1 );
        
        caixa = Box.createVerticalBox();
        caixa.add(panel12);
        caixa.add(ok9);
        
        Main.getJanelaBasica().addComponent( caixa, 0, 1, 1, 3, 1, 1 ); 
        
        }
        
        catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro em DadosFisicosPasse()", "Erro em DadosFisicosPasse.java", JOptionPane.ERROR_MESSAGE );
            
        }   
        
        
        
    }
    
    public void entraDiametroCilindro(){
        
        diametroCilindroLabel = new JLabel( " DiametroCilindro (mm) ");
        panel12.add (diametroCilindroLabel);
        diametroCilindroField = new JTextField("");
        panel12.add (diametroCilindroField); 
    }
    
    public void entraTemperatura(){
        
        temperaturaLabel = new JLabel( " Temperatura (C) ");
        panel12.add (temperaturaLabel);
        temperaturaField = new JTextField("");
        panel12.add (temperaturaField); 
        
    }    
  
    
    public void entraTipoCilindro(){
        
        tipoCilindroLabel = new JLabel( " Material do Cilindro ");
        panel12.add (tipoCilindroLabel);
        tipoCilindro$  = new String [3];
        tipoCilindro$[0] = "Ferro fundido nodular";
        tipoCilindro$[1] = "A�o";
        tipoCilindro$[2] = "Ferro fundido cinzento";
        tipoCilindroBox = new JComboBox( tipoCilindro$ );
        tipoCilindroBox.setMaximumRowCount(3);
        tratadorDadosFisicosPasse1 = new TratadorDadosFisicosPasse();
        tipoCilindroBox.addItemListener(tratadorDadosFisicosPasse1);        
        panel12.add (tipoCilindroBox);
    }
    
    public void entraCarbonoEquivalente(){
        
        carbonoEquivalenteLabel = new JLabel( " Carbono equivalente do a�o ");
        panel12.add (carbonoEquivalenteLabel);
        carbonoEquivalente$  = new String [3];
        carbonoEquivalente$[0] = "Baixo carbono";
        carbonoEquivalente$[1] = "M�dio carbono";
        carbonoEquivalente$[2] = "Alto carbono";
        carbonoEquivalenteBox = new JComboBox( carbonoEquivalente$ );
        carbonoEquivalenteBox.setMaximumRowCount(3);        
        carbonoEquivalenteBox.addItemListener(tratadorDadosFisicosPasse1);        
        panel12.add (carbonoEquivalenteBox);     
    }
    
    public void entraRotacaoPerfilEntrada(){
        
        rotacaoPerfilEntradaLabel = new JLabel( " Rotacao do Perfil de entrada ");
        panel12.add (rotacaoPerfilEntradaLabel);
        rotacaoPerfilEntrada$  = new String [3];
        rotacaoPerfilEntrada$[0] = "0 grau";
        rotacaoPerfilEntrada$[1] = "45 graus";
        rotacaoPerfilEntrada$[2] = "90 graus";
        rotacaoPerfilEntradaBox = new JComboBox( rotacaoPerfilEntrada$ );
        rotacaoPerfilEntradaBox.setMaximumRowCount(3);        
        rotacaoPerfilEntradaBox.addItemListener(tratadorDadosFisicosPasse1);                
        panel12.add (rotacaoPerfilEntradaBox);
        
    }
    
    public void entraMetodoAlargamento(){
        
        metodoAlargamentoLabel = new JLabel( " M�todo de c�lculo do alargamento ");
        panel12.add (metodoAlargamentoLabel);
        metodoAlargamento$  = new String [6];
        metodoAlargamento$[0] = "EKELUND";
        metodoAlargamento$[1] = "GEUZE";
        metodoAlargamento$[2] = "SIEBEL";
        metodoAlargamento$[3] = "SEDLACZEK";
        metodoAlargamento$[4] = "HILL";
        metodoAlargamento$[5] = "LUGAR";
        metodoAlargamentoBox = new JComboBox( metodoAlargamento$ );
        metodoAlargamentoBox.setMaximumRowCount(3);
        metodoAlargamentoBox.addItemListener(tratadorDadosFisicosPasse1);                
        panel12.add (metodoAlargamentoBox);   
        
    }
    
    public void entraMetodoEsforcos(){
        
        metodoEsforcosLabel = new JLabel( " M�todo de c�lculo dos esfor�os ");
        panel12.add (metodoEsforcosLabel);
        metodoEsforcos$  = new String [4];
        metodoEsforcos$[0] = "EKELUND";
        metodoEsforcos$[1] = "MAUK";
        metodoEsforcos$[2] = "TSELIKOV";
        metodoEsforcos$[3] = "MISAKA";        
        metodoEsforcosBox = new JComboBox( metodoEsforcos$ );
        metodoEsforcosBox.setMaximumRowCount(4);
        metodoEsforcosBox.addItemListener(tratadorDadosFisicosPasse1);                
        panel12.add (metodoEsforcosBox);  
        
    }
    
    public void entraLuz(){
        
        luzLabel = new JLabel( " Luz (mm) ");
        panel12.add (luzLabel);
        luzField = new JTextField("");
        panel12.add (luzField);  
        
    }
    
    public void entraFatorAlargamento(){
        
        fatorAlargamentoLabel = new JLabel( " Fator de alargamento ");
        panel12.add (fatorAlargamentoLabel);
        fatorAlargamentoField = new JTextField("");
        panel12.add (fatorAlargamentoField);   
        
    }
    
     public static String getDiametroCilindroText(){
        
        return diametroCilindroField.getText();
    }
    
    public static String  getTemperaturaText(){
        
        return temperaturaField.getText();
    }
    
    public static String getRotacaoCilindroText(){
        
        return rotacaoCilindroField.getText();
    }
    
    public static String getProducaoHorariaText(){
        
        return producaoHorariaField.getText();
    }
    
    public static String getFatorAlargamentoText(){
        
        return fatorAlargamentoField.getText();
    }   
    
    public static String getLuzFieldText(){
        
        return luzField.getText();  
   
    }
    
    public static JComboBox getTipoCilindroBox(){
       
       return tipoCilindroBox;
       
   }
   
   public static JComboBox getRotacaoPerfilEntradaBox(){
       
       return rotacaoPerfilEntradaBox;
       
   }
   
   public static JComboBox getCarbonoEquivalenteBox(){
       
       return carbonoEquivalenteBox;
       
   }
   
   public static JComboBox getMetodoAlargamentoBox(){
       
       return metodoAlargamentoBox;
       
   }
   
   public static JComboBox getMetodoEsforcosBox(){
       
       return metodoEsforcosBox;
       
   }
    
}