/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;



public class EscolhaCanalCaixa extends JPanel{
    
    /*Essa classe � um painel com perguntas sobre
     *os par�metros necess�rios para definir um canal
     *caixa.
     */
    
    private JLabel larguraFundoLabel, larguraBaseLabel, profundidadeCaixaLabel, raioCaixaLabel;
    private JTextField larguraFundoCaixaField, larguraBaseCaixaField, profundidadeCaixaField, raioCaixaField;
    private JPanel panel8;
    private JButton ok5;   
    
    private static TratadorCanalCaixa tratadorCanalCaixa;
    
    private static Box caixa;
    
    private static int tipoCanal;
    
    /** Creates a new instance of EscolhaCanalCaixa */
    public EscolhaCanalCaixa() {
        
        try{
     
        Main.tipoCanal = 1;
        
        panel8 = new JPanel();
        panel8.setLayout ( new GridLayout( 4 , 2 ));
        
        larguraFundoLabel = new JLabel( " largura fundo (mm) ");
        panel8.add (larguraFundoLabel);
        larguraFundoCaixaField = new JTextField(          );
        panel8.add (larguraFundoCaixaField); 
        
        larguraBaseLabel = new JLabel( " largura Base (mm) ");
        panel8.add (larguraBaseLabel);
        larguraBaseCaixaField = new JTextField(          );
        panel8.add (larguraBaseCaixaField); 
        
        profundidadeCaixaLabel = new JLabel( " profundidade (mm) ");
        panel8.add (profundidadeCaixaLabel);
        profundidadeCaixaField = new JTextField(          );
        panel8.add (profundidadeCaixaField);
        
        raioCaixaLabel = new JLabel( " raio(mm) ");
        panel8.add (raioCaixaLabel);
        raioCaixaField = new JTextField(          );
        panel8.add (raioCaixaField);
        
        ok5 = new JButton ( "OK" );
        
        tratadorCanalCaixa = new TratadorCanalCaixa();
        ok5.addActionListener ( tratadorCanalCaixa );
        
        caixa = Box.createVerticalBox();
        caixa.add (panel8);
        caixa.add (ok5);
        Main.getJanelaBasica().addComponent ( caixa, 3, 0, 2, 1, 1, 1 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em EscolhaCanalCaixa() ","Erro em EscolhaCanalCaixa.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public String getLarguraFundoCaixaText(){
        
        return larguraFundoCaixaField.getText();
    }
    
    public String getLarguraBaseCaixaText(){
        
        return larguraBaseCaixaField.getText();
    }
    
    
    public String getProfundidadeCaixaText(){
        
        return profundidadeCaixaField.getText();
    }
    
    public String getRaioCaixaText(){
        
        return raioCaixaField.getText();
    }   
    
    public static Box getCaixa(){
        
        return caixa;
    }
    
    public static TratadorCanalCaixa getTratadorCanalCaixa(){
        
        return tratadorCanalCaixa;
    }
    
    public static int getTipoCanal(){        
        
        return tipoCanal;
    }
}