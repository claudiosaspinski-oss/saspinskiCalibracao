/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;


public class InterfaceInicialOval extends JPanel{
    
    /*Essa classe � um painel com perguntas sobre 
     *os dados das se��o de entrada no caso dessa
     *ser um oval. 
     */
    
    private JPanel panel5;
    private JLabel larguraOvalLabel, espessuraOvalLabel, raioFundoOvalLabel, raioLuzOvalLabel;
    private static JTextField larguraOvalField, espessuraOvalField, raioFundoOvalField, raioLuzOvalField;
    private JButton ok3;
    
    private static TratadorEntradaOval tratadorEntradaOval;
    
    private static Box caixa;
    
    /** Creates a new instance of InterfaceInicialOval */
    public InterfaceInicialOval() {
        
        try{
        
        Main.tipoPerfil = 3;
        
        panel5 = new JPanel();
        panel5.setLayout ( new GridLayout( 4 , 2 ));
        
        larguraOvalLabel = new JLabel( " largura (mm) ");
        panel5.add (larguraOvalLabel);
        larguraOvalField = new JTextField(          );
        panel5.add (larguraOvalField); 
        
        espessuraOvalLabel = new JLabel( " espessura(mm) ");
        panel5.add (espessuraOvalLabel);
        espessuraOvalField = new JTextField(          );
        panel5.add (espessuraOvalField);
        
        raioFundoOvalLabel = new JLabel( " raioFundo(mm) ");
        panel5.add (raioFundoOvalLabel);
        raioFundoOvalField = new JTextField(          );
        panel5.add (raioFundoOvalField);   
        
        raioLuzOvalLabel = new JLabel( " raioLuz(mm) ");
        panel5.add (raioLuzOvalLabel);
        raioLuzOvalField = new JTextField(          );
        panel5.add (raioLuzOvalField); 
        
        ok3 = new JButton ( "OK" );        
        tratadorEntradaOval = new TratadorEntradaOval();
        ok3.addActionListener(tratadorEntradaOval);        
        
        caixa = Box.createVerticalBox();
        
        caixa.add (panel5);
        caixa.add (ok3);   
        Main.getJanelaBasica().addComponent ( caixa, 1, 0, 1, 1, 1, 1 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em InterfaceInicialOval() ","Erro em InterfaceInicialOval.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public static String getLarguraOvalText(){
        
        return larguraOvalField.getText(); 
    }
    
    public static String getEspessuraOvalText(){
        
        return espessuraOvalField.getText(); 
    }
    
    public static String getRaioFundoOvalText(){
        
        return raioFundoOvalField.getText(); 
    }
    
    public static String getRaioLuzOvalText(){
        
        return raioLuzOvalField.getText(); 
    }
    
    public static Box getCaixa(){
         
         return caixa;
     }
    
    public static TratadorEntradaOval getTratador(){
        
        return tratadorEntradaOval;
    }
    
    
}