/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;


public class InterfaceInicialRedondo extends JPanel{
    
    /*Essa classe � um painel com perguntas sobre 
     *os dados das se��o de entrada no caso dessa
     *ser um redondo.
     */
    
    private JPanel panel4;
    private JLabel diametroLabel;
    private static JTextField diametroField;
    private JButton ok2;
    
    private static TratadorEntradaRedondo tratadorEntradaRedondo;
    
    private static Box caixa;
    
    private JanelaBasica janelaBasica;
    
    /** Creates a new instance of InterfaceInicialRedondo */
    public InterfaceInicialRedondo() {
        
        try{
        
        Main.tipoPerfil = 1;
        
        panel4 = new JPanel();
        panel4.setLayout ( new GridLayout( 1 , 2 ));
        
        diametroLabel = new JLabel( " diametro (mm) ");
        panel4.add (diametroLabel);
        diametroField = new JTextField(          );
        panel4.add (diametroField); 
        
        ok2 = new JButton ( "OK" );
       
        tratadorEntradaRedondo = new TratadorEntradaRedondo();
        ok2.addActionListener(tratadorEntradaRedondo);      
        
        caixa = Box.createVerticalBox();
        
        caixa.add (panel4);
        caixa.add (ok2);   
        Main.getJanelaBasica().addComponent ( caixa, 1, 0, 1, 1, 1, 1 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em InterfaceInicialRedondo() ","Erro em InterfaceInicialRedondo.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
     public static String getDiametroText(){
        
        return diametroField.getText(); 
    }
     
     public static Box getCaixa(){
         
         return caixa;
     }
     
     public static TratadorEntradaRedondo getTratador(){
        
        return tratadorEntradaRedondo;
    }
    
}