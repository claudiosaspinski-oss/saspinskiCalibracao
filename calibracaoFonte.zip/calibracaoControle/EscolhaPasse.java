/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;



public class EscolhaPasse extends JPanel{
    
    /*Essa classe � um painel com um 
     *JRadioButtom, onde o usu�rio deve
     *escolher o tipo de canal do passe.
     *Pode ser caixa, oval, redondo ou
     *los�ngo.  
     */
    
    private JPanel panel7;
    private JLabel titulo;
    private static JRadioButton caixa, redondo, oval, oval2Raios, losango;
    private TratadorEscolhaPasse tratadorEscolhaPasse;
    private ButtonGroup radioGroup;
    private static Box caixas;
    
    /** Creates a new instance of EscolhaPasse */
    public EscolhaPasse() {     
        
        try{
        
        panel7 = new JPanel();
        
        titulo = new JLabel (" Escolha o tipo de canal do passe 1 " ); 
        titulo.setAlignmentX(CENTER_ALIGNMENT);
        caixa = new JRadioButton ("caixa", false );
        panel7.add (caixa);
        redondo = new JRadioButton ("redondo", false);
        panel7.add (redondo);       
        oval = new JRadioButton ("oval", false);
        panel7.add (oval);
        oval2Raios = new JRadioButton ("oval 2 raios", false);
        panel7.add (oval2Raios);        
        losango = new JRadioButton ("losango", false);
        panel7.add (losango);       
       
        tratadorEscolhaPasse = new TratadorEscolhaPasse ();
        
        caixa.addItemListener ( tratadorEscolhaPasse );
        redondo.addItemListener ( tratadorEscolhaPasse );
        oval.addItemListener ( tratadorEscolhaPasse );
        oval2Raios.addItemListener ( tratadorEscolhaPasse );
        losango.addItemListener ( tratadorEscolhaPasse );
        
        radioGroup = new ButtonGroup();
        radioGroup.add ( caixa );
        radioGroup.add ( redondo );
        radioGroup.add ( oval );
        radioGroup.add ( oval2Raios );
        radioGroup.add ( losango );        
        
        caixas = Box.createVerticalBox();
        caixas.add(titulo);       
        caixas.add(panel7);
        
        Main.getJanelaBasica().addComponent ( caixas, 2, 0, 1, 1, 1, 1 );
        
        }
        
         catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em EscolhaPasse() ","Erro em EscolhaPasse.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public static JRadioButton getCaixa(){
        
        return caixa;
    }
    
    public static JRadioButton getRedondo(){
        
        return redondo;
    }
    
    public static JRadioButton getOval(){
        
        return oval;
    }
    
    public static JRadioButton getOval2Raios(){
        
        return oval2Raios;
    }
    
    public static JRadioButton getLosango(){
        
        return losango;
    }
    
    public static Box getCaixas(){
        
        return caixas;
    }
    
    
}