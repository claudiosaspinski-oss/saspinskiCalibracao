/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;


public class InterfaceInicialChato extends JPanel {
    
    /*Essa classe � um painel com perguntas sobre 
     *os dados das se��o de entrada no caso dessa
     *ser um chato (ou quadrado que � um chato com
     *a largura = espessura). 
     */
    
    private JPanel panel3;
    private JLabel larguraChatoLabel, espessuraChatoLabel, raioLabel;
    private static JTextField larguraChatoField, espessuraChatoField, raioChatoField;
    private JButton ok1;
    
    private static TratadorEntradaChato tratadorEntradaChato;
    
    private static Box caixa;
    
    /** Creates a new instance of InterfaceInicialChato */
    public InterfaceInicialChato() {
        
        try{
            
        
        Main.tipoPerfil = 2;
        
        panel3 = new JPanel();
        panel3.setLayout ( new GridLayout( 3 , 2 ));
        
        larguraChatoLabel = new JLabel( " largura (mm) ");
        panel3.add (larguraChatoLabel);
        larguraChatoField = new JTextField(          );
        panel3.add (larguraChatoField); 
        
        espessuraChatoLabel = new JLabel( " espessura(mm) ");
        panel3.add (espessuraChatoLabel);
        espessuraChatoField = new JTextField(          );
        panel3.add (espessuraChatoField);
        
        raioLabel = new JLabel( " raio(mm) ");
        panel3.add (raioLabel);
        raioChatoField = new JTextField(          );
        panel3.add (raioChatoField);       
        
        ok1 = new JButton ( "OK" );
      
        tratadorEntradaChato = new TratadorEntradaChato();
        ok1.addActionListener(tratadorEntradaChato);
       
        caixa = Box.createVerticalBox();
        
        caixa.add (panel3);
        caixa.add (ok1);   
        
        Main.getJanelaBasica().addComponent ( caixa, 1, 0, 1, 1, 1, 1 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em InterfaceInicialChato() ","Erro em InterfaceInicialChato.java",JOptionPane.ERROR_MESSAGE);
           
        }
       
    }
    
    public static String getLarguraChatoText(){
        
        return larguraChatoField.getText(); 
    }
    
    public static String getEspessuraChatoText(){
        
        return espessuraChatoField.getText(); 
    }
    
    public static String getRaioChatoText(){
        
        return raioChatoField.getText(); 
    }
    
    public static Box getCaixa(){
         
         return caixa;
     }
    
    public static TratadorEntradaChato getTratador(){
        
        return tratadorEntradaChato;
    }
    
}