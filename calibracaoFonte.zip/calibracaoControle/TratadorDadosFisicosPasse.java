/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;
import calibracaoVisual.*;
import calibracaoModelo.*;


public class TratadorDadosFisicosPasse implements ItemListener, ActionListener{
   
   /*Essa classe armazena os dados introduzidos anteriomente
    *para o passe em quest�o e aciona o modelo de c�lculo
    *(package calibracaoModelo). Com os resultados fornecidos
    *pelo modelo ele manda abrir uma janela mostrando os resultados.
    *Para isso � usado o package calibracaoVisual.    
     */
    
   private final int ACO = 1, FOFON = 2, FOFOC = 3;
   private final int baixoCarbono = 1, medioCarbono = 2, altoCarbono = 3;
   private final int ALARGAMENTOEKELUND = 0, ALARGAMENTOGEUZE = 1, ALARGAMENTOSIEBEL = 2, ALARGAMENTOSEDLACZEK = 3, 
           ALARGAMENTOHILL = 4, ALARGAMENTOLUGAR = 5;
   private final int ESFORCOSEKELUND = 0, ESFORCOSMAUK = 1, ESFORCOSTSELIKOV = 2, ESFORCOSMISAKA = 3;
    
   private int tipoCilindro = 2, metodoAlargamento, metodoEsforcos;
   private double rotacaoPerfilEntrada, carbono = 0.1, manganes = 0.6, cromo;
   private double diametroCilindro, temperatura, rotacaoCilindro, producaoHoraria, fatorAlargamento; 
   private static double luz;
   private static Material material1;
   private static Entrada entrada1;
   private static Passe passe1;
   private static Esforcos esforcos1;
   private static RotacaoPerfil rotacao1;
   private static DadosSaida saida;
   private static Canal canal;
   
    
    /** Creates a new instance of TratadorDadosFisicosPasse */
    public TratadorDadosFisicosPasse() {       
        
    }
    
    public void itemStateChanged(ItemEvent e1){
        
        if(e1.getStateChange() == ItemEvent.SELECTED){               
                   
                    tipoCilindro();
                    rotacaoEntrada();
                    carbonoEquivalente();
                    metodoAlargamento();
                    metodoEsforcos();
               
        }
    }
        
    
    public void actionPerformed ( ActionEvent e2 ){
        
        try {       
                
          
           diametroCilindro = Double.parseDouble(DadosFisicosPasse.getDiametroCilindroText());
           temperatura = Double.parseDouble(DadosFisicosPasse.getTemperaturaText());
            
           if (TratadorInicial.getOpcaoTremAberto())
               rotacaoCilindro = Double.parseDouble(DadosFisicosPasse.getRotacaoCilindroText());
           else
               producaoHoraria = Double.parseDouble(DadosFisicosPasse.getProducaoHorariaText());          
           
           luz = Double.parseDouble(DadosFisicosPasse.getLuzFieldText());
           fatorAlargamento = Double.parseDouble(DadosFisicosPasse.getFatorAlargamentoText());     
       // }
        
       // catch ( NumberFormatException numberFormatException ) {
               
       //        JOptionPane.showMessageDialog(this.saida,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
       //   }
        
       // try{
           
           material1 = new Material( temperatura, diametroCilindro, tipoCilindro, carbono, manganes, cromo);
          
           rotacao1 = new RotacaoPerfil ( getPerfilEntrada(), rotacaoPerfilEntrada );
           
           entrada1 = new Entrada ( rotacao1, getCanal(), material1, luz );
           
           passe1 = new Passe ( entrada1, material1, metodoAlargamento, producaoHoraria, rotacaoCilindro, fatorAlargamento );
          
           esforcos1 = new Esforcos ( entrada1, passe1, material1, metodoEsforcos );   
           
                  
                   
           saida = new DadosSaida();
          
           saida.setLocation(20,20);
           
        }
        
        catch ( NumberFormatException numberFormatException ) {
               
               JOptionPane.showMessageDialog(this.saida,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
           }
        
        catch ( NullPointerException exception ) {
               
               JOptionPane.showMessageDialog(this.saida," Canal ou perfil n�o definidos ","Erro em TratadorDadosFisicosPasse.java",JOptionPane.ERROR_MESSAGE);
           }  
        
        catch ( ArithmeticException arithmeticException ) {
               
               JOptionPane.showMessageDialog(this.saida,"Altura do perfil de entrada pequena para o canal","N�o h� redu��o",JOptionPane.ERROR_MESSAGE);
           }
           
    }
    
    public void tipoCilindro(){
        
               if ( DadosFisicosPasse.getTipoCilindroBox().getSelectedIndex() == 0 )
                   tipoCilindro = FOFON;
               
               if ( DadosFisicosPasse.getTipoCilindroBox().getSelectedIndex() == 1 )
                   tipoCilindro = ACO;
               
               if ( DadosFisicosPasse.getTipoCilindroBox().getSelectedIndex() == 2 )
                   tipoCilindro = FOFOC;  
        
    }
    
    public void rotacaoEntrada(){
        
               if ( DadosFisicosPasse.getRotacaoPerfilEntradaBox().getSelectedIndex() == 0 )
                   rotacaoPerfilEntrada = 0;
               
               if ( DadosFisicosPasse.getRotacaoPerfilEntradaBox().getSelectedIndex() == 1 )
                   rotacaoPerfilEntrada = 45;
               
               if ( DadosFisicosPasse.getRotacaoPerfilEntradaBox().getSelectedIndex() == 2 )
                   rotacaoPerfilEntrada = 90;   
        
    }
    
    public void carbonoEquivalente(){
        
               if ( DadosFisicosPasse.getCarbonoEquivalenteBox().getSelectedIndex() == 0 ){
                   
                   carbono = 0.1; manganes = 0.6; cromo = 0;
                   
               }
               
               if ( DadosFisicosPasse.getCarbonoEquivalenteBox().getSelectedIndex() == 1 ){
                   
                   carbono = 0.3; manganes = 1.0; cromo = 0;
                   
               }
               
               if ( DadosFisicosPasse.getCarbonoEquivalenteBox().getSelectedIndex() == 2 ){
                   
                   carbono = 0.5; manganes = 1.4; cromo = 0.5;
                   
               }                   
        
    }
    
    public void metodoAlargamento(){
    
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 0 )
                   metodoAlargamento = ALARGAMENTOEKELUND;
               
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 1 )
                   metodoAlargamento = ALARGAMENTOGEUZE;
        
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 2 )
                   metodoAlargamento = ALARGAMENTOSIEBEL;
        
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 3 )
                   metodoAlargamento = ALARGAMENTOSEDLACZEK;
        
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 4 )
                   metodoAlargamento = ALARGAMENTOHILL;
        
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 5 )
                   metodoAlargamento = ALARGAMENTOLUGAR;  
    }
    
    public void metodoEsforcos(){
        
               if ( DadosFisicosPasse.getMetodoAlargamentoBox().getSelectedIndex() == 5 )
                   metodoAlargamento = ALARGAMENTOLUGAR;  
               
               if ( DadosFisicosPasse.getMetodoEsforcosBox().getSelectedIndex() == 0 )
                   metodoEsforcos = ESFORCOSEKELUND;
               
               if ( DadosFisicosPasse.getMetodoEsforcosBox().getSelectedIndex() == 1 )
                   metodoEsforcos = ESFORCOSMAUK;
        
               if ( DadosFisicosPasse.getMetodoEsforcosBox().getSelectedIndex() == 2 )
                   metodoEsforcos = ESFORCOSTSELIKOV;
        
               if ( DadosFisicosPasse.getMetodoEsforcosBox().getSelectedIndex() == 3 )
                   metodoEsforcos = ESFORCOSMISAKA;   
    }
    
    public static Material getMaterial(){
        
        return material1;
    }
    
    public static Entrada getEntrada(){
        
        return entrada1;
    }
    
    public static Passe getPasse(){
        
        return passe1;
    }
    
    public static RotacaoPerfil getRotacao(){
        
        return rotacao1;
    }
    
    public static Esforcos getEsforcos(){
        
        return esforcos1;
    }
    
    public static double getLuz(){
        
        return luz;
        
    }
    
    public static Canal getCanal(){
        
        if ( Main.tipoCanal  == 1 && TratadorCanalCaixa.getCanal() != null )         
            return TratadorCanalCaixa.getCanal();          
        
        else if ( Main.tipoCanal == 2 && TratadorCanalRedondo.getCanal() != null )
            return TratadorCanalRedondo.getCanal(); 
        
        else if ( Main.tipoCanal == 3 && TratadorCanalOval.getCanal() != null )
            return TratadorCanalOval.getCanal(); 
        
        else if (Main.tipoCanal == 4 && TratadorCanalLosango.getCanal() != null ) 
            return TratadorCanalLosango.getCanal(); 
        
        else 
            return TratadorCanalOval2Raios.getCanal(); 
        
    }
    
    public static Perfil getPerfilEntrada(){
        
        if ( Main.tipoPerfil  == 1 && TratadorEntradaRedondo.getPerfilEntrada() != null )         
            return TratadorEntradaRedondo.getPerfilEntrada();          
        
        else if ( Main.tipoPerfil == 2 && TratadorEntradaChato.getPerfilEntrada() != null )
            return TratadorEntradaChato.getPerfilEntrada();  
        
        else if ( Main.tipoPerfil == 3 && TratadorEntradaOval.getPerfilEntrada() != null )
            return TratadorEntradaOval.getPerfilEntrada();  
        
        else  
            return TratadorEntradaLosango.getPerfilEntrada();  
    }
           
}