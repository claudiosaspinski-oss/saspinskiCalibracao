/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;




public class TratadorEscolhaPasse implements ItemListener{
    
    /*Essa classe, em fun��o da escolha do 
     *usu�rio sobre o tipo de canal do passe,
     *manda abrir um painel com perguntas
     *sobre a geometria desse canal.
     */ 
    
    private static EscolhaCanalCaixa janela11;
    private static EscolhaCanalRedondo janela12;
    private static EscolhaCanalOval janela13;
    private static EscolhaCanalOval2Raios janela15;
    private static EscolhaCanalLosango janela14;
    
    /** Creates a new instance of TratadorEscolhaPasse */
    public TratadorEscolhaPasse() {
    }
    
    public void itemStateChanged(ItemEvent e){     
        
       
            if( e.getSource() == EscolhaPasse.getCaixa()){
                
                descarte();                       
                janela11 = new EscolhaCanalCaixa();          
               //janelaTeste = new Planilha();
            }
            
            else if ( e.getSource() == EscolhaPasse.getRedondo() ){                              
                
                descarte();
                janela12 = new EscolhaCanalRedondo(); 
                
                  
            }
            
            else if ( e.getSource() == EscolhaPasse.getOval() ){                
                
               descarte(); 
                janela13 = new EscolhaCanalOval();          
                
            }
            
            else if ( e.getSource() == EscolhaPasse.getOval2Raios() ){                
                
               descarte(); 
                janela15 = new EscolhaCanalOval2Raios();          
                
            }
            
            else if ( e.getSource() == EscolhaPasse.getLosango() ) {                
                
                descarte();  
                janela14 = new EscolhaCanalLosango();                       
                
       }  
           
            }
    
     public void descarte(){         
                               
          if ( janela11 != null ){
              
              Main.getJanelaBasica().removeComponent(EscolhaCanalCaixa.getCaixa());             
              
          }
              
          
          if ( janela12 != null ){ 
              
              Main.getJanelaBasica().removeComponent(EscolhaCanalRedondo.getCaixa());       
             
          }
             
          
          if ( janela13 != null ){
              
              Main.getJanelaBasica().removeComponent(EscolhaCanalOval.getCaixa());             
            
          }
             
          
          if ( janela14 != null ){  
              
              Main.getJanelaBasica().removeComponent(EscolhaCanalLosango.getCaixa());            
             
          }        
          
          if ( janela15 != null ){  
              
              Main.getJanelaBasica().removeComponent(EscolhaCanalOval2Raios.getCaixa());            
             
          }      
       
      }
     
     public static EscolhaCanalCaixa getJanela11(){
         
         return janela11;
     }
    
     public static EscolhaCanalRedondo getJanela12(){
         
         return janela12;
     }
     
     public static EscolhaCanalOval getJanela13(){
         
         return janela13;
     }
     
     public static EscolhaCanalOval2Raios getJanela15(){
         
         return janela15;
     }
     
     public static EscolhaCanalLosango getJanela14(){
         
         return janela14;
     }
}
