/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;


public class JanelaBasica extends JFrame{
    
    /*Essa classe cria a janela, com a defini��o de layout
     *onde todos os dados ser�o introduzidos.
     */
    
    private GridBagLayout layout;
    private GridBagConstraints especificacoes;
    
    /** Creates a new instance of JanelaBasica */
    public JanelaBasica() {
        
        layout = new GridBagLayout();    
        setLayout ( layout );
        especificacoes = new GridBagConstraints();
        setSize ( 800, 600 );        
        
    }
    
    public void addComponent ( Component component, int linha, int coluna, int largura, int altura, int folgaH, int folgaV ){
        
        especificacoes.gridx = coluna;
        especificacoes.gridy = linha;        
        especificacoes.gridwidth = largura;
        especificacoes.gridheight = altura;
        especificacoes.weightx = folgaH;
        especificacoes.weighty = folgaV;
        
        layout.setConstraints ( component, especificacoes );
        
        add ( component ); 
        setVisible(true);
        
    }
   
   public void removeComponent(Component component){
       
       remove(component);              
       setVisible(false);
       
   }

}