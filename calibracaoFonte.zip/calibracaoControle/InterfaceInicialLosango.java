/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.*;


public class InterfaceInicialLosango extends JPanel{
    
    /*Essa classe � um painel com perguntas sobre 
     *os dados das se��o de entrada no caso dessa
     *ser um los�ngo. 
     */
    
    private JPanel panel6;
    private JLabel larguraLosangoLabel, espessuraLosangoLabel, raioFundoLosangoLabel, raioLuzLosangoLabel, anguloLosangoLabel;
    private static JTextField larguraLosangoField, espessuraLosangoField, raioFundoLosangoField, raioLuzLosangoField, anguloLosangoField; 
    private JButton ok4;
    
    private static TratadorEntradaLosango tratadorEntradaLosango;
    
    private static Box caixa;
    
    /** Creates a new instance of InterfaceInicialLosango */
    public InterfaceInicialLosango() {
        
        try{
        
        Main.tipoPerfil = 4;
        
        panel6 = new JPanel();
        panel6.setLayout ( new GridLayout( 5 , 2 ));
        
        larguraLosangoLabel = new JLabel( " largura (mm) ");
        panel6.add (larguraLosangoLabel);
        larguraLosangoField = new JTextField(          );
        panel6.add (larguraLosangoField); 
        
        espessuraLosangoLabel = new JLabel( " espessura(mm) ");
        panel6.add (espessuraLosangoLabel);
        espessuraLosangoField = new JTextField(          );
        panel6.add (espessuraLosangoField);
        
        raioFundoLosangoLabel = new JLabel( " raioFundo(mm) ");
        panel6.add (raioFundoLosangoLabel);
        raioFundoLosangoField = new JTextField(          );
        panel6.add (raioFundoLosangoField);   
        
        raioLuzLosangoLabel = new JLabel( " raioLuz(mm) ");
        panel6.add (raioLuzLosangoLabel);
        raioLuzLosangoField = new JTextField(          );
        panel6.add (raioLuzLosangoField);   
        
        anguloLosangoLabel = new JLabel( " angulo(graus) ");
        panel6.add (anguloLosangoLabel);
        anguloLosangoField = new JTextField(          );
        panel6.add (anguloLosangoField);  
        
        ok4 = new JButton ( "OK" );       
        tratadorEntradaLosango = new TratadorEntradaLosango();
        ok4.addActionListener(tratadorEntradaLosango);        
        
        caixa = Box.createVerticalBox();
        
        caixa.add (panel6);
        caixa.add (ok4);   
        Main.getJanelaBasica().addComponent ( caixa, 1, 0, 1, 1, 1, 1 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em InterfaceInicialLosango() ","Erro em InterfaceInicialLosango.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public static String getLarguraLosangoText(){
        
        return larguraLosangoField.getText(); 
    }
    
    public static String getEspessuraLosangoText(){
        
        return espessuraLosangoField.getText(); 
    }
    
    public static String getRaioFundoLosangoText(){
        
        return raioFundoLosangoField.getText(); 
    }
    
    public static String getRaioLuzLosangoText(){
        
        return raioLuzLosangoField.getText(); 
    }
    
    public static String getAnguloLosangoText(){
        
        return anguloLosangoField.getText(); 
    }
    
    public static Box getCaixa(){
         
         return caixa;
     }
    
    public static TratadorEntradaLosango getTratador(){
        
        return tratadorEntradaLosango;
    }
    
    
    
}