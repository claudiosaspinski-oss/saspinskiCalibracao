/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoControle;

import javax.swing.*;
import java.awt.event.*;
import calibracaoModelo.*;

public class TratadorEntradaLosango implements ActionListener{
    
    /*Essa classe armazena o valor das vari�veis
     *introduzidas para o caso da se��o ser um los�ngo
     *e abre um novo painel, perguntando sobre
     *qual � o tipo do passe onde essa se��o 
     *ir� ser laminada
     */
    
    private static double larguraLosango, espessuraLosango, raioFundoLosango, raioLuzLosango, anguloLosango; 
    private static PerfilLosango perfilEntrada;
    private static EscolhaPasse escolha;
    
    /** Creates a new instance of TratadorEntradaLosango */
    public TratadorEntradaLosango() {
    }
    
    public void actionPerformed ( ActionEvent e ){
           
           try {
           larguraLosango = Double.parseDouble(InterfaceInicialLosango.getLarguraLosangoText());
           espessuraLosango = Double.parseDouble(InterfaceInicialLosango.getEspessuraLosangoText());
           raioFundoLosango = Double.parseDouble(InterfaceInicialLosango.getRaioFundoLosangoText());
           raioLuzLosango = Double.parseDouble(InterfaceInicialLosango.getRaioLuzLosangoText());
           anguloLosango = Double.parseDouble(InterfaceInicialLosango.getAnguloLosangoText());
           
           perfilEntrada = new PerfilLosango ( espessuraLosango, larguraLosango, anguloLosango, raioFundoLosango, raioLuzLosango ); 
           
           
           if  ( escolha == null && TratadorEntradaChato.getEscolha() == null && TratadorEntradaRedondo.getEscolha() == null && 
                   TratadorEntradaOval.getEscolha() == null )                
            
           
               escolha = new EscolhaPasse();
           }
           
           
           catch ( NumberFormatException numberFormatException ) {
               
               JOptionPane.showMessageDialog(escolha,"use ponto como separador decimal","Preencha todos os campos",JOptionPane.ERROR_MESSAGE);
           }          
           
       }
    
     public static double getLargura(){
        
        return larguraLosango;
    }
    
    public static double getEspessura(){
        
        return espessuraLosango;
    }
    
    public static double getRaioFundo(){
        
        return raioFundoLosango;
    }
    
    public static double getRaioLuz(){
        
        return raioLuzLosango;
    }
    
    public static double getAngulo(){
        
        return anguloLosango;
    }
    
    public static Perfil getPerfilEntrada(){
        
        return perfilEntrada;
    }
    
    public static EscolhaPasse getEscolha(){
        
        return escolha;
        
    }
    
}