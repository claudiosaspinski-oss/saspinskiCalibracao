/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilChato extends Perfil{
    
    /*Essa classe herda de Perfil e fornece m�todos como 
     *valorDeY e valorDeTeta espec�ficos para um chato
     *como se��o de entrada.   
     */
    
    double largura, altura, raio, xCentroM, yCentroM, xCentrom;
    double termoX2, termoX, termoIndependente;
    Equacao2Grau equacao3;
    
    /** Creates a new instance of PerfilChato */
    
    
    public PerfilChato( double larg , double alt , double r ) {        
        
        largura = larg;
        altura = alt;
        raio = r;
        x0y0 = new double [32];
        termoX2 = 1;
        termoX = -2*raio;
        termoIndependente = altura * altura / 4;
        equacao3 = new Equacao2Grau(termoX2,termoX, termoIndependente);                 
        xCentroM = largura / 2 - raio;
        yCentroM = altura / 2 - raio;
        xCentrom = - xCentroM;
        if ( raio < altura / 2)
            tipo = CHATO;
        else
            tipo = CHATOMOLA;
        xInicio = largura / 2;
        yInicio = 0;
           
    }
    
    public double area(){
        
        if(tipo == CHATO)
            return largura*altura - (4 - Math.PI) * raio*raio;
        else{
            double teta1 = Math.acos(altura / ( 2 * raio));
            //double teta2 = Math.PI - teta1;
            double teta2 = Math.PI / 2;
            double b = raio * (1 - Math.sin(teta1));
            Redondo boleadoHorizontal = new Redondo ( 2 * raio , teta1 , teta2 , 0);
            double areaBoleada = boleadoHorizontal.area();
            double areaInterna = 2 * raio * Math.sin ( teta1 ) * altura;
            return (largura - 2 * b) * altura + 2*areaBoleada + 0*areaInterna;
        }
            
        
    }
    
    public double[] pontos(){
        
                     
           x0y0[0] = xInicio;
           if ( tipo == CHATO )
               x0y0[1] = altura / 2 - raio;
           else
               x0y0[1] = 0;               
           
           if ( tipo == CHATO )
               x0y0[2] = xCentroM;
           else
               x0y0[2] = largura / 2 - equacao3.raizMenor();
           x0y0[3] = altura / 2;
           
           x0y0[4] = -x0y0[2];
           x0y0[5] = x0y0[3];
           
           x0y0[6] = -x0y0[0];
           x0y0[7] = x0y0[1];
           
           x0y0[8] = x0y0[6];
           x0y0[9] = -x0y0[7];
           
           x0y0[10] = x0y0[4];
           x0y0[11] = -x0y0[5];
           
           x0y0[12] = x0y0[2];
           x0y0[13] = x0y0[11];
           
           x0y0[14] = x0y0[0];
           x0y0[15] = -x0y0[1];
           
           return x0y0;
        
    }
    
    public double valorDeYPos(double x){ 
        
        
        if ( x < pontos()[0] && x >= pontos()[2] && tipo == CHATO)          
            return altura / 2 - raio + Math.sqrt(raio*raio - (x-xCentroM)*(x-xCentroM));
        else if ( x < pontos()[0] && x >= pontos()[2] && tipo == CHATOMOLA )
            return Math.sqrt(raio*raio - (x-xCentroM)*(x-xCentroM));
        
        else if ( x < pontos()[2] && x >= pontos()[4] )
            return altura / 2;
        
        else if ( x < pontos()[4] && x > pontos() [6] && tipo == CHATO )
            return altura / 2 - raio + Math.sqrt(raio*raio - (x-xCentrom)*(x-xCentrom)); 
        else if ( x < pontos()[4] && x > pontos() [6] && tipo == CHATOMOLA )
            return Math.sqrt(raio*raio - (x-xCentrom)*(x-xCentrom)); 
        
        else return 0;
    }
    
    public double valorDeYNeg(double x){       
       
        
        if ( x < pontos()[0] && x >= pontos()[2] && tipo == CHATO )           
            return -(altura / 2 - raio + Math.sqrt(raio*raio - (x-xCentroM)*(x-xCentroM)));
        else if ( x < pontos()[0] && x >= pontos()[2] && tipo == CHATOMOLA )
            return -Math.sqrt(raio*raio - (x-xCentroM)*(x-xCentroM));
        
        else if ( x < pontos()[2] && x >= pontos()[4] )
            return -(altura / 2);
        
        else if ( x < pontos()[4] && x > pontos()[6] && tipo == CHATO )
            return -(altura / 2 - raio + Math.sqrt(raio*raio - (x-xCentrom)*(x-xCentrom)));
        else if ( x < pontos()[4] && x > pontos()[6] && tipo == CHATOMOLA)
            return -Math.sqrt(raio*raio - (x-xCentrom)*(x-xCentrom));
        
        else return 0;
    }
    
    public double valorDeR (double teta) {
        
        if ( Math.tan ( teta ) > -pontos()[1] / pontos()[0] && Math.tan ( teta ) < pontos()[1] / pontos()[0] && tipo == CHATO ) 
            return largura / ( 2 * Math.abs(Math.cos ( teta )));
        
        else if ((( Math.tan(teta) > pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[3] / pontos()[2] ) && tipo == CHATO )  ||
                (( Math.tan(teta) > -pontos()[3] / pontos()[2] && Math.tan(teta) < -pontos()[1] / pontos()[0] ) && tipo == CHATO )){
                        
            double termox2 = 1;
            double termox = - ( 2*xCentroM*Math.abs(Math.cos(teta)) + 2*yCentroM*Math.abs(Math.sin(teta)) );
            double termoIndependente = xCentroM*xCentroM + yCentroM*yCentroM - raio*raio;    
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();
        }
               
        else if ( tipo == CHATOMOLA && Math.tan ( teta ) > - pontos()[3] / pontos()[2] && Math.tan ( teta ) < pontos()[3] / pontos()[2] ){
                        
            double termox2 = 1;
            double termox = - 2 * xCentroM * Math.abs(Math.cos(teta));
            double termoIndependente = xCentroM * xCentroM - raio*raio; 
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();  
        }
        
        else 
            return altura / ( 2 * Math.abs(Math.sin ( teta )));
    }
       
    
}