/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public class CanalCaixa extends Canal{
    
    /*Essa classe herda de Canal, e solicita todas os par�metros
     *necess�rias para definir um canal caixa. S�o ent�o
     *calculadas as caracter�sticas do canal assim parametrizado.
     *O m�todo valorDeY(x) � fundamental pois � a fun��o que
     *associa a cada valor de x o y correspondente do canal.
     */
    
    private double larguraFundo, larguraBase, teta;        
        
    /** Creates a new instance of CanalCaixa */
    public CanalCaixa() {
        
        profundidade = 0;
        larguraFundo = 0;
        larguraBase = 0;
        raioFundo = 0;    
        teta = 0;  
        numPontos = 6;
        tipo = CANALCAIXA;
    }
    
    public CanalCaixa(double p , double lF , double lB , double r ) {
        
        profundidade = p;
        larguraFundo = lF;
        
        if ( lB > larguraFundo )
            larguraBase = lB;
        else 
            larguraBase = lF;
        
        if ( r < larguraFundo / 2 && r < profundidade )
            raioFundo = r; 
        else
            raioFundo = Math.min(larguraFundo / 2 , profundidade );        
        
        teta = Math.atan ( profundidade / (( larguraBase - larguraFundo ) / 2 ));
        
        numPontos = 6;
        tipo = CANALCAIXA;
               
    }      
    
    
    public double valorDeY( double x ){ 
    
        // calcula o y para cada x em cada tipo de curva do canal, da esquerda para a direita. 
        try{            
        
        if( x < xInicioCanal() )
            return yInicioCanal(); // na mesa antes do canal
        
        else if ( x >= xInicioCanal() && x < pontos()[0] ) // na parede esquerda at� o in�cio do raio                       
                return ( pontos()[1] - yInicioCanal()) / ( pontos()[0] - xInicioCanal() ) * ( x - xInicioCanal() ) + yInicioCanal();        
        
        else if ( x >= pontos()[0] && x < pontos()[2] ){ 
        // no raio de fundo do lado esquerdo. Usa a classe Equacao2Grau para resolver uma equa��o de 2 grau. 
            double yc = profundidade - raioFundo;
            double termoy = -2 * yc;
            double independente = x*x - 2*x*pontos()[2] + pontos()[2]*pontos()[2] + yc*yc - raioFundo*raioFundo;
            equacao = new Equacao2Grau ( 1 , termoy , independente );
            return equacao.raizMaior();          
            
        }
        
        else if ( x >= pontos()[2] && x < pontos()[4] ) {
        // no trecho reto do fundo do canal entre os raios.    
            return pontos()[3];
        }
        
        else if ( x >= pontos()[4] && x < pontos()[6] ){
        // no raio de fundo do lado direito. Usa a classe Equacao2Grau para resolver uma equa��o de 2 grau.     
            double yc = profundidade - raioFundo;
            double termoy = -2 * yc;
            double independente = x*x + 2*x*pontos()[2] + pontos()[2]*pontos()[2] + yc*yc - raioFundo*raioFundo;
            equacao = new Equacao2Grau ( 1 , termoy , independente );
            return equacao.raizMaior();           
            
        }
        
        else if ( x >= pontos()[6] && x < xFimCanal() ) // na parede direita do fim do raio ao fim do canal
            
            return ( yFimCanal() - pontos()[7]) / ( xFimCanal() - pontos()[6] ) * ( x - pontos()[6] ) + pontos()[7];      
        
        
        else 
            return yFimCanal(); // na mesa ap�s o canal
        
        }    
        
        catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro no c�lculo do valor de Y", "Erro em CanalCaixa.java", JOptionPane.ERROR_MESSAGE );
            return 0;
        }
        
        
        
    }     
    
    
    public double xInicioCanal(){
        
        return -larguraBase / 2;
    }
    
    public double yInicioCanal(){        
        
        return 0;
    }    
    
    
    public double xFimCanal(){
        
        return -xInicioCanal();
        
    }
    
    public double yFimCanal(){
        
        return yInicioCanal();
        
    }
    
    public double[] pontos(){
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x)
        
        try {
        
        int limite = 2 * ( numPontos - 3 ) + 2;
        x0y0 = new double [ limite ];
        
       x0y0[1] = profundidade - raioFundo * ( 1 - Math.cos ( teta )); 
       x0y0[0] = xInicioCanal() + x0y0[1] / Math.tan ( teta );      
       x0y0[2] = x0y0[0] + raioFundo * Math.sin ( teta );
       x0y0[3] = profundidade;
       x0y0[4] = -x0y0[2];
       x0y0[5] = x0y0[3];
       x0y0[6] = -x0y0[0];    
       x0y0[7] = x0y0[1];       
                
        return x0y0; 
        
        }
        
        catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro em pontos()", "Erro em CanalCaixa.java", JOptionPane.ERROR_MESSAGE );
            return null;
        }   
    }
    
    public double teta(){
        
        return  teta;
        
    }
       
}