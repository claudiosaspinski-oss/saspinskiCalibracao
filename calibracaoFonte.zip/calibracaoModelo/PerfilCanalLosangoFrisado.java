/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

/**
 *
 * @author jcbrc
 */
public class PerfilCanalLosangoFrisado extends Perfil {
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. Isso � feito na classe Entrada. Depois � calculada a largura do
     *perfil de sa�da na classe Passe.
     *Agora falta construir o perfil de sa�da do passe. Ele � a uni�o do trecho
     *de material em contato com o canal, que segue portanto as equa��es deste,
     *e um raio que liga o ponto de "descolamento" com o canal com o ponto 
     *correspondente � largura m�xima, situado entre os cilindros.
     *Como os canais s�o figuras geom�tricas formadas pela uni�o
     *de segmentos de reta e arcos de c�rculo, � preciso considerar caso a 
     *caso as possibilidades de intercess�o entre o perfil de entrada e a 
     *equa��o de cada trecho de canal para depois calcular o raio e assim
     *definir a equa��o do perfil de sa�da.
     *Nesse caso, analisa-se a possibilidade de intercess�o entre o perfil e
     *a mesa do cilindro, ou seja se ela ocorrer fora do canal. 
     */
    
    private CanalQuadrado canal;
    private double xVar, yVar, luz, raioLuz, xCentroM, xC, yC, yF;
    private double [] x0y0;
    
    /** Creates a new instance of PerfilCanalLosangoFrisado */
    public PerfilCanalLosangoFrisado() {
        
        xVar = PerfilCanalLosango.getXVar();
        yVar = PerfilCanalLosango.getYVar();  
        luz = PerfilCanalLosango.getLuz();
        raioLuz = PerfilCanalLosango.getRaioLuz();
        xCentroM = PerfilCanalLosango.getXCentroM();
        xC = PerfilCanalLosango.getXC();
        yC = PerfilCanalLosango.getYC();
        canal = PerfilCanalLosango.getCanalQuadrado();
        yF = PerfilCanalLosango.getYF();
    }
    
    public double [] pontos(){
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x) para o caso em que o canal frisa       
        x0y0 = new double[30];
        
        x0y0[0] = xVar;
        x0y0[1] = yVar;        
        x0y0[2] = canal.xFimCanal();
        x0y0[3] = luz / 2;        
        x0y0[4] = canal.pontos()[2];
        x0y0[5] = canal.pontos()[3] + luz / 2;
        x0y0[6] = canal.pontos()[0];
        x0y0[7] = canal.pontos()[1] + luz / 2;
        x0y0[8] = -x0y0[2];
        x0y0[9] = x0y0[3];
        x0y0[10] = -x0y0[0];
        x0y0[11] = x0y0[1];
        x0y0[12] = -xVar;
        x0y0[13] = -yVar;        
        x0y0[14] = -canal.xFimCanal();
        x0y0[15] = -luz / 2;        
        x0y0[16] = -canal.pontos()[2];
        x0y0[17] = -(canal.pontos()[3] + luz / 2);
        x0y0[18] = -canal.pontos()[0];
        x0y0[19] = -(canal.pontos()[1] + luz / 2);
        x0y0[20] = x0y0[2];
        x0y0[21] = -x0y0[3];
        x0y0[22] = x0y0[0];
        x0y0[23] = -x0y0[1];
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){
    // calcula o y para cada x em cada tipo de curva da parte superior, da direita para a esquerda quando o canal frisa.      
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );//na parte superior do raio do friso direito
        
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return pontos()[1];// no friso lado direito, contato com a mesa do cilindro superior
        
        else if ( x > pontos()[4] && x <= pontos()[2] )
        // acompanhando a parte reta do lado direito do canal superior    
            return ( pontos()[3] + ( pontos()[5] - pontos()[3] ) / ( pontos()[4] - pontos()[2] ) * ( x - pontos()[2] ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )
        // acompanhando o raio de fundo do canal superior     
            return   canal.profundidade + luz / 2 - canal.raioFundo + Math.sqrt ( Math.pow ( canal.raioFundo , 2 ) - x*x );
        
        else if ( x > pontos()[8] && x <= pontos()[6] )        
        // acompanhando a parte reta do lado esquerdo do canal superior  
            return ( pontos()[9] + ( pontos()[7] - pontos()[9] ) / ( pontos()[6] - pontos()[8] ) * ( x - pontos()[8] ));
        
        else if ( x > pontos()[10] && x<= pontos()[8] )
            return pontos()[1];// no friso lado esquerdo, contato com a mesa do cilindro superior
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );//na parte superior do raio do friso esquerdo
        
    }
    
    public double valorDeYNeg(double x){
    // calcula o y para cada x em cada tipo de curva da parte inferior, da direita para a esquerda quando o canal frisa.     
       if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );//na parte inferior do raio do friso direito
        
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return -pontos()[1];// no friso lado direito, contato com a mesa do cilindro inferior
        
        else if ( x > pontos()[4] && x <= pontos()[2] )
        // acompanhando a parte reta do lado direito do canal superior    
            return -( pontos()[3] + ( pontos()[5] - pontos()[3] ) / ( pontos()[4] - pontos()[2] ) * ( x - pontos()[2] ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )
        // acompanhando o raio de fundo do canal inferior    
            return   -(canal.profundidade + luz / 2 - canal.raioFundo + Math.sqrt ( Math.pow ( canal.raioFundo , 2 ) - x*x ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] )        
       // acompanhando a parte reta do lado esquerdo do canal inferior 
            return -( pontos()[9] + ( pontos()[7] - pontos()[9] ) / ( pontos()[6] - pontos()[8] ) * ( x - pontos()[8] ));
        
        else if ( x > pontos()[10] && x<= pontos()[8] )
            return -pontos()[1];// no friso lado esquerdo, contato com a mesa do cilindro superior
       
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );//na parte superior do raio do friso esquerdo
        
    }
    
     public double valorDeR(double teta){
         
         if ( Math.tan(teta) > - pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0] ){
            
            
            double termox2 = 1;
            double termox = - 2 * xCentroM * Math.abs(Math.cos(teta));
            double termoIndependente = xCentroM * xCentroM - raioLuz*raioLuz; 
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();           
        }
                 
         else if (  Math.tan(teta) > pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[3] / pontos()[2] || 
                 Math.tan(teta) < -pontos()[1] / pontos()[0] && Math.tan(teta) > -pontos()[3] / pontos()[2] )
            return luz / ( 2 * Math.abs( Math.sin(teta) ));
                      
         
         else if (  Math.tan(teta) > pontos()[3] / pontos()[2] && Math.tan(teta) < pontos()[5] / pontos()[4] || 
                 Math.tan(teta) > pontos()[7] / pontos()[6] && Math.tan(teta) < pontos()[9] / pontos()[8] )
             return ( canal.alturaTeorica() + luz / 2 ) / 
                     ( Math.abs(Math.sin ( teta )) + ( Math.abs( Math.cos( teta ) * Math.tan( canal.anguloComHorizontal() ) ) ) );         
         
         
         else {                         
            
            double termox2 = 1;
            double termox = - 2*yF*Math.abs ( Math.sin(teta) );
            double termoIndependente = yF*yF - canal.raioFundo*canal.raioFundo; 
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();  
         }
              
     }
    
}
