/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public abstract class Canal {
    
    /*Essa classe cria o desenho do canal. O m�todo para isso
     *(figura()), � depois usado por cada canal espec�fico
     *de acordo com sua geometria. As classes para os canais s�o
     *herdadas dessa classe abstrata. 
     */
    
    protected int numPontos;
    protected double profundidade , raioFundo, x0y0[];
    protected Equacao2Grau equacao;
    protected GeneralPath desenhoCanal;
    public final int CANALREDONDO = 10, CANALQUADRADO = 11, CANALCAIXA = 12,
            CANALOVAL = 13, MESALISA = 14, CANALOVAL2RAIOS = 15;    
    protected int tipo;
    private double err;
    
    /** Creates a new instance of Canal */
    public Canal() {
                
    }
          
    public GeneralPath figura(){
        
        try{
            
        desenhoCanal = new GeneralPath();
        desenhoCanal.moveTo ( (float) ( xInicioCanal() - profundidade / 10 ) , (float) yInicioCanal() );         
        desenhoCanal.lineTo( (float) xInicioCanal() , (float) yInicioCanal() );         
        for (double i = xInicioCanal() ; i <= xFimCanal() ; i+=( xFimCanal() - xInicioCanal() ) / 100){
        desenhoCanal.lineTo( (float) i , (float) valorDeY(i) );    
        if ( i > 1000000 ){
            err = equacao.getDeterminante();
            break;}
        }
        desenhoCanal.lineTo( (float) xFimCanal(), (float) yFimCanal() );
        desenhoCanal.lineTo( (float) (xFimCanal() + profundidade / 10 ) , (float) yFimCanal() );
        return desenhoCanal;          
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Loop infinito no desenho do canal", "Erro em Canal.java", JOptionPane.ERROR_MESSAGE );
            return null;
        }
        
        
    }
    
    public double valorDeY ( double x ){
        
        return profundidade;
    }
    
    public double xInicioCanal(){
        
        return 0;
    }
    
    public double yInicioCanal(){
        
        return 0;
    }
    
    public double xFimCanal(){
        
        return 0;
    }
    
    public double yFimCanal(){             
        
        return 0;        
    }
       
    
    public double[] pontos(){
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x)   
        
        try {
        int limite = 2 * ( numPontos - 3 ) + 1;
        x0y0 = new double [ limite ];
        
        for (int i = 0 ; i < limite ; i++ ){
            
            x0y0[i] = 0;
            if ( i > 1000000 ){
            err = equacao.getDeterminante(); 
            break;}
            
            
            
        }  
        
        return x0y0;
        
        }
        
        catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro em pontos()", "Erro em Canal.java", JOptionPane.ERROR_MESSAGE );
            return null;
        }        
          
    }
    
    public double valorDeR( double t ){
        
        return t;
    }
    
    public Integer tipo(){
        
        if ( tipo == CANALREDONDO )
            return CANALREDONDO;
        
        else if ( tipo == CANALQUADRADO)
            return CANALQUADRADO;
        
        else if ( tipo == CANALCAIXA )
            return CANALCAIXA;
        
        else if ( tipo == CANALOVAL )
            return CANALOVAL;
        
        else if ( tipo == MESALISA)
            return MESALISA;
        
        else
            return CANALOVAL2RAIOS;
          
        
        
        
    }
    
}

