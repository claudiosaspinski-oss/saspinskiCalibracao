/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public class CanalRedondo extends Canal{
    
    /*Essa classe herda de Canal, e solicita todas os par�metros
     *necess�rias para definir um canal redondo. Para isso o 
     *construtor prev� o caso de redondo perfeito, com �ngulo 
     *de inclina��o e com 2 raios. Em cada caso s�o ent�o
     *calculadas as caracter�sticas do canal assim parametrizado.
     *O m�todo valorDeY(x) � fundamental pois � a fun��o que
     *associa a cada valor de x o y correspondente do canal.
     */
    
    protected double diametro;   
    protected double anguloSaida;    
    protected double segundoRaio;
    
        
    
    /** Creates a new instance of CanalRedondo */
    public CanalRedondo() {
        
        diametro = 0;
        profundidade = 0;
        anguloSaida = 0;
        segundoRaio = 0;
        numPontos = 4;
        raioFundo = diametro / 2;
        
        tipo = CANALREDONDO;
        
               
    }
    
     public CanalRedondo ( double dia , double prof) {
        
        diametro = dia;
        
        if ( prof <= dia /2 )
            profundidade = prof;
        else
            profundidade = dia /2;
        
        anguloSaida = 0;
        segundoRaio = 1000 * diametro;
        numPontos = 4;
        raioFundo = diametro / 2;
        
        tipo = CANALREDONDO;
               
    }
     
     public CanalRedondo ( double dia , double prof , double angSaida) {
        
        diametro = dia;
        
        if ( prof <= dia /2 )
            profundidade = prof;
        else
            profundidade = dia /2;
        
        if ( angSaida >= 0 && angSaida <= 90 )
            anguloSaida = Math.PI / 180 * angSaida;
        else
            anguloSaida = 0;
        
        segundoRaio = 1000 * diametro;
        numPontos = 4;
        raioFundo = diametro / 2;
        
        tipo = CANALREDONDO;
               
    }
     
     public CanalRedondo ( double dia , double prof , double angSaida , double segRaio) {
        
        diametro = dia;
        
        if ( prof <= dia /2 )
            profundidade = prof;
        else
            profundidade = dia /2;
        
        if ( angSaida >= 0 && angSaida <= 90 )
            anguloSaida = Math.PI / 180 * angSaida;
        else
            anguloSaida = 0;
        
        if ( (diametro / 2 - segRaio) * Math.sin(anguloSaida) < diametro / 2 - profundidade )
            segundoRaio = segRaio;
        else
            segundoRaio = diametro / 2;
        numPontos = 4;
        raioFundo = diametro / 2;
        
        tipo = CANALREDONDO;
                       
    }
     
     public double distMesaCentro(){
     // coordenada y da mesa do cilindro    
         return diametro / 2 - profundidade;
     }
     
     public double larguraCanal(){         
     // largura do canal redondo para cada construtor             
         if (anguloSaida <= anguloSaidaMinmimo())                          
             
             return larguraRedondoPerfeito();    
                                    
         else {
             
             double altura1 = - yCentroSegundoRaio();            
             double largura1 = - xCentroSegundoRaio() + larguraRedondoPerfeito() / 2;
             double independente =  largura1 * largura1 - segundoRaio * segundoRaio + altura1 * altura1;
             Equacao2Grau equacao = new Equacao2Grau ( 1.0 , 2 * largura1 , independente );            
             
             return  2 * ( larguraRedondoPerfeito() / 2 + equacao.raizMaior() );
         }
                      
     }
     
     public double xCentroSegundoRaio(){
     // abcissa do centro do raio de al�vio    
                      
             return -( segundoRaio - diametro / 2 ) * Math.cos( anguloSaida ); 
                         
     }
     
     public double yCentroSegundoRaio(){
     // ordenada do centro do raio de al�vio      
                     
             return - ( segundoRaio - diametro / 2 ) * Math.sin( anguloSaida ) - distMesaCentro(); 
                         
     }
     
     private double anguloSaidaMinmimo(){
     // Se o �ngulo de sa�da for menor que esse o redondo � perfeito, sem al�vio    
         return Math.asin( distMesaCentro() / ( diametro / 2 ) );
     }
     
     private double larguraRedondoPerfeito(){        
     // largura do redondo no caso de ser sem al�vio    
         return diametro * Math.cos( anguloSaidaMinmimo() );
             
     }
     
     public double xInicioCanal(){
         
         return - larguraCanal() / 2;
         
     }
     
     public double yInicioCanal(){
         
         return 0;
         
     }
     
     public double xFimCanal(){
         
         return  larguraCanal() / 2;
         
     }
     
     public double yFimCanal(){
         
         return 0;
         
     }      
            
     
     public double getDiametro(){
         
         return diametro;
         
     }
     
     public double getSaida(){
         
         return anguloSaida;
         
     }
     
     public double getraioSaida(){
         
         return segundoRaio;
         
     }
     
     public double valorDeY( double x ){
     // calcula o y para cada x em cada tipo de curva do canal, da esquerda para a direita.
         
         try{
                     
         if ( x < xInicioCanal())
             return yInicioCanal(); // na mesa antes do canal
         
         else if ( x >= xInicioCanal() && x < pontos()[0] ){
         // no raio de al�vio da esquerda. Usa a classe Equacao2Grau para resolver uma equa��o de 2 grau.     
             double raiz = getraioSaida() * getraioSaida() - Math.pow ( (x + xCentroSegundoRaio()),  2 );
             raiz = Math.sqrt(raiz);
             return yCentroSegundoRaio() + raiz;
         }
         
         else if ( x >= pontos()[0] && x < pontos()[2] ){
         // no raio de fundo. Usa a classe Equacao2Grau para resolver uma equa��o de 2 grau.     
             return Math.sqrt ( Math.pow ( diametro/2 , 2) - Math.pow ( x , 2) ) - distMesaCentro();
         }
         
         else if ( x >= pontos()[2] && x < xFimCanal() ){
         // no raio de al�vio da direita. Usa a classe Equacao2Grau para resolver uma equa��o de 2 grau.    
             double raiz = getraioSaida() * getraioSaida() - Math.pow ( (x - xCentroSegundoRaio()),  2 );
             raiz = Math.sqrt(raiz);
             return yCentroSegundoRaio() + raiz;
         }
         
         else
             return yFimCanal(); // na mesa ap�s o canal 
         
     }
         
         catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro em valorDeY()", "Erro em CanalRedondo.java", JOptionPane.ERROR_MESSAGE );
            return 0;
        }   
     
}
     
      
         
     
     public double[] pontos(){
     // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x)
         
         try{
             
        int limite = 2 * ( numPontos - 3 ) + 2;
        x0y0 = new double [ limite ];
       
       if ( anguloSaida <= anguloSaidaMinmimo() )             
             x0y0[0] = - larguraRedondoPerfeito() / 2;         
         else             
             x0y0[0] = - diametro / 2 * Math.cos( anguloSaida ); 
        
        
        if ( anguloSaida <= anguloSaidaMinmimo() )             
             x0y0[1] = 0;         
         else             
             x0y0[1] = diametro / 2 * Math.sin( anguloSaida ) - distMesaCentro();        
       
            
       x0y0[2] = -x0y0[0];
       x0y0[3] = x0y0[1];            
                
        return x0y0;        
    }
         
         catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro em pontos()", "Erro em CanalRedondo.java", JOptionPane.ERROR_MESSAGE );
            return null;
        }   
         
         
     }    
     
                  
     }