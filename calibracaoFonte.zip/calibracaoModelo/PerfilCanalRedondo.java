/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilCanalRedondo extends Perfil{
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. Como os canais s�o figuras geom�tricas formadas pela uni�o
     *de segmentos de reta e arcos de c�rculo, � preciso considerar caso a 
     *caso as possibilidades de intercess�o entre o perfil de entrada e a 
     *equa��o de cada trecho de canal.
     *Nesse caso, verifica-se onde a intercess�o ocorreu, e aciona-se a classe
     *que lida com o trecho respectivo (raio principal, segundo raio ou trecho
     *reto de al�vio, ou na mesa do cilindro).   
     */
    
    private static double xVar, yVar, luz, raioLuz, xCentroM, yF, x0, y0, x1, y1, xC , yC, largura; 
    private static CanalRedondo canal;    
    private static Intercessao intercessao;    
    private PerfilCanalRedondoFrisado frisado;
    private PerfilCanalRedondoCheio cheio;
    private PerfilCanalRedondoMagro magro;
        
    
    /** Creates a new instance of PerfilCanalRedondo */
    public PerfilCanalRedondo( CanalRedondo c , double larg , double luz$ , double raio ) {
        
        canal = c;
        largura = larg;
        luz = luz$;
        raioLuz = raio;
        tipo = RESULTANTE;  
        xCentroM = largura / 2 - raioLuz;
        xInicio = largura / 2;
        yInicio = 0;
        xC = canal.xCentroSegundoRaio();
        yC = canal.yCentroSegundoRaio() + luz / 2;        
        yF = canal.profundidade + luz / 2 - canal.getDiametro() / 2;
              
        x0y0 = new double [24];
        
        cortaFrisando();      
        if ( xVar < canal.xFimCanal() )
            cortaNaParede();
        if ( xVar < canal.pontos()[2])
            cortaNoRaio();      
        
        frisado = new PerfilCanalRedondoFrisado(); 
        cheio = new PerfilCanalRedondoCheio();
        magro = new PerfilCanalRedondoMagro();  
    }
    
    public double valorDeYPos(double x){
            
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeYPos(x);  
        else if ( xVar > canal.pontos()[2])
            return cheio.valorDeYPos(x);
        else 
            return magro.valorDeYPos(x); 
        
    }
    
    public double valorDeYNeg(double x){
               
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeYNeg(x);  
        else if ( xVar > canal.pontos()[2])
            return cheio.valorDeYNeg(x);
        else 
            return magro.valorDeYNeg(x); 
        
    }
    
    public double valorDeR(double teta){
               
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeR(teta);  
        else if ( xVar > canal.pontos()[2])
            return cheio.valorDeR(teta);
        else 
            return magro.valorDeR(teta); 
        
    }
    
    public static void cortaFrisando(){
        
        x0 = 0;
        x1 = 1;
        y0 = luz / 2;
        y1 = y0;
            
        intercessao = new Intercessao ( x0 ,y0 ,x1 ,y1 ,xCentroM ,0 ,raioLuz );
        
        if ( intercessao.getXMaior() != 9999 ){
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;         
        }
        
        else{
            raioLuz = canal.raioFundo;
            xCentroM = 0.001;
            intercessao = new Intercessao ( x0 ,y0 ,x1 ,y1 ,xCentroM ,0 ,raioLuz );
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }       
            
    }
    
    public static void cortaNaParede(){
        
        if (canal.getraioSaida() == 0){
            x0 = canal.pontos()[2];
            y0 = canal.pontos()[3] + luz / 2;
            x1 = canal.xFimCanal();
            y1 = canal.yFimCanal() + luz / 2; 
                      
            intercessao = new Intercessao ( x0, y0, x1, y1, xCentroM, 0, raioLuz );
        
            if ( intercessao.getXMaior() != 9999 ){
                xVar = intercessao.getXMaior();
                yVar = canal.valorDeY(xVar) + luz / 2;
            }
        
            else            
             xVar = canal.pontos()[2] - 0.001;            
        }
        else{
            x0 = xCentroM;
            y0 = 0;
            x1 = xC;
            y1 = yC;
            
            intercessao = new Intercessao ( x0 , y0 , x1 , y1 , raioLuz , canal.getraioSaida() );
            
            if ( intercessao.getXMaior() != 9999 ){
                xVar = intercessao.getXMaior();
                yVar = canal.valorDeY(xVar) + luz / 2;
            }
        
            else            
             xVar = canal.pontos()[2] - 0.001;                
        }
    }
    
    public static void cortaNoRaio(){
        
        intercessao = new Intercessao ( xCentroM, 0, 0, yF , raioLuz, canal.getDiametro()/2 );
        //intercessao = new Intercessao ( xCentroM, 0, 0, luz / 2 - canal.distMesaCentro() , raioLuz, canal.getDiametro()/2 );
        //if (intercessao.getXMenor() != 9999 && intercessao.getXMenor() > 0 ){      
          if(yF<=0){  
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
        else{
            //raioLuz = 10000;
            //xCentroM = largura / 2 - raioLuz;
            //intercessao = new Intercessao ( xCentroM, 0, 0, luz / 2 - canal.distMesaCentro(), raioLuz, canal.getDiametro()/2 );            
            xVar = intercessao.getXMenor();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
            
        }
    
   /* private class PerfilCanalRedondoFrisado  {
           
      
    public double xIntercessao(){        
        
            PerfilCanalRedondo.this.cortaFrisando();                    
           
                return xVar;
    }
    
    public double yIntercessao(){        
        
            PerfilCanalRedondo.this.cortaFrisando();           
                       
                return yVar;
    }
    
    public double [] pontos(){
        
        
        x0y0[0] = xIntercessao();
        x0y0[1] = luz / 2;        
        x0y0[2] = canal.xFimCanal();
        x0y0[3] = luz / 2;
        x0y0[4] = canal.pontos()[2];
        x0y0[5] = canal.pontos()[3] + luz / 2;
        x0y0[6] = canal.pontos()[0];
        x0y0[7] = canal.pontos()[1] + luz / 2;
        x0y0[8] = canal.xInicioCanal();
        x0y0[9] = x0y0[3];
        x0y0[10] = -x0y0[0]; 
        x0y0[11] = x0y0[1]; 
        x0y0[12] = -xIntercessao();
        x0y0[13] = -luz / 2;        
        x0y0[14] = -canal.xFimCanal();
        x0y0[15] = -luz / 2;
        x0y0[16] = -canal.pontos()[2];
        x0y0[17] = -(canal.pontos()[3]  + luz / 2);
        x0y0[18] = -canal.pontos()[0];
        x0y0[19] = -(canal.pontos()[1]  + luz / 2);
        x0y0[20] = -canal.xInicioCanal();
        x0y0[21] = -x0y0[3];
        x0y0[22] = x0y0[0]; 
        x0y0[23] = -x0y0[1]; 
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){
        
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return pontos()[1];
        else if ( x > pontos()[4] && x <= pontos()[2] && canal.getraioSaida() == 0)
            
            return Math.min((pontos()[3] + ( pontos()[5] - pontos()[3] ) / ( pontos()[4] - pontos()[2] ) * ( x - pontos()[2] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        else if ( x > pontos()[4] && x <= pontos()[2] && canal.getraioSaida() != 0)
            
            return Math.min( yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x - xC)*(x - xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )
            
            return Math.min( luz / 2 - canal.distMesaCentro() + ( Math.sqrt ( Math.pow (canal.raioFundo , 2) - x*x )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] && canal.getraioSaida() == 0 )
            
            return Math.min((pontos()[9] + ( pontos()[7] - pontos()[9] ) / ( pontos()[6] - pontos()[8] ) * ( x - pontos()[8] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] && canal.getraioSaida() != 0 )
            
            return Math.min(luz / 2 + yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x + xC)*(x + xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));
                
        else if ( x > pontos()[10] && x<= pontos()[8] )
            return pontos()[11];        
      
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
        
    }
    
    public double valorDeYNeg(double x){
        
       if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return -pontos()[1];
        else if ( x > pontos()[4] && x <= pontos()[2] && canal.getraioSaida() == 0)
            
            return -Math.min((pontos()[3] + ( pontos()[5] - pontos()[3] ) / ( pontos()[4] - pontos()[2] ) * ( x - pontos()[2] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        else if ( x > pontos()[4] && x <= pontos()[2] && canal.getraioSaida() != 0)
            
            return -Math.min(luz / 2 + yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x - xC)*(x - xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )
            
            return -Math.min( luz / 2 - canal.distMesaCentro() + ( Math.sqrt ( Math.pow (canal.raioFundo , 2) - x*x )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] && canal.getraioSaida() == 0 )
            
            return -Math.min((pontos()[9] + ( pontos()[7] - pontos()[9] ) / ( pontos()[6] - pontos()[8] ) * ( x - pontos()[8] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] && canal.getraioSaida() != 0 )
            
            return -Math.min(luz / 2 + yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x + xC)*(x + xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));
                
        else if ( x > pontos()[10] && x<= pontos()[8] )
            return -pontos()[11];        
      
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
        
    }
    
    public double valorDeR ( double teta ){
        
        if ( Math.tan(teta) > -pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0]  ){
            
            double termox2 = 1;
            double termox = -2*xCentroM*Math.abs(Math.cos(teta));
            double termoIndependente = xCentroM*xCentroM - raioLuz*raioLuz;
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
        }
               
        
        else if ( ( Math.tan(teta) > pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[3] / pontos()[2] ) ||
               ( Math.tan(teta) > pontos()[9] / pontos()[8] && Math.tan(teta) < pontos()[11] / pontos()[10] ) ) 
            return luz / ( 2 * Math.abs( Math.sin ( teta ) ) );
                
        
        else if ( ( Math.tan(teta) > pontos()[3] / pontos()[2] && Math.tan(teta) < pontos()[5] / pontos()[4] )||
                ( Math.tan(teta) > pontos()[7] / pontos()[6] && Math.tan(teta) < pontos()[9] / pontos()[8] )) {
            
            double termox2 = 1;
            double termox = - ( 2*xC*Math.abs( Math.cos(teta) ) + 2*yC*Math.abs( Math.sin(teta) ) );            
            double termoIndependente = xC*xC + yC*yC - canal.getraioSaida()*canal.getraioSaida();
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
        }       
        
        else {
            double termox2 = 1;
            double termox = - ( 2*yF*Math.abs( Math.sin(teta) ) );            
            double termoIndependente = yF*yF - canal.raioFundo*canal.raioFundo;
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
        }     
            
            
    }
    
    
}
    
    private class PerfilCanalRedondoCheio  {
           
      
    public double xIntercessao(){        
        
            PerfilCanalRedondo.this.cortaNaParede();                    
           
                return xVar;
    }
    
    public double yIntercessao(){        
        
            PerfilCanalRedondo.this.cortaNaParede();           
                       
                return yVar;
    }
    
    public double [] pontos(){
        
        
        x0y0[0] = xIntercessao();
        x0y0[1] = yIntercessao();       
        x0y0[2] = canal.pontos()[2]; 
        x0y0[3] = canal.pontos()[3] + luz / 2;
        x0y0[4] = canal.pontos()[0];  
        x0y0[5] = canal.pontos()[1] + luz / 2;  
        x0y0[6] = -x0y0[0];
        x0y0[7] = x0y0[1];        
        x0y0[8] = -xIntercessao();
        x0y0[9] = -yIntercessao();       
        x0y0[10] = -canal.pontos()[2]; 
        x0y0[11] = -(canal.pontos()[3] + luz / 2);
        x0y0[12] = -canal.pontos()[0];  
        x0y0[13] = -(canal.pontos()[1] + luz / 2);  
        x0y0[14] = x0y0[0];
        x0y0[15] = -x0y0[1];  
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){
        
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
               
        else if ( x > pontos()[2] && x <= pontos()[0] && canal.getraioSaida() == 0)            
            return Math.min((pontos()[1] + ( pontos()[3] - pontos()[1] ) / ( pontos()[2] - pontos()[0] ) * ( x - pontos()[0] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[2] && x <= pontos()[0] && canal.getraioSaida() != 0)            
            return Math.min( yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x - xC)*(x - xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[4] && x <= pontos()[2] )
            
            return Math.min( luz / 2 + ( Math.sqrt ( Math.pow (canal.raioFundo , 2) - x*x )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] && canal.getraioSaida() == 0 )
            
            return Math.min((pontos()[7] + ( pontos()[5] - pontos()[7] ) / ( pontos()[4] - pontos()[6] ) * ( x - pontos()[6] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] && canal.getraioSaida() != 0 )
            
            return Math.min( yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x + xC)*(x + xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));             
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
        
    }
    
    public double valorDeYNeg(double x){
        
        if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
               
        else if ( x > pontos()[2] && x <= pontos()[0] && canal.getraioSaida() == 0)            
            return -Math.min((pontos()[1] + ( pontos()[3] - pontos()[1] ) / ( pontos()[2] - pontos()[0] ) * ( x - pontos()[0] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[2] && x <= pontos()[0] && canal.getraioSaida() != 0)            
            return -Math.min( yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x - xC)*(x - xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[4] && x <= pontos()[2] )
            
            return -Math.min( luz / 2 + ( Math.sqrt ( Math.pow (canal.raioFundo , 2) - x*x )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] && canal.getraioSaida() == 0 )
            
            return -Math.min((pontos()[7] + ( pontos()[5] - pontos()[7] ) / ( pontos()[4] - pontos()[6] ) * ( x - pontos()[6] )) , 
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] && canal.getraioSaida() != 0 )
            
            return -Math.min( yC + Math.sqrt(canal.getraioSaida()*canal.getraioSaida() - ( x + xC)*(x + xC)),
                    Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) ));             
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
        
    }
    
    public double valorDeR( double teta ){
        
        if ( Math.tan(teta) > -pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0] ){
            
            double termox2 = 1;
            double termox = -2*xCentroM*Math.abs( Math.cos(teta) );
            double termoIndependente = xCentroM*xCentroM - raioLuz*raioLuz;
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
        } 
                
        
        else if ( (Math.tan(teta) > pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[3] / pontos()[2] ) ||
               ( Math.tan(teta) > pontos()[5] / pontos()[4] && Math.tan(teta) < pontos()[7] / pontos()[6] ) ) {
            
            double termox2 = 1;
            double termox = - ( 2*xC*Math.abs( Math.cos(teta) ) + 2*yC*Math.abs( Math.sin(teta) ) );            
            double termoIndependente = xC*xC + yC*yC - canal.getraioSaida()*canal.getraioSaida();
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
        }       
        
        else {
            
            double termox2 = 1;
            double termox = - ( 2*yF*Math.abs( Math.sin(teta) ) );            
            double termoIndependente = yF*yF - canal.raioFundo*canal.raioFundo;
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
                 
        }
    }
    }
    
    

    
     private class PerfilCanalRedondoMagro  {
           
        
    public double xIntercessao(){        
        
            PerfilCanalRedondo.this.cortaNoRaio();                    
           
                return xVar;
    }
    
    public double yIntercessao(){        
        
            PerfilCanalRedondo.this.cortaNoRaio();           
                       
                return yVar;
    }
    
    public double [] pontos(){
        
        
        x0y0[0] = xIntercessao();
        x0y0[1] = yIntercessao();       
        x0y0[2] = -x0y0[0];
        x0y0[3] = x0y0[1];  
        x0y0[4] = -xIntercessao();
        x0y0[5] = -yIntercessao();       
        x0y0[6] = x0y0[0];
        x0y0[7] = -x0y0[1];  
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){      
        
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
        
        else if ( x > pontos()[2] && x <= pontos()[0] )                    
            return  luz / 2 + Math.sqrt ( Math.pow (canal.raioFundo,2) - x*x ); 
        
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
        
    }
    
    public double valorDeYNeg(double x){        
       
            if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
        
        else if ( x > pontos()[2] && x <= pontos()[0] )                    
            return -( luz / 2 + Math.sqrt ( Math.pow (canal.raioFundo,2) - x*x )); 
        
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
               
    }
    
    public double valorDeR( double teta ){        
        
        if ( Math.tan(teta) > -pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0] ){
            
            double termox2 = 1;
            double termox = -2*xCentroM*Math.abs( Math.cos(teta) );
            double termoIndependente = xCentroM*xCentroM - raioLuz*raioLuz;
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();
        }
          
        
        else {
            double termox2 = 1;
            double termox = -2*yF*Math.abs( Math.sin(teta) );
            double termoIndependente = yF*yF - canal.raioFundo*canal.raioFundo;
            Equacao2Grau equacao = new Equacao2Grau( termox2 , termox , termoIndependente );
            return equacao.raizMaior();           
        }
    }   
    
}
     */
     public double getLargura(){
         
         return largura;
     }
     
     public static double getXVar(){
        
        return xVar;
    }
    
    public static double getYVar(){
        
        return yVar;
    }
    
    public static double getLuz(){
        
        return luz;
    }
    
    public static double getRaioLuz(){
        
        return raioLuz;
    }
    
    public static double getXCentroM(){
        
        return xCentroM;
    }    
    
    
    public static CanalRedondo getCanalRedondo(){
        
        return canal;
    }
    
    public static double getYF(){
        
        return yF;
    }
    
    public static double getXC(){
        
        return xC;
    }
    
    public static double getYC(){
        
        return yC;
    }
}