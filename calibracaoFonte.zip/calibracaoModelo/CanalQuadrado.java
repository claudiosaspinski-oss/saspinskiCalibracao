/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public class CanalQuadrado extends Canal{
    
    /*Essa classe herda de Canal, e solicita todas os par�metros
     *necess�rias para definir um canal quadrado. Para isso h� 
     *diversos construtores. Em cada caso s�o ent�o
     *calculadas as caracter�sticas do canal assim parametrizado.
     *O m�todo valorDeY(x) � fundamental pois � a fun��o que
     *associa a cada valor de x o y correspondente do canal.
     */
    
    private double lado, angulo;     
    
    
    /** Creates a new instance of CanalQuadrado */
    public CanalQuadrado() {
        
        lado = 0;
        raioFundo = 0;
        angulo = 0;
        profundidade = 0;
        numPontos = 4;
        tipo = CANALQUADRADO;
                
    }
    
    public CanalQuadrado( double p ) {
                
        raioFundo = 0;
        angulo = Math.PI/2;
        profundidade = p;
        numPontos = 4;
        tipo = CANALQUADRADO;        
    }
    
    public CanalQuadrado( double p , double r ) {
                
        raioFundo = r;
        angulo = Math.PI/2;
        profundidade = p;
        numPontos = 4;
        tipo = CANALQUADRADO;
                
    }
    
    public CanalQuadrado(double p , double r , double ang) {
        
        profundidade = p;
        raioFundo = r;
        angulo = Math.PI/180*ang;
        numPontos = 4;
        tipo = CANALQUADRADO;
                
    }
    
    public double larguraCanal(){
    // calcula a largura do canal los�ngo ou quadrado    
        double binomio1 = raioFundo * ( 1.0 / Math.sin ( angulo / 2 )  - 1 ) + profundidade;
        return 2 * binomio1 * Math.tan (  angulo / 2);
        
        
    }
        
    
    public double xInicioCanal(){
        
        return -larguraCanal() / 2;
    }
    
    public double yInicioCanal(){
        
        return 0;
    }    
    
    public double xFimCanal(){
        
        return -xInicioCanal();
        
    }
    
    public double yFimCanal(){
        
        return 0;
    }
    
    public double valorDeY( double x ){
    // calcula o y para cada x em cada tipo de curva do canal, da esquerda para a direita.
        
        try{
                
        if ( x < xInicioCanal() )
            return yInicioCanal(); // na mesa antes do canal
        
        else if ( x >= xInicioCanal() && x < pontos()[0] ) // na reta esquerda at� o in�cio do raio de fundo
            return Math.tan ( ( Math.PI - angulo ) / 2 ) * ( x - xInicioCanal() );
        
        else if ( x >= pontos()[0] && x < pontos()[2] ){
        // no raio de fundo. Usa a classe Equacao2Grau para resolver uma equa��o de 2 grau.     
            double termoy2 = -2 * ( profundidade - raioFundo );
            double independente = x * x + profundidade * profundidade - 2 * profundidade * raioFundo;
            
            Equacao2Grau equacao = new Equacao2Grau ( 1 , termoy2 , independente );
            return equacao.raizMaior();  
            
        }
        
        else if ( x >= pontos()[2]  && x < xFimCanal() ) // na parede direita do fim do raio ao fim do canal           
            return Math.tan ( ( Math.PI + angulo ) / 2 ) * ( x - xFimCanal() );
        
        else 
            return yFimCanal();   // na mesa ap�s o canal 
        }
        
        catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro no valorDeY()", "Erro em CanalQuadrado.java", JOptionPane.ERROR_MESSAGE );
            return 0;
        }  
        
    }
    
    public double[] pontos(){
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x)
        
        try {
            
        
       int limite = 2 * ( numPontos - 3 ) + 2;
       x0y0 = new double [ limite ];
        
       x0y0[0] = -raioFundo * Math.cos ( angulo / 2);  
       x0y0[1] = profundidade - raioFundo * ( 1 - Math.sin ( angulo / 2 ) );         
       x0y0[2] = -x0y0[0];
       x0y0[3] = x0y0[1];           
                
       return x0y0; 
       
    }
    
    catch (Exception exception ){
            
            JOptionPane.showMessageDialog ( null, "Erro em pontos()", "Erro em CanalQuadrado.java", JOptionPane.ERROR_MESSAGE );
            return null;
        }   
    }
    
    public double anguloComHorizontal(){
        
        return Math.PI/2 - angulo / 2;
    }
    
    public double alturaTeorica(){
        
        return larguraCanal() / 2 * Math.tan ( anguloComHorizontal() );
        
    }
    
}