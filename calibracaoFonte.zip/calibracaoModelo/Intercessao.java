/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class Intercessao {
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. Como os canais s�o figuras geom�tricas formadas pela uni�o
     *de segmentos de reta e arcos de c�rculo, � preciso considerar caso a 
     *caso as possibilidades de intercess�o entre o perfil de entrada e a 
     *equa��o de cada trecho de canal.
     *Essa classe fornece m�todos para o c�lculo de todas as possibilidades de
     *intercess�o (uma reta com outra, uma reta com um c�rculo, ou um c�rculo
     *com outro.  
     */
    
    double x, y, x0, y0, x1, y1, x2, y2, x3, y3, A, B, A1, B1, A2, B2,
           raio, raio1, raio2, xC, yC, termoX2, termoX, termoIndependente, 
           xMaior, yDeXMaior, xMenor, yDeXMenor;
    Equacao2Grau equacao;
    
    /** Creates a new instance of Intercessao */
    public Intercessao( double x0$, double y0$, double x1$, double y1$, double x2$, double y2$, double x3$, double y3$) {
        
        //construtor para interces�o de 2 retas passando por 2 pontos { (x0,y0) (x1,y1) } e { (x2,y2) (x3,y3) }
        
        x0 = x0$; y0 = y0$; x1 = x1$; y1 = y1$;
        x2 = x2$; y2 = y2$; x3 = x3$; y3 = y3$;
        
        if ( x1 != x0 && x3 != x2 ){ 
            
            A1 = ( y1 - y0 ) / ( x1 - x0 );
            B1 = y0 - x0 * ( y1 - y0 ) / ( x1 - x0 );
            A2 = ( y3 - y2 ) / ( x3 - x2 );
            B2 = y2 - x2 * ( y3 - y2 ) / ( x3 - x2 ); 
            
            x = ( B2 - B1) / ( A1 - A2 );
            y = A1 * x + B1;
        }
        
        else if ( x1 == x0 && x3 != x2){
            x = x0; 
            y = A2 * x + B2;
        }
        
        else if ( x1 != x0 && x3 == x2){
            x = x2;
            y = A1 * x + B1;
        }
        
        else {
            x = 9999;
            y = 9999;
                        
        }
               
    }
    
    public Intercessao( double x0$, double y0$, double x1$, double y1$, double xC$, double yC$, double r ) {
        
        //construtor para interces�o de 1 retas passando por 2 pontos { (x0,y0) (x1,y1) } e 
        //um circulo com centro em (xC,yC) e raio r
        
        x0 = x0$; y0 = y0$; x1 = x1$; y1 = y1$;
        xC = xC$; yC = yC$; raio = r; 
        
        if ( x1 != x0 ){ 
            
            A = ( y1 - y0 ) / ( x1 - x0 );
            B = y0 - x0 * ( y1 - y0 ) / ( x1 - x0 );
            
            termoX2 = 1 + A * A;
            termoX = 2 * ( A * B - xC - A * yC);
            termoIndependente = xC * xC + B * B - 2 * B * yC + yC * yC - raio * raio;
            equacao = new Equacao2Grau ( termoX2 , termoX , termoIndependente);
            
            if ( equacao.getDeterminante() >= 0){
                
                xMaior = equacao.raizMaior();
                yDeXMaior = A * xMaior + B;
                
                xMenor = equacao.raizMenor();
                yDeXMenor = A * xMenor + B;
            }
            
            else 
                intercessaoVazia();                   
               
        }
        else {
            
            termoX2 = 1;
            termoX = -2 * yC;
            termoIndependente = x0 * x0 - 2 * xC * x0 + xC * xC + yC * yC - raio * raio;
            equacao = new Equacao2Grau ( termoX2 , termoX , termoIndependente);
            
            if ( equacao.getDeterminante() >= 0){
            xMaior = x0;
            yDeXMaior = equacao.raizMaior();
            xMenor = x0;
            yDeXMenor = equacao.raizMenor();
            }
            
            else                 
            intercessaoVazia();           
                       
            }    
}
    
    public Intercessao( double x0$, double y0$, double x1$, double y1$, double r1, double r2 ) {
        
        //construtor para interces�o de 2 circulos com centros (x0,y0) e (x1,y1) e raios r1 e r2 
        
        x0 = x0$; y0 = y0$; x1 = x1$; y1 = y1$;
        raio1 = r1; raio2 = r2;       
         
            if ( y1 != y0 ){
            
                A = ( x1 - x0 ) / ( y1 - y0 );
                B = ( -raio2*raio2 + y1*y1 + x1*x1 + raio1*raio1 - y0*y0 - x0*x0 ) / ( 2 * ( y1 - y0 ) );
            
                termoX2 = 1 + A * A;
                termoX = 2 * ( -A * B - x0 + A * y0);
                termoIndependente = x0 * x0 + B * B - 2 * B * y0 + y0 * y0 - raio1 * raio1;
                equacao = new Equacao2Grau ( termoX2 , termoX , termoIndependente);
            
                if ( equacao.getDeterminante() >= 0){
                
                    xMaior = equacao.raizMaior();
                    yDeXMaior = -A * xMaior + B;
                
                    xMenor = equacao.raizMenor();
                    yDeXMenor = -A * xMenor + B;
                }
            
                else 
                    intercessaoVazia();                         
            
            }
            else{
            
                x = ( -raio2*raio2 + raio1*raio1 + x1*x1 - x0*x0 ) / (2*( x1 - x0 ) );               
                termoX2 = 1;
                termoX = -2 * y0;
                termoIndependente = x*x - 2*x1*x + x1*x1 + y1*y1 - raio2*raio2;
                equacao = new Equacao2Grau ( termoX2 , termoX , termoIndependente);
                
                if( equacao.getDeterminante() >= 0){
                    
                    xMaior = x;
                    xMenor = x;
                    yDeXMaior = equacao.raizMaior();
                    yDeXMenor = equacao.raizMenor();
                }
                
                else
                    intercessaoVazia();           
            
            }   
       
}
    
    public void intercessaoVazia(){
        
        xMaior = 9999;
        yDeXMaior = 9999;
        xMenor = 9999;
        yDeXMenor = 9999;
        
    }
    
    public double getXMaior(){
        
        if ( xMaior >= xMenor )
            return xMaior;
        else 
            return xMenor;
    }
    
    public double getXMenor(){
        
        if ( xMaior >= xMenor )
            return xMenor;
        else 
            return xMaior;
    }
    
    public double getYMaior(){
        
        if ( yDeXMaior >= yDeXMenor )
            return yDeXMaior;
        else 
            return yDeXMenor;
    }
    
    public double getYMenor(){
        
        if ( yDeXMaior >= yDeXMenor )
            return yDeXMenor;
        else 
            return yDeXMaior;
    }   
    
}