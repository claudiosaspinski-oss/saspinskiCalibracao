/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public class Passe {
    
    /*Essa classe recebe todas as informa��es necess�rias do material, do perfil
     *de entrada e do canal do cilindro. Com isso calcula o alargamento no passe.
     *Por meio das classes derivadas de Perfil como PerfilCanalCaixa etc, a 
     *forma final do perfil de sa�da � definida. Ent�o s�o calculadas a �rea e
     *o alongamento, velocidade, rota��o etc.
     */
    
    private Entrada entrada;
    private int tipoDeAlargamento;
    private final int EKELUND = 0, GEUZE = 1, SIEBEL = 2, SEDLACZEK = 3, HILL = 4, LUGAR = 5;
    private final int TREMABERTO = 10, TREMCONTINUO = 11, BLOCO = 12;
    private double fatorDeCorrecaoAlargamento, rotacao, producaoHoraria, luz, b9, b0, area, x0, y0;
    private double raioLuz, raioProv, dif1, dif2, areaVertice, x, dteta, o2, tetaIntercessao,raio,yC, flecha, err;
    private Material material;
    private Perfil perfilSaida;   
    private GeneralPath raioVertice;
    private Equacao2Grau equacao;
        
    /** Creates a new instance of Passe */
    public Passe( Entrada ent, Material m, int tip, double ph , double rot, double fCA ) {
        
        entrada = ent;
        material = m;
        b0 = entrada.getPerfilEntrada().getLargura();
        tipoDeAlargamento = tip;
        fatorDeCorrecaoAlargamento = fCA;
        if ( ph > 0 ){
            producaoHoraria = ph;
            rotacao = -1;
        }
        else{
            rotacao = rot;
            producaoHoraria = -1;
        }
        alargamento();        
         
        perfilDeSaida();
        
        raioVertice();
       
        areaVertice();
       
        area();  
         
    }
     
    
    public void alargamento(){
        
        switch ( tipoDeAlargamento ) {
            
            case EKELUND:                
                ekelund();
                correcao();
                break;
                
            case GEUZE:   
                b9 = 0.3 * entrada.deltaH() + b0;
                correcao();
                 break;
                 
            case SIEBEL:
                siebel();
                correcao();
                 break;
                
            case SEDLACZEK:
                sedlaczek();
                correcao();
                 break;
                
            case HILL:
                hill();
                correcao();
                 break;
                
            case LUGAR:
                lugar();
                correcao();
                 break;
                
            default:                
                b9 = 0.3 * entrada.deltaH() + b0;   
                
        }
        
    }
    
    public double raioNaLuz(){        
        
        double rLuzEntrada = 1;
        double teta1 = 0.1;
        double rt = entrada.getPerfilEntrada().valorDeR(teta1);
        double r0 = entrada.getPerfilEntrada().valorDeR(0);
        double cos = Math.cos(teta1);
        
        if (r0 - rt*Math.cos(teta1) < 0.0001)
            rLuzEntrada = 500;
        else
            rLuzEntrada = ( rt*rt + r0*r0 - 2*rt*r0*cos ) / ( 2 * ( r0 - rt*cos ));
        
        double fator = ( entrada.alturaEntrada() / entrada.alturaSaida() ) / 1.3;
        
        if (fator < 1)            
            x0 = fator * ( b9 - b0 ) / 4 + entrada.getXIntercessao();  
        
        else            
          x0 = ( b9 - b0 ) / 4 + entrada.getXIntercessao();
            //x0 = entrada.getXIntercessao();
             
          y0 = entrada.canal.valorDeY(x0) + entrada.getLuz() / 2;
        
        
        raioLuz = ( x0 * x0 + y0 * y0 + b9 * b9 / 4 - b9 * x0 ) / ( b9 - 2 * x0 );        
        
        if ( entrada.arcoDeContato() != 0 ){
            
           // verificaRaio();
            return raioLuz;
        }
        
        else        
            return rLuzEntrada;       
            
    }
    
    public void perfilDeSaida(){
        
        if ( entrada.getCanalCaixa() != null && entrada.arcoDeContato() != 0 )
            perfilSaida = new PerfilCanalCaixa ( entrada.getCanalCaixa() , b9 , entrada.getLuz() , raioNaLuz() );            
                                
        
        
        else if ( entrada.getCanalQuadrado() != null && entrada.arcoDeContato() != 0 ){
            perfilSaida = new PerfilCanalLosango ( entrada.getCanalQuadrado() , b9 , entrada.getLuz() , raioNaLuz() );
            
        }
        
        else if ( entrada.getCanalOval() != null && entrada.arcoDeContato() != 0 ){
            perfilSaida = new PerfilCanalOval ( entrada.getCanalOval() , b9 , entrada.getLuz() , raioNaLuz() );
           
        }
        
        else if ( entrada.getCanalRedondo() != null && entrada.arcoDeContato() != 0 ){
            perfilSaida = new PerfilCanalRedondo ( entrada.getCanalRedondo() , b9  , entrada.getLuz() , raioNaLuz() );
           
        }
        
        else 
            perfilSaida = entrada.getPerfilEntrada().getPerfil();
       
    }
    
    public void area(){
        
     area = perfilSaida.area() - areaVertice;
     
    }
    
    public double alongamento(){
        
        return entrada.getAreaEntrada() / area;
    }
    
    public double reducaoDeArea(){
        
        return (1 - 1.0 / alongamento()) *100;
    }
    
    public double avanco(){
        
        double ang = Math.sqrt(entrada.deltaH()/2/entrada.diametroDeTrabalho());
        ang = ang - entrada.deltaH()/2/entrada.diametroDeTrabalho()/material.coeficienteDeAtrito();
        double avanco = Math.sin(ang/2)*Math.sin(ang/2);
        avanco = avanco * ( entrada.diametroDeTrabalho() / entrada.alturaSaida() * Math.cos(ang) - 1 );
        return avanco;
    }
    
    
    
    public double velocidade(){
        
        if ( producaoHoraria > 0 )          
            return producaoHoraria / 3.6 / ( 7.85 /1000 * area );
        
        else 
            return Math.PI * entrada.diametroDeTrabalho() * rotacao() / 60000 * ( 1 + avanco() );        
       
    }
    
    public double rotacao(){
        
        if ( producaoHoraria > 0 )       
            return velocidade() * 60000 / ( ( 1 + avanco() ) * Math.PI * entrada.diametroDeTrabalho() );
        
        else 
            return rotacao;
        
    }
    
        
    public double producaoHoraria(){
        
        return 3.6 * velocidade() * area * 7.85 / 1000;
    }
    
    
    private void ekelund(){
        
        try{
        
        int i = 0;
        o2 = (1.6*material.coeficienteDeAtrito()*entrada.arcoDeContato()-1.2*entrada.deltaH())/entrada.somaH();
        double o3 = 4*o2*entrada.somaH()*entrada.arcoDeContato();
        double o4 = -Math.pow(entrada.getPerfilEntrada().getLargura() , 2 ) - 
                     8*o2*entrada.arcoDeContato()*entrada.deltaH()-o3*Math.log(entrada.getPerfilEntrada().getLargura());
        b9 = entrada.getPerfilEntrada().getLargura();
        double o5 = Math.pow( b9 , 2 ) + o3 * Math.log(b9) + o4;
        while ( Math.abs(o5) > 0.01 ){
            
            if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
            
            b9=b9-o5/(2*b9+o3/b9);
            o5 = Math.pow( b9 , 2 ) + o3 * Math.log(b9) + o4;
            i++;
        }
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em ekelund() ","Erro em Passe.java",JOptionPane.ERROR_MESSAGE);
            
        }
      
    }
    
    private void siebel(){
        double c = 0;
        double fator = 0;
        double baseDeCalculo = entrada.getPerfilEntrada().getLargura() / entrada.arcoDeContato();
        if ( baseDeCalculo <= 7 )
            fator = 1;
        else if ( baseDeCalculo <= 8 && baseDeCalculo > 7)
            fator = 0.92;
        else if ( baseDeCalculo <= 10 && baseDeCalculo > 8)
            fator = 0.75;
        else if ( baseDeCalculo <= 12 && baseDeCalculo > 10)
            fator = 0.6;
        else if ( baseDeCalculo <= 14 && baseDeCalculo > 12)
            fator = 0.45;
        else if ( baseDeCalculo <= 16 && baseDeCalculo > 14)
            fator = 0.30;
        else if ( baseDeCalculo <= 18 && baseDeCalculo > 16)
            fator = 0.3;
        else if ( baseDeCalculo <= 20 && baseDeCalculo > 18)
            fator = 0.15;
        else if ( baseDeCalculo > 20)
            fator = 0;
        
        if ( material.getTemperatura() < 1000 )            
            c = ( 1000 - material.getTemperatura() ) / 4000  + 0.35;
        else
            c= 0.35;
        
        b9 = entrada.getPerfilEntrada().getLargura() + fator * c *
                    Math.sqrt(entrada.diametroDeTrabalho()/2*entrada.deltaH())*entrada.deltaH()/entrada.alturaEntrada(); 
    }
    
    private void sedlaczek(){        
        
        b9 = b0 + entrada.deltaH() / 6 * Math.sqrt(entrada.diametroDeTrabalho() / 2 / entrada.alturaEntrada());
    }
    
    private void hill(){
       
        double x = 0.5 * b0 / ( entrada.diametroDeTrabalho() * entrada.deltaH());
        double q = 0.5 * Math.exp(-x);
        b9 = b0 * Math.pow ( ( 1 - entrada.deltaH() / entrada.alturaEntrada() ) , -q );
                
    }
    
    private void lugar(){
        
        double a = 1.269 * b0 / ( Math.pow ( Math.pow ( entrada.alturaEntrada() , 4 ) * 
                   Math.pow ( entrada.diametroDeTrabalho() , 5 ) , ( 1.0 / 9 ) ) );
        b9 = b0 * Math.pow ( entrada.alturaEntrada() / entrada.alturaSaida() , ( 1.0 / ( Math.pow ( 10 , a ))));
        
    }
    
    public void correcao(){
        
        b9 = fatorDeCorrecaoAlargamento * ( b9 - b0 ) + b0;
    }
    
    public Perfil getPerfilSaida(){
        
        return perfilSaida;
    }
    
    public double getAlargamento(){
        
        return b9;
    }
    
    public double getArea(){
        
        return area;
    }
    
    public void verificaRaio(){
        
        try{
        
        raioProv = 0;
        double i = 0; 
        while ( raioProv < 1 ){                       
        
        double x = b9/2;
        double xC = b9/2 - raioLuz;    
        double comparacao = entrada.canal.valorDeY(x) + entrada.getLuz() / 2 - Math.sqrt ( raioLuz * raioLuz - ( x - xC ) * ( x - xC ));
        for ( x = b9 / 2 ; x >= xC && x >= x0 && comparacao >= 0; x -=  b9/100 ){
       // for ( double x = b9 / 2 ; x >= xC && x > ( b0 + b9 ) / 4; x -=  b9/100 ){
            
            if ( x < -1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
           
            //if ( entrada.canal.valorDeY(x) + entrada.getLuz() / 2 > Math.sqrt ( raioLuz * raioLuz - ( x - xC ) * ( x - xC ))  )
             //continue;                 
            //else
            //{ raioProv = 1; break;}
            
            }
        
        if(comparacao < 0){
            
            raioLuz = raioLuz * 1.01;
            i++;
        }
        else
            raioProv = 1;
        
        
        if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
        }   
         if  ( raioLuz > b9 * 1000 )
            raioLuz = b9 * 1000;
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em verificaRaio() ","Erro em Passe.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
        
        }
    
    public double valorDeYVertice(double teta){        
        
        
               
        if ( flecha() > 0 )
            
            return  Math.min ( ( raio * Math.sin (teta) + y1() - raio) , 
                    ( entrada.canal.valorDeY(entrada.getPerfilEntrada().valorDeR(teta) * Math.cos(teta)) + entrada.getLuz() / 2));        
        
        else   
            
            return 0;                
        
    }
    
    public GeneralPath raioVertice(){
        
        try{
        
            raioVertice = new GeneralPath();
            dteta = 0.1;
            intercessaoVertice();
            if( valorDeYVertice(Math.PI / 2) > 0.1 ){
            raioVertice.moveTo ( (float) ( entrada.getPerfilEntrada().valorDeR(tetaIntercessao) * Math.cos(tetaIntercessao) ) , (float) ( valorDeYVertice(tetaIntercessao)  ));            
            
            for ( double i = tetaIntercessao ; i <= Math.PI - tetaIntercessao; i+=dteta ){
                
                if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
                
                    raioVertice.lineTo( (float) ( entrada.getPerfilEntrada().valorDeR(i) * Math.cos(i) ) , (float) ( valorDeYVertice(i)));
            }
            
            raioVertice.moveTo ( (float) ( entrada.getPerfilEntrada().valorDeR(tetaIntercessao) * Math.cos(tetaIntercessao) ) , (float) ( -valorDeYVertice(tetaIntercessao)  )); 
            
            for ( double i = tetaIntercessao ; i <=  Math.PI - tetaIntercessao; i+=dteta ){
                
                if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
                    raioVertice.lineTo( (float) ( entrada.getPerfilEntrada().valorDeR(i) * Math.cos(i) ) , (float) ( -valorDeYVertice(i)));
            }
            }
                return raioVertice;
                
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em valorDeYVertice() ","Erro em Passe.java",JOptionPane.ERROR_MESSAGE);
            return null;
        }
        
        
    }  
    
    public void areaVertice(){
        
        try{        
        
        intercessaoVertice();
        areaVertice = 0;        
        dteta = 0.1;
        for (double teta = tetaIntercessao ; teta <= Math.PI - tetaIntercessao ; teta += dteta ){
            
            if ( teta > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }            
            
        x = entrada.getPerfilEntrada().valorDeR(teta) * Math.cos(teta);        
        areaVertice += (entrada.canal.valorDeY(x) + entrada.getLuz() / 2  -  raio * Math.sin (teta)) * raio * dteta;
        }
        areaVertice = 2 * areaVertice;
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em areaVertice() ","Erro em Passe.java",JOptionPane.ERROR_MESSAGE);
            
        }
             
    }
    
    public double getFatorDeForma(){
        
        return o2;
    }
    
    public void intercessaoVertice(){   
                
        tetaIntercessao = Math.atan ( ( entrada.canal.valorDeY(entrada.larguraComum() / 2) + entrada.getLuz() / 2 ) /
                ( entrada.larguraComum() / 2 ) );           
        
    }
    
    public void raioNoVertice(){        
        
        double x0 = entrada.larguraComum() / 2;
        double y0 = entrada.canal.valorDeY(x0) + entrada.getLuz() / 2;
        raio = ( x0 * x0 + y0 * y0 + y1() * y1() - 2 * y0 * y1() ) / ( 2 * y1() - 2 * y0 );
        
        if ( raio > b9 * 1000 )
            raio = b9 * 1000;
        
    }
    
    public double flecha(){
        
        return ( entrada.fatorDesigualdadeDeformacao() - 0.7 ) * entrada.larguraComum();
    }
    
    public double y1(){
        
       return  entrada.canal.profundidade + entrada.getLuz() / 2 - flecha();
    }       
      
 }