/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class Equacao2Grau {
    
    /*Essa classe calcula as ra�zes de uma equa��o do 
     *segundo grau, sendo dados os coeficientes a, b e c.
     */
    
    private double coeficienteX2, coeficienteX, termoIndependente;
    
    /** Creates a new instance of Equacao2Grau */
    public Equacao2Grau() {
        
        seta(1);
        setb(0);
        setc(0);
    }
    
    public Equacao2Grau( double a , double b , double c ) {
        
        seta(a);
        setb(b);
        setc(c);
        
    } 
    
    public void seta( double a ){
        
       if (a != 0)
        coeficienteX2 = a;
       else
          coeficienteX2 = 0.0000001; 
    }
    
    public void setb( double b ){
        
        coeficienteX = b;
    }
    
    public void setc( double c ){
        
        termoIndependente = c;
        
    }
    
    public double setDeterminante(){
        
        double determinante = Math.pow( coeficienteX , 2 ) - 4 * coeficienteX2 * termoIndependente;
        
        if ( determinante >= 0 )
            return determinante;
        else
            return -1;
    }
    
    public double geta( double a ){
        
        return coeficienteX2;
    }
    
    public double getb( double b ){
        
        return coeficienteX;
    }
    
    public double getc( double c ){
        
        return termoIndependente;
    }
    
    public double getDeterminante(){
                      
        return setDeterminante();      
    }
    
    public double raizMaior(){
        
        if ( getDeterminante() >= 0) {
        
            double raiz1 = (- getb( coeficienteX ) + Math.sqrt (getDeterminante())) / ( 2 * geta(coeficienteX2));
            double raiz2 = (- getb( coeficienteX ) - Math.sqrt (getDeterminante())) / ( 2 * geta(coeficienteX2));
        
            if ( raiz1 > raiz2 )
                 return raiz1;
            else
                 return raiz2;
            }
        else
            return -99999999;
    }
    
    public double raizMenor(){
        
        if ( getDeterminante() >= 0) {
        
            double raiz1 = (- getb( coeficienteX ) + Math.sqrt ( getDeterminante()) ) / ( 2 * geta(coeficienteX2));
            double raiz2 = (- getb( coeficienteX ) - Math.sqrt ( getDeterminante()) ) / ( 2 * geta(coeficienteX2));
        
            if ( raiz1 > raiz2 )
                 return raiz2;
            else
                 return raiz1;
            }
        else
            return -99999999;
    }
    
    public String toString(){
        
        String raizMaior$;
        String raizMenor$;
        
        if (getDeterminante() < 0 ) {
            
            raizMaior$ = "imagin�ria";
            raizMenor$ = "imagin�ria";
        }
        else {
            raizMaior$ = Double.toString ( Math.floor ( raizMaior() * 1000 ) / 1000 );
            raizMenor$ = Double.toString ( Math.floor ( raizMenor() * 1000 ) / 1000 );
        }
        return "( " +  raizMaior$ + " , " +  raizMenor$  + " )";
        
    }
    
}