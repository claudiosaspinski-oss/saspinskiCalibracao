/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilCanalCaixaFrisado extends Perfil {
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. Isso � feito na classe Entrada. Depois � calculada a largura do
     *perfil de sa�da na classe Passe.
     *Agora falta construir o perfil de sa�da do passe. Ele � a uni�o do trecho
     *de material em contato com o canal, que segue portanto as equa��es deste,
     *e um raio que liga o ponto de "descolamento" com o canal com o ponto 
     *correspondente � largura m�xima, situado entre os cilindros.
     *Como os canais s�o figuras geom�tricas formadas pela uni�o
     *de segmentos de reta e arcos de c�rculo, � preciso considerar caso a 
     *caso as possibilidades de intercess�o entre o perfil de entrada e a 
     *equa��o de cada trecho de canal para depois calcular o raio e assim
     *definir a equa��o do perfil de sa�da.
     *Nesse caso, analisa-se a possibilidade de intercess�o com a mesa do 
     *cilindro, ou seja, a intercess�o acontecendo fora do canal. 
     */
    
     private CanalCaixa canal;
     private double xVar, yVar, luz, raioLuz, xCentroM, xC, yC;
     private double [] x0y0;
     
    public PerfilCanalCaixaFrisado(){
        
        xVar = PerfilCanalCaixa.getXVar();
        yVar = PerfilCanalCaixa.getYVar();  
        luz = PerfilCanalCaixa.getLuz();
        raioLuz = PerfilCanalCaixa.getRaioLuz();
        xCentroM = PerfilCanalCaixa.getXCentroM();
        xC = PerfilCanalCaixa.getXC();
        yC = PerfilCanalCaixa.getYC();
        canal = PerfilCanalCaixa.getCanalCaixa();
    }
     
    
    public double [] pontos(){
        
        x0y0 = new double [40];
        
        x0y0[0] = xVar;
        x0y0[1] = yVar;        
        x0y0[2] = canal.xFimCanal();
        x0y0[3] = luz / 2;
        x0y0[4] = canal.pontos()[6];
        x0y0[5] = canal.pontos()[7] + luz/2;
        x0y0[6] = canal.pontos()[4];
        x0y0[7] = canal.pontos()[5] + luz/2;
        x0y0[8] = canal.pontos()[2];
        x0y0[9] = canal.pontos()[3] + luz/2;
        x0y0[10] = canal.pontos()[0];
        x0y0[11] = canal.pontos()[1] + luz/2;
        x0y0[12] = -x0y0[2];
        x0y0[13] = x0y0[3];
        x0y0[14] = -x0y0[0];
        x0y0[15] = x0y0[1];
        x0y0[16] = -xVar;
        x0y0[17] = -yVar;        
        x0y0[18] = -canal.xFimCanal();
        x0y0[19] = -luz / 2;
        x0y0[20] = -canal.pontos()[6];
        x0y0[21] = -canal.pontos()[7] - luz/2;
        x0y0[22] = -canal.pontos()[4];
        x0y0[23] = -canal.pontos()[5] - luz/2;
        x0y0[24] = -canal.pontos()[2];
        x0y0[25] = -canal.pontos()[3] - luz/2;
        x0y0[26] = -canal.pontos()[0];
        x0y0[27] = -canal.pontos()[1] - luz/2;
        x0y0[28] = x0y0[2];
        x0y0[29] = -x0y0[3];
        x0y0[30] = x0y0[0];
        x0y0[31] = -x0y0[1];
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){
        
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
        
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return pontos()[1];
        
        else if ( x > pontos()[4] && x <= pontos()[2] )            
            return ( pontos()[3] + ( pontos()[5] - pontos()[3] ) / ( pontos()[4] - pontos()[2] ) * ( x - pontos()[2] ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )            
            return  (yC + Math.sqrt ( Math.pow (canal.raioFundo,2) - (x-xC)*(x-xC) ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] )            
            return  pontos()[7];        
        
        else if ( x > pontos()[10] && x<= pontos()[8] )
            return  (yC + Math.sqrt ( Math.pow (canal.raioFundo,2) - (x+xC)*(x+xC) ));
        
        else if ( x > pontos()[12] && x <= pontos()[10] )
            return  pontos()[13] + ( pontos()[11] - pontos()[13] ) / ( pontos()[10] - pontos()[12] ) * ( x - pontos()[12] );
        
        else if ( x > pontos()[14] && x<= pontos()[12] )
            return pontos()[15];
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
        
    }
    
    public double valorDeYNeg(double x){
        
       if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );
        
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return -pontos()[1];
        
        else if ( x > pontos()[4] && x <= pontos()[2] )            
            return -( pontos()[3] + ( pontos()[5] - pontos()[3] ) / ( pontos()[4] - pontos()[2] ) * ( x - pontos()[2] ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )            
            return  -(yC + Math.sqrt ( Math.pow (canal.raioFundo,2) - (x-xC)*(x-xC) ));
        
        else if ( x > pontos()[8] && x <= pontos()[6] )            
            return  -pontos()[7];        
        
        else if ( x > pontos()[10] && x<= pontos()[8] )
            return  -(yC + Math.sqrt ( Math.pow (canal.raioFundo,2) - (x+xC)*(x+xC) ));
        
        else if ( x > pontos()[12] && x <= pontos()[10] )
            return  -(pontos()[13] + ( pontos()[11] - pontos()[13] ) / ( pontos()[10] - pontos()[12] ) * ( x - pontos()[12] ));
        
        else if ( x > pontos()[14] && x<= pontos()[12] )
            return -pontos()[15];
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );
    
    } 
    
    public double valorDeR( double teta ){
        
        if ( Math.tan(teta) > - pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0] ){            
            
            double termox2 = 1;
            double termox = - 2 * xCentroM * Math.abs(Math.cos(teta));
            double termoIndependente = xCentroM * xCentroM - raioLuz*raioLuz;  
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();           
        }         
        
        else if  ( (Math.tan(teta) > pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[3] / pontos()[2]) ||
                (Math.tan(teta) < -pontos()[1] / pontos()[0] && Math.tan(teta) > -pontos()[3] / pontos()[2] ))                
            return luz / ( 2 * Math.abs(Math.sin(teta) ));       
        
        
        else if ( (Math.tan(teta) > pontos()[3] / pontos()[2] && Math.tan(teta) < pontos()[5] / pontos()[4]) ||
                (Math.tan(teta) > pontos()[27] / pontos()[26] && Math.tan(teta) < pontos()[29] / pontos()[28]) )            
            return ( luz / 2 + Math.tan(canal.teta())*pontos()[2] ) / ( Math.abs(Math.cos (teta))*Math.tan(canal.teta()) + Math.abs(Math.sin(teta)));
        
               
        else if ( (Math.tan(teta) > pontos()[5] / pontos()[4] && Math.tan(teta) < pontos()[7] / pontos()[6] )|| 
                (Math.tan(teta) > pontos()[9] / pontos()[8] && Math.tan(teta) < pontos()[11] / pontos()[10] )) {
                        
            double termox2 = 1;
            double termox = - ( 2*xC*Math.abs(Math.cos(teta)) + 2*yC*Math.abs(Math.sin(teta) ));
            double termoIndependente = xC*xC + yC*yC - canal.raioFundo*canal.raioFundo; 
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();            
        }        
        
        else       
            return  pontos()[7] /  Math.abs(Math.sin (teta)) ;
        
    }
}