/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilOval extends Perfil{
    
    /*Essa classe herda de Perfil e fornece m�todos como 
     *valorDeY e valorDeTeta espec�ficos para um oval
     *como se��o de entrada. Nesse caso o raio da luz
     *concorda com o raio do fundo.
     */
    
    double altura, largura, raioFundo, raioLuz;
    double yCentroFundo, xCentroLuz, xCentroM, xCentrom, yCentro;
    double termoX2, termoX, termoIndependente, A, B,larguraTeorica;
    Equacao2Grau equacao1;
    
    
    /** Creates a new instance of PerfilOval */
    
    
    public PerfilOval(double alt , double larg , double rF , double rL) {
        
        tipo = OVAL;         
        largura = larg;
        altura = alt; 
        if( rF >= ( largura*largura + altura*altura ) / ( 4*altura ) )          
            raioFundo = rF;
        else
            raioFundo = ( largura*largura + altura*altura ) / ( 4*altura );
        
        if (rL > (altura*altura/4+largura*largura/4-altura*raioFundo) / (largura-2*raioFundo) && 
                (altura*altura/4+largura*largura/4-altura*raioFundo) / (largura-2*raioFundo) > 0)
            raioLuz = rL;
        else if (rL > (altura*altura/4+largura*largura/4-altura*raioFundo) / (largura-2*raioFundo) && 
                (altura*altura/4+largura*largura/4-altura*raioFundo) / (largura-2*raioFundo) < 0)
                raioLuz = (altura*altura/4+largura*largura/4-altura*raioFundo) / (largura-2*raioFundo);
        else
                raioLuz = 1000;
        
        
        x0y0 = new double [20];
        xInicio = largura / 2;
        yInicio = 0;
        yCentroFundo = altura / 2 - raioFundo;        
        xCentroM = largura / 2 - raioLuz;
        xCentrom = - xCentroM;
        yCentro = altura / 2 - raioFundo;
        A = xCentroM / yCentroFundo;           
        B = yCentroFundo*yCentroFundo - xCentroM*xCentroM + raioLuz*raioLuz - raioFundo*raioFundo;           
        B = B / (2*yCentroFundo);
        termoX2 = 1 + ( A*A );
        termoX = 2*A*B - 2*A*yCentroFundo;
        termoIndependente = B*B - 2*B*yCentroFundo + yCentroFundo*yCentroFundo - raioFundo*raioFundo;
        equacao1 = new Equacao2Grau ( termoX2 , termoX , termoIndependente);
        
    }
    
    public double area(){
        
        double teta1 = Math.acos(pontos()[0] / raioFundo);
        double teta2 = Math.PI / 2;
        Redondo redondoFundo = new Redondo ( 2*raioFundo , teta1 , teta2 , 0 );
        
        double teta3 = Math.acos(pontos()[1] / raioLuz);
        double teta4 = Math.PI / 2;
        Redondo redondoLuz = new Redondo ( 2*raioLuz , teta3 , teta4 , 0 );
        
        double areaInterna = 4*pontos()[0]*pontos()[1];
        double areaFundo = 2*redondoFundo.area();
        double areaLuz = 2*redondoLuz.area();
        
        return areaInterna + areaFundo + areaLuz;
    }
    
    public double[] pontos(){       
                     
                    
           x0y0[0] = equacao1.raizMaior();              
           x0y0[1] = A*x0y0[0] + B;           
           
           x0y0[2] = -x0y0[0];
           x0y0[3] = x0y0[1];
           
           x0y0[4] = x0y0[2];
           x0y0[5] = -x0y0[3];
           
           x0y0[6] = x0y0[0];
           x0y0[7] = -x0y0[1];
           
           x0y0[8] = 0;
           x0y0[9] = 0;
           
           x0y0[10] = 0;
           x0y0[11] = 0;
           
           x0y0[12] = 0;
           x0y0[13] = 0;
           
           x0y0[14] = 0;
           x0y0[15] = 0;       
                  
           return x0y0;   
        
    }
    
    public double valorDeYPos(double x){       
                
        if ( x <= xInicio && x > pontos()[0] )
            return Math.sqrt(raioLuz*raioLuz - (x-xCentroM)*(x-xCentroM));        
        else if (x <= pontos()[0] && x > pontos()[2] )
            return Math.sqrt(raioFundo*raioFundo - (x*x)) + yCentro;
        else if (x <= pontos()[2] && x >= -xInicio )
            return Math.sqrt(raioLuz*raioLuz - (x-xCentrom)*(x-xCentrom));
        else return 0;         
        
    }
    
    public double valorDeYNeg(double x){        
        
        if ( x <= xInicio && x > pontos()[0] )
            return -(Math.sqrt(raioLuz*raioLuz - (x-xCentroM)*(x-xCentroM)));
        else if (x <= pontos()[0] && x > pontos()[2] )
            return (-Math.sqrt(raioFundo*raioFundo - (x*x)) - yCentro);
        else if (x <= pontos()[2] && x >= -xInicio )
            return -(Math.sqrt(raioLuz*raioLuz - (x-xCentrom)*(x-xCentrom)));
        else return 0;           
        
    } 
    
    public double valorDeR(double teta){        
        
        if ( Math.tan(teta) > pontos()[1] / pontos()[0] || Math.tan(teta) < pontos()[3] / pontos()[2] ){
               
        double termox2 = 1;
        double termox = 2 * ( raioFundo - altura / 2 ) * Math.abs(Math.sin( teta ));
        double termoIndependente = altura * altura / 4 - raioFundo * altura;
        Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
        
        return equacao.raizMaior();
        }
        
        else {
             
        double termox2 = 1;
        double termox = ( 2 * raioLuz - largura ) * Math.abs(Math.cos( teta ));
        double termoIndependente = largura * largura / 4 - raioLuz * largura;
        Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
        
        return equacao.raizMaior();
        }      
    
    
}   
   
}