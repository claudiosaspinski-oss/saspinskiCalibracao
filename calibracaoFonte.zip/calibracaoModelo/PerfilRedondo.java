/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilRedondo extends Perfil{
    
    /*Essa classe herda de Perfil e fornece m�todos como 
     *valorDeY e valorDeTeta espec�ficos para um redondo
     *perfeito como se��o de entrada  
     */
    
    double raio;       
    
    /** Creates a new instance of PerfilRedondo */
    public PerfilRedondo() {
        
        tipo = REDONDO;
        xInicio = raio;
        
    }
    
     public PerfilRedondo(double r) {
        
        tipo = REDONDO;
        raio = r;
        xInicio = raio;
        
    }
     
     public double area(){
        
        return Math.PI * raio*raio;
    }     
    
     
     public double valorDeYPos(double x){               
            
            return Math.sqrt( raio*raio - x*x );           
    }
    
    public double valorDeYNeg(double x){           
            
            return -Math.sqrt( raio*raio - x*x );
            
    }
    
    public double valorDeR(double teta){               
            
            return raio;           
    }     
    
}