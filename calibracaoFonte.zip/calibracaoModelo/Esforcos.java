/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import javax.swing.*;

public class Esforcos {
    
    /*Essa classe calcula a for�a de separa��o dos cilindros, o torque e a 
     *pot�ncia do passe. 
     */
    
    Entrada entrada;
    Passe passe;
    Material material;
    Equacao2Grau equacao;
    final int EKELUND = 0, MAUK = 1, TSELIKOV = 2, MISAKA = 3;
    int metodoDeForca;
    double kF, fator, deformacaoUniforme, velocidadeDeformacao, err;
    
    /** Creates a new instance of Esforcos */
    public Esforcos(Entrada e, Passe p, Material m, int metodo ) {
        
        entrada = e;
        passe = p; 
        material = m;
        metodoDeForca = metodo;
        
        deformacaoUniforme = Math.log(entrada.alturaEntrada() / entrada.alturaSaida());
        velocidadeDeformacao = passe.velocidade() * deformacaoUniforme / ( entrada.arcoDeContato() / 1000 );
        
        if ( metodoDeForca == EKELUND || metodoDeForca == TSELIKOV )
            resistenciaDeformacaoEkelund();
        
        else if ( metodoDeForca == MAUK )
            resistenciaDeformacaoMauk();
        
        else if ( metodoDeForca == MISAKA )
            resistenciaDeformacaoMisaka();            
        
        else kF=7;
        
        
    }
    
    public void resistenciaDeformacaoMauk(){             
        
        double A = 4.59462904;
        double B = .179599573;
        double C = .0196427786;
        double D = .0566336862000012;
        double E = .00235420612;
        
        kF = Math.exp( A - B * deformacaoUniforme + C * Math.log( deformacaoUniforme ) + 
                D * Math.log ( velocidadeDeformacao ) - E * material.getTemperatura());
        
    }
    
    public void resistenciaDeformacaoEkelund(){
        
        double epsilon = 0.01 * ( 20164 - 7.89 * ( 9.0 / 5.0 * material.getTemperatura() + 32 ) ) / 2240;
        double epsilonMetrico = epsilon * 1.01605 / ( 25.4001 * 25.4001 );
       
        double sigma = 100 * epsilonMetrico * ( 1.4 + material.getTeorDeCarbono() + material.getTeorDeManganes() + 0.3 * material.getTeorDeCromo());
        kF = ( sigma + 2 * passe.velocidade() * epsilonMetrico * Math.sqrt(entrada.deltaH() / ( entrada.diametroDeTrabalho() / 2 ) )/
        entrada.somaH() ) * 1000;
    }
    
    public void resistenciaDeformacaoMisaka(){
        
        double C = material.getTeorDeCarbono();
        double beta = 0.126 -  1.75 * C  +  0.594 * Math.pow ( C , 2 )  + 
                ( 2831 +  2968 * C  -  1120 * Math.pow ( C , 2 ) ) / ( material.getTemperatura() + 273 );
        
        kF = Math.pow ( deformacaoUniforme ,  0.21  ) * Math.pow ( velocidadeDeformacao , 0.13 ) * Math.exp(beta);        
        
    }
    
    public double fatorGeometrico(){
        
        if ( metodoDeForca == MAUK || metodoDeForca == EKELUND )
            
            return 1 + passe.getFatorDeForma();
        
        else if ( metodoDeForca == TSELIKOV ){
            tselikov();
            return fator;      
        }
        
        else {
            nakajima();
            return fator; 
            
        }
    }       
     
    
    public double forca(){
        
        
        return fatorGeometrico() * ( entrada.getPerfilEntrada().getLargura() + 
                passe.getAlargamento()) / 2 * entrada.arcoDeContato() * kF;
        
        
    } 
    
    
    public double torque(){
        
        return forca() * entrada.arcoDeContato() / 1000;        
        
    }
    
    public double potencia(){
        
        return torque() * 2.0 * Math.PI / 60 * passe.rotacao() * 9.8 / 1000;     
                
    }
    
    public void tselikov(){
        
        try{
            
        Colina colina ;
        colina = new Colina(entrada.diametroDeTrabalho(), entrada.alturaEntrada(), entrada.alturaSaida(), material.coeficienteDeAtrito(), 1);
        
        
        fator = colina.fatorGeometrico();
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em tselikov() ","Erro em Esforcos.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public void nakajima(){
        
        double alturaMedia = ( entrada.alturaEntrada() + 2 * entrada.alturaSaida() ) / 3;
        fator = 0.25 * entrada.arcoDeContato() / alturaMedia + 0.21 * alturaMedia / entrada.arcoDeContato() + 0.6;
    }
}

