/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilQuadrado extends Perfil{
    
    /*Essa classe herda de Perfil e fornece m�todos como 
     *valorDeY e valorDeTeta espec�ficos para um quadrado
     *com raios de canto iguais como se��o de entrada  
     */
    
    double lado, raio, xCentroM, xCentrom, yCentroM, yCentrom;
    
    /** Creates a new instance of PerfilQuadrado */
   
    
    public PerfilQuadrado(double l , double r) {
        
        tipo = QUADRADO;
        lado = l;
        if( r <= lado / 2 )
            raio = r;
        else
            raio = lado / 2;
        x0y0 = new double [32]; 
        xCentroM = lado / 2 - raio;
        yCentroM = xCentroM;
        xCentrom = - xCentroM;
        yCentrom = xCentrom;
        
    }
    
    public double area(){
        
        return lado*lado - (4 - Math.PI) * raio*raio;
    }
    
     public double[] pontos(){
        
           xInicio = lado / 2;
           yInicio = 0;
           
           x0y0[0] = xInicio;
           x0y0[1] = lado / 2 - raio;
           
           x0y0[2] = lado / 2 - raio;
           x0y0[3] = lado / 2;
           
           x0y0[4] = -x0y0[2];
           x0y0[5] = x0y0[3];
           
           x0y0[6] = -x0y0[0];
           x0y0[7] = x0y0[1];
           
           x0y0[8] = x0y0[6];
           x0y0[9] = -x0y0[7];
           
           x0y0[10] = x0y0[4];
           x0y0[11] = -x0y0[5];
           
           x0y0[12] = x0y0[2];
           x0y0[13] = x0y0[11];
           
           x0y0[14] = x0y0[0];
           x0y0[15] = -x0y0[1];         
                  
           return x0y0;   
        
    }
     
     public double valorDeYPos(double x){ 
        
        
        if ( x < pontos()[0] && x >= pontos()[2])          
            return lado / 2 - raio + Math.sqrt(raio*raio - (x-xCentroM)*(x-xCentroM));
        else if ( x < pontos()[2] && x >= pontos()[4] )
            return lado / 2;
        else if ( x < pontos()[4] && x > pontos() [6])
            return lado / 2 - raio + Math.sqrt(raio*raio - (x-xCentrom)*(x-xCentrom));        
        else return 0;
    }
    
    public double valorDeYNeg(double x){       
       
        
        if ( x < pontos()[0] && x >= pontos()[2])           
            return -(lado / 2 - raio + Math.sqrt(raio*raio - (x-xCentroM)*(x-xCentroM)));
        else if ( x < pontos()[2] && x >= pontos()[4] )
            return -(lado / 2);
        else if ( x < pontos()[4] && x > pontos() [6])
            return -(lado / 2 - raio + Math.sqrt(raio*raio - (x-xCentrom)*(x-xCentrom)));        
        else return 0;
    }
    
    public double valorDeR(double teta){       
        
        if ( Math.tan ( teta ) > -pontos()[1] / pontos()[0] && Math.tan ( teta ) < pontos()[1] / pontos()[0] ) 
            
            return lado / ( 2 * Math.abs(Math.cos ( teta )));
        
        else if ( Math.tan(teta) > pontos()[3] / pontos()[2] || Math.tan(teta) < pontos()[5] / pontos()[4] )  
            
            return lado / ( 2 * Math.abs(Math.sin ( teta )));               
        
        else{
                        
            double termox2 = 1;
            double termox = - ( 2*xCentroM*Math.abs(Math.cos(teta)) + 2*yCentroM*Math.abs(Math.sin(teta)) );
            double termoIndependente = xCentroM*xCentroM + yCentroM*yCentroM - raio*raio; 
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior(); 
            
        }       
       
    }   
    
}