/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;
import java.awt.*;

public class Entrada {
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. 
     *Essa classe calcula essa intercess�o e as �reas, larguras e alturas
     *dos ret�ngulos equivalentes. 
     *Tamb�m calcula o �ngulo de agarre.
     */
    
    RotacaoPerfil perfilEntrada;
    Canal canal;    
    Material material;
    Equacao2Grau equacao;
    private double xPerfil, yPerfil, luz, xVar, yVar, delta, tetaProv,
            areaE, areaS,areaPerfilEntrada, xAgarre, err;
    
    
    
    /** Creates a new instance of Entrada */
    public Entrada( RotacaoPerfil rP , Canal c , Material m , double l) {
        
        //try{
            
            perfilEntrada = rP;
            canal = c;
            material = m;
            luz = l;
            xIntercessao();   
        
            if ( tetaProv > Math.PI / 2 ){            
                double x = 1/0;
            
                //xVar = 1;            
                //areaE = 1;
                //areaS = 1;
            }              
        
            else{        
                areaComumEntrada(); 
                areaComumSaida();  
                areaPerfilEntrada();
            }
        
        //}
        
        //catch(ArithmeticException arithmeticException){
            
       //     JOptionPane.showMessageDialog(null,"N�o h� intercess�o entre o perfil de entrada e o canal ","",JOptionPane.ERROR_MESSAGE);
       // }
        
   }
        
        
    
    
    public double zDeContato() {     
                
        return ( material.getDiametroCilindro() / 2  - yVar ) * Math.sin(agarre());
    }
    
    public double y3D(double d , double y2D , double z) {
        
        double raio = d / 2 - y2D;
        double alfa = Math.asin( z / raio );        
        
        return raio * ( 1 - Math.cos( alfa ) );
    } 
    
    public GeneralPath visaoDaEntrada() {
        
        try{
            
        
        GeneralPath canalNaEntrada = new GeneralPath();
        double zcontato = zDeContato();
        double diametro = material.getDiametroCilindro();
        
        canalNaEntrada.moveTo( (float)(canal.xInicioCanal() - 10) , (float)( y3D(diametro , luz / 2 , zcontato) ) );
        
        for (double x = canal.xInicioCanal() - 10 ; x < canal.xFimCanal() + 10 ; x+=0.1 ){
            canalNaEntrada.lineTo( (float)(x) , (float)( y3D(diametro , canal.valorDeY(x) + luz / 2 , zcontato ) ));
            if ( x > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
        }
        canalNaEntrada.moveTo( (float)(canal.xInicioCanal() - 10) , (float)( -y3D(diametro , luz / 2 , zcontato) ) );
        
        for (double x = canal.xInicioCanal() - 10 ; x < canal.xFimCanal() + 10 ; x+=0.1 ){
            canalNaEntrada.lineTo( (float)(x) , (float)( -y3D(diametro , canal.valorDeY(x) + luz / 2 , zcontato ) ));
            if ( x > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }
            
        }
        return canalNaEntrada;
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em visaoDaEntrada() ","Erro em Entrada.java",JOptionPane.ERROR_MESSAGE);
            return null;
        }
    } 
    
    public double agarre() {        
        
        try {            
        
        xAgarre = 0;
        for ( double teta=0 ; teta<=Math.PI ; teta+=0.1 ){
            
            if ( teta > 1000000 ){
                err = equacao.getDeterminante();
                break;               
            }
            
            double x1 = perfilEntrada.valorDeR(teta) * Math.cos(teta);  
            double x2 = perfilEntrada.valorDeR(teta) * Math.cos(teta + 0.1);
            double diferenca = perfilEntrada.valorDeR(teta) * Math.sin(teta) 
            - ( canal.valorDeY(x1) + luz / 2 );
            double diferencaPlus = perfilEntrada.valorDeR(teta+0.1) * Math.sin(teta+0.1) 
            - ( canal.valorDeY(x2) + luz / 2 );
            if ( diferencaPlus < diferenca ){
                xAgarre = x1;
                delta = diferenca;
                break;
            }
            else
                return  Math.acos( ( diametroDeTrabalho() - deltaH() )
        /  diametroDeTrabalho() );
        }
        yVar = canal.valorDeY(xAgarre);         
        
        return ( Math.acos( ( ( material.getDiametroCilindro() / 2  - yVar ) - delta )
        / ( material.getDiametroCilindro() / 2  - yVar ) ) );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em agarre() ","Erro em Entrada.java",JOptionPane.ERROR_MESSAGE);
            return 0;
        }      
        
    }
    
    public void xIntercessao() {
        
        try{
            
        
        for ( tetaProv = 0 ; perfilEntrada.valorDeR(tetaProv) * Math.sin(tetaProv) <
              ( canal.valorDeY(perfilEntrada.valorDeR(tetaProv) * Math.cos(tetaProv)) + luz / 2 ) ; tetaProv += 0.01 ){
            
            if ( tetaProv > 1000000 ){
                err = equacao.getDeterminante();
                break;               
            }
        xVar = perfilEntrada.valorDeR(tetaProv) * Math.cos(tetaProv);  
        if( tetaProv > Math.PI / 2 )
            break;
               }
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em xIntercessao() ","Erro em Entrada.java",JOptionPane.ERROR_MESSAGE);
            
        }     
        
    }
    
    public void areaComumEntrada() {
        
        try{
            
        
        double raioCritico = Math.sqrt( xVar * xVar + Math.pow(( canal.valorDeY(xVar) + luz/2 ),2 ) ) ;
        double tetaCritico = Math.acos( xVar / raioCritico );        
        areaE = 0;   
        double dteta = 0.001;
        for (double teta = tetaCritico ; teta <= Math.PI - tetaCritico ; teta += dteta ){
            
            if ( teta > 1000000 ){
                err = equacao.getDeterminante();
                break;               
            }
             areaE += perfilEntrada.valorDeR (teta) * perfilEntrada.valorDeR (teta) * dteta / 2;
             
        }
        areaE =  2 * areaE + larguraComum()*( canal.valorDeY(xVar) + luz/2 );
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro na areaComumEntrada() ","Erro em Entrada.java",JOptionPane.ERROR_MESSAGE);
            
        }     
        
    }
    
    public void areaComumSaida() {        
        
        try{
            
        
        double dX = larguraComum()/1000;
        areaS = 0;
        for ( double x = -xVar; x <= xVar ; x += dX ){
            areaS += canal.valorDeY(x) * dX;
            
            if ( x > 1000000 ){
                err = equacao.getDeterminante();
                break;               
            }
        }
            areaS = 2 * areaS + larguraComum() * luz;
            
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro na areaComumSaida() ","Erro em Entrada.java",JOptionPane.ERROR_MESSAGE);
            
        }       
       
    }
    
    public double larguraComum() {
        
        return 2 * xVar;
        
    }
    
    public double alturaEntrada() {
        
        return areaE / larguraComum();
    }
    
    public double alturaSaida() {           
        
        return areaS / larguraComum();
    }
    
    public double arcoDeContato() {
        
        return Math.pow( (  diametroDeTrabalho ()  / 2 *
                ( alturaEntrada() - alturaSaida() ) ) , 0.5 );
    }
    
    public RotacaoPerfil getPerfilEntrada() {
        
        return perfilEntrada;
    }
    
    public CanalCaixa getCanalCaixa() {
        
        if (canal.tipo() == canal.CANALCAIXA )
            return (CanalCaixa) canal;               
        else 
            return null;
    }
    
    public CanalQuadrado getCanalQuadrado() {
        
        if (canal.tipo() == canal.CANALQUADRADO )
            return (CanalQuadrado) canal;               
        else 
            return null;
    }
    
    public CanalOval getCanalOval() {
        
        if (canal.tipo() == canal.CANALOVAL )
            return (CanalOval) canal;               
        else 
            return null;
    }
    
    public CanalRedondo getCanalRedondo() {
        
        if (canal.tipo() == canal.CANALREDONDO )
            return (CanalRedondo) canal;               
        else 
           return null;
    }
    
    
    public Material getMaterial() {
        
        return material;
    }
    
    public double getLuz(){
        
        return luz;
    }
    
    public double diametroDeTrabalho(){
        
        return  material.getDiametroCilindro() - ( alturaSaida() - luz );
    }
    
    public double deltaH(){
        
        return alturaEntrada() - alturaSaida();
        
    }
    
    public double somaH(){
        
        return alturaEntrada() + alturaSaida();
        
    }
    
    public void areaPerfilEntrada(){
        
        areaPerfilEntrada = perfilEntrada.getPerfil().area();
    }
    
    public double getAreaEntrada(){
        
        return areaPerfilEntrada;
    }
    
    public double getAreaComumEntrada(){
        
        return areaE;
    }

    public double getAreaComumSaida(){
        
        return areaS;
    }
    
    public double getXIntercessao(){
        
        return xVar;
    }
    
    public double fatorDesigualdadeDeformacao(){
        
        try{
            
        
        double num = 0;
        double den = 0;
        double dTeta = 0.1;
        for ( double teta = Math.atan ( ( canal.valorDeY(xVar) + luz / 2 ) / xVar ); teta < Math.PI / 2; teta+=dTeta ){
            
            if ( teta > 1000000 ){
                err = equacao.getDeterminante();
                break;               
            }
            
            double deltaHi = perfilEntrada.valorDeR(teta) * Math.sin(teta) -
              canal.valorDeY(perfilEntrada.valorDeR(teta) * Math.cos(teta)) + luz / 2; 
            double xTeta = perfilEntrada.valorDeR(teta) * Math.cos(teta);
            double dX = perfilEntrada.valorDeR(teta) * dTeta;
            
            num +=  deltaHi * xTeta * dX ; 
            den += deltaHi * dX ;        
            
        }
        
        return num / ( den * xVar );         
              
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em fatorDesigualdadeDeformacao() ","Erro em Entrada.java",JOptionPane.ERROR_MESSAGE);
            return 1;
        }  
  
    }
    
    public double fatorDeCanal(){
        
        return material.getDiametroCilindro() - diametroDeTrabalho();
    }
    
    public double anguloNeutro(){    
        
        return Math.asin( 0.5 * Math.sin (agarre())  - ( 1 - Math.cos ( agarre() ) )/ ( 2 * material.coeficienteDeAtrito()) );
    }
    
    public double alturaNoPontoNeutro(){
        
        return  diametroDeTrabalho() / 2 * ( 1 - Math.cos ( anguloNeutro() ) ) * 2 + alturaSaida();
        
    }
    
}