/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public abstract class Perfil {
    
    /*Essa classe abstrata � usada por todas as figuras fechadas,
     *sejam as se��es de entrada, sejam as se��es calculadas do material
     *ap�s passar pelo canal. Ela fornece m�todos b�sicos a serem 
     *aproveitados por suas herdeiras, como a �rea, e os desenhos 
     *formados a partir de coordenadas cartesianas ou polares.  
     */
    
    private Equacao2Grau equacao;
    protected double xInicio, yInicio, err;
    protected double [] x0y0;
    protected Canal canal;        
    protected GeneralPath desenhoPasse;    
    public final int REDONDO = 0, QUADRADO = 1, CHATO = 2, OVAL = 3;
    public final int LOSANGO = 4, CHATOMOLA =5, RESULTANTE = 6;
    protected int tipo;
    
    
    /** Creates a new instance of Perfil */
    public Perfil() {        
    } 
       
    
    
    public double area(){
    //calcula a �rea do perfil numericamente
        
        try{
            
        
        double a = 0;   
        double dteta = 0.01;
        for (double teta = 0 ; teta <= 2 * Math.PI ; teta += dteta ){
            
            if ( teta > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            } 
          
             a += valorDeR (teta) * valorDeR (teta) * dteta / 2;
           
        }
        return a;
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em area() ","Erro em Perfil.java",JOptionPane.ERROR_MESSAGE);
            return 0;
            
        }
    }
    
    public double[] pontos(){        
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x)      
       x0y0 = new double [35];   
       
           return x0y0;   
        
    }
    
    public double valorDeYPos(double x){         
       
          
            return x;          
        
    }
    
    public double valorDeYNeg(double x){        
            
          
            return x;      
        
    }
    
    public double valorDeR(double teta){        
            
          
            return teta;      
        
    }  
    
    public GeneralPath figuraPerfil(){
        
        try{
               
        desenhoPasse = new GeneralPath();        
       
        if ( tipo == QUADRADO || tipo == CHATO){ 
            
            desenhoPasse.moveTo ( (float) pontos()[14]  , (float) pontos()[15] );
            desenhoPasse.lineTo ( (float) pontos()[0]  , (float) pontos()[1] );  
            for (double i = pontos()[0]-.1 ; i >= pontos()[6]+.1 ; i-=1 ){
                
                if ( i < -1000000 ){
                err = equacao.getDeterminante();
                break;                
            } 
                
                desenhoPasse.lineTo( (float) i , (float) valorDeYPos(i) );
            }
            desenhoPasse.lineTo ( (float) pontos()[8]  , (float) pontos()[9] );
            for (double i = pontos()[8]+.1 ; i < pontos()[14] ; i+=1 ){
                
                if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            } 
                desenhoPasse.lineTo( (float) i , (float) valorDeYNeg(i) );
            }
            desenhoPasse.closePath(); 
            return desenhoPasse;
        }
        else{
            
            desenhoPasse.moveTo ( (float) xInicio  , (float) yInicio );            
            for (double i = xInicio ; i >= -xInicio ; i-=1 ){
                
                if ( i < -1000000 ){
                err = equacao.getDeterminante();
                break;                
            } 
            desenhoPasse.lineTo( (float) i , (float) valorDeYPos(i) );
            }
            for (double i = -xInicio ; i <= xInicio ; i+=1 ){
                
                if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            } 
                desenhoPasse.lineTo( (float) i , (float) valorDeYNeg(i) );
            }
                return desenhoPasse;
        }
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em figuraPerfil() ","Erro em Perfil.java",JOptionPane.ERROR_MESSAGE);
            return null;
        }
        
    }   
    
    public GeneralPath figuraPolarPerfil(){
        
        try{
               
        desenhoPasse = new GeneralPath();             
            
            desenhoPasse.moveTo( (float) (valorDeR(0) * Math.cos(0)) , (float) (valorDeR(0) * Math.sin(0)) );            
            for (double i = 0 ; i <= 2*Math.PI ; i+=0.01 ){
                
                if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }                 
                
            desenhoPasse.lineTo( (float) (valorDeR(i) * Math.cos(i)) , (float) (valorDeR(i) * Math.sin(i)) );
            }
            return desenhoPasse;
            
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em figuraPolarPerfil() ","Erro em Perfil.java",JOptionPane.ERROR_MESSAGE);
            return null;
        }
        
    }   
    
     public double getLargura() {
        
        return 2 * valorDeR(0);
    }
    
    public double getAltura(){
        
        //return  valorDeYPos(0) - valorDeYNeg(0);
        return 2 * valorDeR( Math.PI / 2 );
    }
    
    public Canal getCanal(){
        
        return canal;
        
    }
    
   
}