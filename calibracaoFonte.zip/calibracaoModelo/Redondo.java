/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class Redondo {
    
    /*Essa classe calcula a �rea e o momento de in�rcia de 
     *redondos ou de figuras compreendidas entre 2 cordas
     *em um redodndo.Nesse �ltimo caso se usa o construtor 
     *public Redondo (d, alfa1, alfa2, a), 
     *onde d � o di�metro, alfa1 � o �ngulo trigonom�trico
     *at� o ponto de in�cio da primeira corda, alfa2 � o �ngulo
     *trigonom�trico at� o ponto de in�cio da segunda corda e
     *a � a dist�ncia do eixo de in�rcia at� o centro do
     *c�rculo. Uma utilidade dessa classe est� no c�lculo de
     *�rea de figuras com raios de concord�ncia.     
     */
    
    private double diametro, teta1, teta2, distCentro;
    
    /** Creates a new instance of Redondo */
    public Redondo() {
        
        diametro = 0;
        teta1 = 0;
        teta2 = Math.PI;
        distCentro = 0;
    }
    
    public Redondo ( double d) {
        
        diametro = d;
        teta1 = 0;
        teta2 = Math.PI;
        distCentro = 0;
    }
    
    public Redondo (double d, double alfa1, double alfa2, double a){
        
        diametro = d;
        teta1 = alfa1;
        teta2 = alfa2;
        distCentro = a; 
    }
    
    public double area(){
        
        double trig = -Math.sin(teta2) * Math.cos(teta2) + Math.sin(teta1) * Math.cos(teta1);
        return 0.25 * Math.pow(diametro, 2) * (( teta2 - teta1 ) - trig);
        
    }
    
    public double momento (){
        
        double trig1 = Math.sin(teta2) * Math.cos(teta2) - Math.sin(teta1) * Math.cos(teta1);
        double trig2 = ( Math.pow (( Math.sin (teta2)),3 ) - Math.pow( (Math.sin(teta1)),3)) / 3;
        return distCentro * Math.pow (diametro , 2) / 2 * (( teta2 - teta1 ) / 2 - trig1 / 2 ) + 0.25 * (Math.pow (diametro , 3)) * trig2;
        
    }
    
    public double centroide (){
        
        if (area() != 0)
            return this.momento() / this.area();
        else
            return 0;
    }
    
    public double momentoDeInercia(){
        
        double trig1 = Math.sin(teta2) * Math.cos(teta2) - Math.sin(teta1) * Math.cos(teta1);
        double trig2 = ( Math.pow ( Math.sin (teta2),3 ) - Math.pow( Math.sin(teta1),3)) / 3;
        double trig3 = ( teta2 - teta1 );
        double trig4 = Math.sin(teta2) * Math.pow ( Math.cos (teta2) , 3) - Math.sin(teta1) * Math.pow ( Math.cos (teta1) , 3);
        double binomio1 = 0.25 * distCentro * distCentro * diametro * diametro; 
        double binomio2 = 0.5 * distCentro * Math.pow ( diametro , 3 );
        double binomio3 = Math.pow (diametro , 4) / 8;
        
        return binomio1 * ( trig3 - trig1 ) + binomio2 * trig2 + binomio3 * ( trig3 / 8 + trig1 / 8 - trig4 / 4 );  
    }
    
    public double getDiametro(){
        
        return diametro;
        
    }
    
}