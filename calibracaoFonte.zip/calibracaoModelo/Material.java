/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class Material {
    
    /*Essa classe apenas recebe informa��es sobre o material dos cilindros e da 
     *barra e as disponibiliza. Al�m disso calcula o fator de atrito entre os 
     *cilindros e a barra.
     */
    
    private double teorDeCarbono, teorDeManganes, teorDeCromo, temperatura, 
            diametroCilindro;
    private int tipoDeCilindro;
    
    /** Creates a new instance of Material */
    public Material( double temp, double dia, int tipo, double C, double Mn, double Cr) {  
        
        temperatura = temp;
        diametroCilindro = dia;
        teorDeCarbono = C;
        teorDeManganes = Mn;
        teorDeCromo = Cr;
        tipoDeCilindro = tipo;
        
    }
    
    public double coeficienteDeAtrito(){
        
        return ( 1.05 - 0.0005 * temperatura ) * ( 1.1 - (double) tipoDeCilindro / 10 );
    }
    
    public double getDiametroCilindro(){
        
        return diametroCilindro;
    }
    
    public double getTeorDeCarbono(){
        
        return teorDeCarbono;
    }
    
    public double getTeorDeManganes(){
        
        return teorDeManganes;
    }
    
    public double getTeorDeCromo(){
        
        return teorDeCromo;
    }
    
    public double getTemperatura(){
        
        return temperatura;
    }
    
    public int getTipoDeCilindro() {
        
        return tipoDeCilindro;
    }
}