/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilLosango extends Perfil{
    
    /*Essa classe herda de Perfil e fornece m�todos como 
     *valorDeY e valorDeTeta espec�ficos para um los�ngo
     *como se��o de entrada. Nesse caso o raio da luz
     *concorda com os lados do los�ngo.  
     */
    
    double altura, largura, angulo, raioFundo, raioLuz;
    double  m, hTeorica, xCentroM, xCentrom, yCentro;
    double termoX2, termoX, termoIndependente; 
    Equacao2Grau equacao, equacao2;    
    
    
    /** Creates a new instance of PerfilLosango */
   
    
    public PerfilLosango(double alt , double larg , double ang , double rF , double rL) {
        
        tipo = LOSANGO;
        altura = alt;
        largura = larg;
        
        if( Math.PI / 180 * ang > 2*Math.atan(largura / altura) )
            angulo = Math.PI / 180 * ang;
        else
            angulo = 2*Math.atan(largura / altura);
        
        if( rF < ( largura / 3 ) / ( Math.cos(angulo / 2) ) )
            raioFundo = rF;   
        else
            raioFundo = ( largura / 3 ) / ( Math.cos(angulo / 2) );
                        
        hTeorica = 2*( raioFundo / Math.sin(angulo / 2) + altura / 2 - raioFundo);
               
        xInicio = largura / 2;
        yInicio = 0;
        
        m = Math.tan( (Math.PI + angulo) / 2 );    
        
        
        xCentroM = largura / 2 - rL;
        xCentrom = - xCentroM;
        yCentro = altura / 2 - raioFundo;
        termoX2 = 1 + m*m;
        termoX = -( 2*xCentroM - m*hTeorica );
        termoIndependente = xCentroM*xCentroM + hTeorica*hTeorica / 4 - rL*rL;           
        equacao = new Equacao2Grau ( termoX2, termoX , termoIndependente );
        
        if(equacao.getDeterminante()>0)
            
            raioLuz = rL;
        
        else{         
            
            raioLuz = 1000;
            xCentroM = largura / 2 - raioLuz;
            xCentrom = - xCentroM;           
            termoX = -( 2*xCentroM - m*hTeorica );
            termoIndependente = xCentroM*xCentroM + hTeorica*hTeorica / 4 - raioLuz*raioLuz;           
            equacao = new Equacao2Grau ( termoX2, termoX , termoIndependente );
        }
            
        
        
        x0y0 = new double [32];
        
    }
    
    public double area(){
        
        double teta1 = Math.acos(pontos()[2] / raioFundo );
        double teta2 = Math.PI - teta1;
        Redondo redondoFundo = new Redondo (2*raioFundo , teta1 , teta2 , 0 );
        double areaFundo = 2*redondoFundo.area();
        
        double teta3 = Math.acos(pontos()[1] / raioLuz );
        double teta4 = Math.PI - teta3;
        Redondo redondoLuz = new Redondo (2*raioLuz , teta3 , teta4 , 0 );
        double areaLuz = 2*redondoLuz.area();
        
        double areaCentro = 4*pontos()[0] * pontos()[1];
        
        double areaTrapezio = (pontos()[0] + pontos()[2])*( pontos()[3] - pontos()[1] );
        
        return 2*areaFundo + 2*areaLuz + areaCentro + 2*areaTrapezio; 
        
    }
    
    public double[] pontos(){          
                    
           
           x0y0[0] = equacao.raizMaior();
           x0y0[1] = m*x0y0[0] + hTeorica / 2 ;           
           x0y0[2] = raioFundo*Math.cos( angulo / 2 );
           x0y0[3] = altura / 2 - raioFundo + raioFundo*Math.sin( angulo / 2 );
           x0y0[4] = -x0y0[2];
           x0y0[5] = x0y0[3];       
           x0y0[6] = -x0y0[0];
           x0y0[7] = x0y0[1]; 
           x0y0[8] = -equacao.raizMaior();
           x0y0[9] = -(m*x0y0[0] + hTeorica / 2) ;           
           x0y0[10] = -raioFundo*Math.cos( angulo / 2 );
           x0y0[11] = -(altura / 2 - raioFundo + raioFundo*Math.sin( angulo / 2 ));
           x0y0[12] = x0y0[2];
           x0y0[13] = -x0y0[3];       
           x0y0[14] = x0y0[0];
           x0y0[15] = -x0y0[1];        
                  
           return x0y0;   
        
    }
    
    public double valorDeYPos(double x){       
                
        if ( x <= xInicio && x > pontos()[0] )
            return Math.sqrt(raioLuz*raioLuz - (x-xCentroM)*(x-xCentroM));
        else if (x <= pontos()[0] && x > pontos()[2] )
            return m * x + hTeorica / 2 ;        
        else if (x <= pontos()[2] && x > pontos()[4] ){
            double termoY2 = 1;
            double termoY = -2*yCentro;
            double termoIndependente = x*x + yCentro*yCentro - raioFundo*raioFundo;
            equacao2 = new Equacao2Grau (termoY2 , termoY , termoIndependente);            
            return equacao2.raizMaior();            
        }
            
        else if (x <= pontos()[4] && x > pontos()[6])
            return -m * x + hTeorica / 2 ;
        else if (x <= pontos()[6] && x >= -xInicio )
            return Math.sqrt(raioLuz*raioLuz - (x-xCentrom)*(x-xCentrom));
        else return 0;
        
        
    }
    
    public double valorDeYNeg(double x){        
        
        if ( x <= xInicio && x > pontos()[0] )
            return -Math.sqrt(raioLuz*raioLuz - (x-xCentroM)*(x-xCentroM));
        else if (x <= pontos()[0] && x > pontos()[2])
            return -(m * x + hTeorica / 2) ;        
        else if (x <= pontos()[2] && x > pontos()[4] ){
            double termoY2 = 1;
            double termoY = 2*yCentro;
            double termoIndependente = x*x + yCentro*yCentro - raioFundo*raioFundo;
            equacao2 = new Equacao2Grau (termoY2 , termoY , termoIndependente);
            return equacao2.raizMenor();            
        }            
        else if (x <= pontos()[4] && x > pontos()[6])
            return -(-m *  x + hTeorica / 2) ;
        else if (x <= pontos()[6] && x >= -xInicio )
            return -Math.sqrt(raioLuz*raioLuz - (x-xCentrom)*(x-xCentrom));
        else return 0;
           
        
    }
    
    public double valorDeR(double teta){        
        
        if ( Math.tan(teta) > pontos()[15] / pontos()[14] && Math.tan(teta) < pontos()[1] / pontos()[0]){
        
            double termox2 = 1;
            double termox = - 2 * xCentroM * Math.abs(Math.cos(teta));
            double termoIndependente = xCentroM * xCentroM - raioLuz*raioLuz; 
            equacao2 = new Equacao2Grau (termox2,termox,termoIndependente);            
            return equacao2.raizMaior();  
        }
        
        else if ( Math.tan(teta) > pontos()[3] / pontos()[2] || Math.tan(teta) < pontos()[5] / pontos()[4]){
                        
            double termox2 = 1;
            double termox = - 2*yCentro*Math.abs(Math.sin(teta));
            double termoIndependente = yCentro*yCentro - raioFundo*raioFundo;
            equacao2 = new Equacao2Grau (termox2,termox,termoIndependente);            
            return equacao2.raizMaior();  
        }
        
        else 
            return  hTeorica / 
                     ( 2 * Math.abs(Math.cos ( teta )) * ( Math.abs(Math.tan (teta)) + ( Math.tan( Math.PI/2 - angulo/2 ) ) ) );
        
       
            
        }
    }