/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilCanalOval extends Perfil{
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. Isso � feito na classe Entrada. Depois � calculada a largura do
     *perfil de sa�da na classe Passe.
     *Agora falta construir o perfil de sa�da do passe. Ele � a uni�o do trecho
     *de material em contato com o canal, que segue portanto as equa��es deste,
     *e um raio que liga o ponto de "descolamento" com o canal com o ponto 
     *correspondente � largura m�xima, situado entre os cilindros.
     *Como os canais s�o figuras geom�tricas formadas pela uni�o
     *de segmentos de reta e arcos de c�rculo, � preciso considerar caso a 
     *caso as possibilidades de intercess�o entre o perfil de entrada e a 
     *equa��o de cada trecho de canal para depois calcular o raio e assim
     *definir a equa��o do perfil de sa�da.
     *Nesse caso, verifica-se onde a intercess�o ocorreu, e aciona-se a classe
     *que lida com o trecho respectivo (raio do oval ou mesa do cilindro). 
     */
    
    private static double xVar, yVar, luz, raioLuz, xCentroM, yF;
    private double largura, x0, y0, x1, y1;
    private static CanalOval canal; 
    private Intercessao intercessao;    
    private PerfilCanalOvalFrisado frisado;
    private PerfilCanalOvalCheio cheio; 
   
    
    /** Creates a new instance of PerfilCanalOval */
    
    public PerfilCanalOval(){
        
    }
    
    public PerfilCanalOval( CanalOval c , double larg , double luz$ , double raio ) {
        
        canal = c;
        largura = larg;
        luz = luz$;
        raioLuz = raio;
        tipo = RESULTANTE;  
        xCentroM = largura / 2 - raioLuz;
        xInicio = largura / 2;
        yInicio = 0;        
             
        x0y0 = new double [20];
        yF = canal.profundidade + luz / 2 - canal.raioFundo;         
        
        cortaFrisando(); //calcula a abcissa da intercess�o com a mesa do cilindro      
        if ( xVar < canal.xFimCanal() )           
            cortaNoRaio(); //calcula a abcissa e ordenada da intercess�o com o raio do canal 
        // se a intercess�o for no raio, ou seja se o canal n�o frisar.   
       
        frisado = new PerfilCanalOvalFrisado();
        cheio = new PerfilCanalOvalCheio(); 
           
    }
    
    public double valorDeYPos(double x){
    // para cada tipo de intercess�o, remete o c�lculo de y = f(x) para a 
    // classe interna correspondente. Parte superior do perfil
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeYPos(x);  
        else 
            return cheio.valorDeYPos(x);   
           
    }
    
    public double valorDeYNeg(double x){
    // para cada tipo de intercess�o, remete o c�lculo de y = f(x) para a 
    // classe interna correspondente. Parte inferior do perfil          
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeYNeg(x);  
        else
            return cheio.valorDeYNeg(x);         
      
    }
    
    public double valorDeR(double teta){
    // para cada tipo de intercess�o, remete o c�lculo de r = f(teta) para a 
    // classe interna correspondente.          
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeR(teta); 
        else       
           return cheio.valorDeR(teta);
            
    }
    
    
    public void cortaFrisando(){
    // calcula a intercess�o do material com a mesa do cilindro como se fosse
    // uma mesa lisa, ou seja como se n�o existisse canal.
        x0 = 0;
        x1 = 1;
        y0 = luz / 2;
        y1 = y0;
            
        intercessao = new Intercessao ( x0 ,y0 ,x1 ,y1 ,xCentroM ,0 ,raioLuz );
     // se houver intercess�o retorna os valores de x e y.   
        if ( intercessao.getXMaior() != 9999 ){
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
        
        else{ // caso contr�rio o raio � muito pequeno, portanto for�a-o a um
            // tamanho razo�vel, no caso igual a altura do canal.
            raioLuz = 2 * canal.profundidade + luz;
            xCentroM = largura / 2 - raioLuz;
            intercessao = new Intercessao ( x0 ,y0 ,x1 ,y1 ,xCentroM ,0 ,raioLuz );
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
            
    }
    
    public void cortaNoRaio(){
    // calcula a intercess�o do material com o raio do canal oval. Esse m�todo s� � chamado se
    // o material n�o frisar, ou seja a intercess�o � dentro do canal.   
        
        intercessao = new Intercessao ( xCentroM, 0, 0, luz / 2 + canal.profundidade - canal.raioFundo, raioLuz, canal.raioFundo );
        if (intercessao.getXMaior() != 9999 && intercessao.getXMaior() > 0 ){      
    // se houver intercess�o retorna os valores de x e y.         
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
        else{// caso contr�rio o raio � muito pequeno, portanto for�a-o a um valor alto, se aproximando a uma parede vertical
            raioLuz = 10000;
            xCentroM = largura / 2 - raioLuz;
            intercessao = new Intercessao ( xCentroM, 0, 0, luz / 2 + canal.profundidade - canal.raioFundo, raioLuz, canal.raioFundo );
            
            xVar = intercessao.getXMaior(); 
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
    }
    
    /*private class PerfilCanalOvalFrisado  {
    // Essa classe calcula os valores de y = f(x) do perfil em cada trecho de
    // curva ou seja para cada tipo de equa��o. A classe s� � chamada se o
    // canal estiver frisado. 
         
    public double [] pontos(){               
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x) para o caso em que o canal frisa     
        x0y0[0] = xVar;
        x0y0[1] = yVar;        
        x0y0[2] = canal.xFimCanal();
        x0y0[3] = luz / 2;        
        x0y0[4] = -x0y0[2];
        x0y0[5] = luz / 2; 
        x0y0[6] = -x0y0[0];
        x0y0[7] = x0y0[1];
        x0y0[8] = x0y0[6];
        x0y0[9] = -x0y0[7];
        x0y0[10] = x0y0[4];
        x0y0[11] = -x0y0[5];
        x0y0[12] = x0y0[2];
        x0y0[13] = -x0y0[3];
        x0y0[14] = x0y0[0];
        x0y0[15] = -x0y0[1];
        
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){
    // calcula o y para cada x em cada tipo de curva da parte superior, da direita para a esquerda quando o canal frisa.     
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );//na parte superior do raio do friso direito
        
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return pontos()[1]; // no friso lado direito, contato com a mesa do cilindro superior
        
        else if ( x > pontos()[4] && x <= pontos()[2] )
    // acompanhando o raio de fundo do canal superior      
            return   canal.profundidade + luz / 2 - canal.raioFundo + Math.sqrt ( Math.pow ( canal.raioFundo , 2 ) - x*x );
        
        else if ( x > pontos()[6] && x <= pontos()[4] )
            
            return pontos()[1]; // no friso lado esquerdo, contato com a mesa do cilindro superior    
        
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );//na parte superior do raio do friso esquerdo
        
    } 
    
    
    public double valorDeYNeg(double x){
    // calcula o y para cada x em cada tipo de curva da parte inferior, da direita para a esquerda.     
      if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );//na parte inferior do raio do friso direito
        
        else if ( x > pontos()[2] && x <= pontos()[0] )
            return -pontos()[1];// no friso lado direito, contato com a mesa do cilindro inferior
        
        else if ( x > pontos()[4] && x <= pontos()[2] )
     // acompanhando o raio de fundo do canal inferior        
            return   -(canal.profundidade + luz / 2 - canal.raioFundo + Math.sqrt ( Math.pow ( canal.raioFundo , 2 ) - x*x ));
        
        else if ( x > pontos()[6] && x <= pontos()[4] )
            
            return -pontos()[1];// no friso lado esquerdo, contato com a mesa do cilindro inferior        
        
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );//na parte inferior do raio do friso esquerdo
        
    }
    
    public double valorDeR(double teta){
         
         if ( Math.tan(teta) > - pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0] ){            
            
            double termox2 = 1;
            double termox = - 2 * xCentroM * Math.abs( Math.cos(teta));
            double termoIndependente = xCentroM * xCentroM - raioLuz*raioLuz;
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();           
        }
         
         else if ( Math.tan(teta) > pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[3] / pontos()[2] ||
                 Math.tan(teta) < -pontos()[1] / pontos()[0] && Math.tan(teta) > -pontos()[3] / pontos()[2] ) 
            return luz / ( 2 * Math.abs( Math.sin(teta) ));   
                     
         
         
         else{             
            
            double termox2 = 1;
            double termox = - 2*yF*Math.abs(Math.sin(teta));
            double termoIndependente = yF*yF - canal.raioFundo*canal.raioFundo;
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();  
         }         
             
     }
    
    
}
    
    private class PerfilCanalOvalCheio  {
           
    
    public double [] pontos(){
    // pontos em que h� mudan�a de tipo de linha, e consequentemente do tipo
    // de equa��o y = f(x) para o caso em que o canal n�o frisa    
                
        x0y0[0] = xVar;
        x0y0[1] = yVar;   
        x0y0[2] = -x0y0[0];
        x0y0[3] = x0y0[1]; 
        x0y0[4] = x0y0[2];
        x0y0[5] = -x0y0[3];
        x0y0[6] = x0y0[0];
        x0y0[7] = x0y0[5];
        
        return x0y0;
    }
    
    
    public double valorDeYPos(double x){
    // calcula o y para cada x em cada tipo de curva da parte superior, da direita para a esquerda quando o canal n�o frisa.    
        if ( x > pontos()[0] && x <= xInicio )
            return Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );//na parte superior do raio da luz direito.
        
        else if ( x > pontos()[2] && x <= pontos()[0] )// acompanhando o raio de fundo do canal superior 
            return  ( canal.profundidade + luz / 2 - canal.raioFundo + Math.sqrt ( Math.pow ( canal.raioFundo , 2 ) - x*x )); 
        
        else 
            return Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );//na parte superior do raio da luz esquerdo.
        
    }
    
    public double valorDeYNeg(double x){
    // calcula o y para cada x em cada tipo de curva da parte inferior, da direita para a esquerda quando o canal n�o frisa.        
        if ( x > pontos()[0] && x <= xInicio )
            return -Math.sqrt ( raioLuz*raioLuz - ( x - xCentroM )*( x - xCentroM ) );//na parte inferior do raio da luz direito.
        
        else if ( x > pontos()[2] && x <= pontos()[0] )// acompanhando o raio de fundo do canal inferior 
            return -( canal.profundidade + luz / 2 - canal.raioFundo + Math.sqrt ( Math.pow ( canal.raioFundo , 2 ) - x*x )); 
        
        else 
            return -Math.sqrt ( raioLuz*raioLuz - ( x + xCentroM )*( x + xCentroM ) );//na parte inferior do raio da luz esquerdo.       
    }  
    
    public double valorDeR(double teta){
         
         if ( Math.tan(teta) > - pontos()[1] / pontos()[0] && Math.tan(teta) < pontos()[1] / pontos()[0] ){            
            
            double termox2 = 1;
            double termox = - 2 * xCentroM * Math.abs(Math.cos(teta));
            double termoIndependente = xCentroM * xCentroM - raioLuz*raioLuz;
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();           
        }             
       
         
         else {                        
            
            double termox2 = 1;
            double termox = - 2*yF*Math.abs(Math.sin(teta));
            double termoIndependente = yF*yF - canal.raioFundo*canal.raioFundo; 
            Equacao2Grau equacao = new Equacao2Grau (termox2,termox,termoIndependente);
            return equacao.raizMaior();  
         }           
         
    
}  
    
}
    */
    public double getLargura(){
        
        return largura;
        
    }
    
     public static double getXVar(){
        
        return xVar;
    }
    
    public static double getYVar(){
        
        return yVar;
    }
    
    public static double getLuz(){
        
        return luz;
    }
    
    public static double getRaioLuz(){
        
        return raioLuz;
    }
    
    public static double getXCentroM(){
        
        return xCentroM;
    }    
    
    
    public static CanalOval getCanalOval(){
        
        return canal;
    }
    
    public static double getYF(){
        
        return yF;
    }
}   