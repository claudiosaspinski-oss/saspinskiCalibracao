/*Copyright 2008 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;

public class Colina {
    
    /* Essa classe calcula a colina de fric��o associada ao
     *arco de contato e o fator geom�trico a ser multiplicado
     *ao limite de escoamento e � �rea para c�lculo da for�a
     *de lamina��o. Esse � um tipo de fator geom�trico. 
     *Dependendo do m�todo de c�lculo da for�a podem ser usados
     *outros.
     */
    
    private static double alfa, espessuraFinal, espessuraInicial, diametro, espessura, alfaInicial, tau, mu, forca;
    private static double alfaNeutro, deltaForca, deltaEspessura, forcaParcial, deltaTeta, teta, arcoContato;
    private static double pontoCriticoEntrada, pontoCriticoSaida, alturaNeutra, n, espessuraMedia, anguloRestrito;
    public static double tensaoEntradaZonaNeutra;
    private static GeneralPath colina, marcas;
    private static int flag;
    
    /** Creates a new instance of Colina */
    public Colina(double d, double eI, double eF, double m, int f) {
        
        setDiametro(d);
        setEspessuraInicial(eI);
        setEspessuraFinal(eF);
        setMu(m);
        flag = f;
        deltaTeta = 0.001;    
        tau = 5;          
        alfaInicial();
        arcoContato();        
        espessuraMedia();
        parametroN();        
        anguloRestrito();
        alfaNeutro();         
        alturaNeutra();
        grafico();
        marcas();
        
    }
    
    public static double forca ( double alfa ){
        
        
        if(alfa > alfaInicial)
            return 0;
        
        else if (alfa < 0)
            return 0;
        
        else if ( alfa > alfaNeutro && alfa <= alfaInicial ){
            
            forcaParcial = 2*tau;
            
           
            
            for (teta=alfaInicial; teta>alfa; teta-=deltaTeta){
                
                espessura = espessuraFinal + diametro * (1 - Math.cos(teta));
                deltaEspessura = -diametro * Math.sin(teta) * deltaTeta;
                
                if( flag != 1 || ( teta - alfaNeutro > anguloRestrito / 2 && mu*forcaParcial < tau )){
                    forcaParcial += ( 2 * tau - mu * forcaParcial / Math.tan(teta)) * deltaEspessura / espessura ; 
                    
                    }
                
                else if( teta - alfaNeutro > anguloRestrito / 2 ){
                    forcaParcial += ( 2 * tau - tau / Math.tan(teta)) * deltaEspessura / espessura ;
                    
                }
                
                else{
                    forcaParcial += tau * ( 2 - ( n * (espessura-alturaNeutra)/( 2 * tau * Math.tan(anguloRestrito)) ) / Math.tan(teta)) * deltaEspessura / espessura ; 
                  
                   
                    
                }
                    
            }
            if(forcaParcial<2*tau)
                forcaParcial = 2 * tau;
            
            return -forcaParcial;
            
        }
        
        else{
            
            forcaParcial = 2*tau;
            
            
            for (teta=deltaTeta; teta<alfa; teta+=deltaTeta){
                
                espessura = espessuraFinal + diametro * (1 - Math.cos(teta));
                deltaEspessura = diametro * Math.sin(teta) * deltaTeta;
                if( flag != 1 || ( alfaNeutro - teta > anguloRestrito / 2 && mu*forcaParcial<tau )){
                    forcaParcial += ( 2 * tau + mu * forcaParcial / Math.tan(teta)) * deltaEspessura / espessura;
                   
                }                
                else if ( alfaNeutro - teta > anguloRestrito / 2 ){
                    forcaParcial += ( 2 * tau + tau / Math.tan(teta)) * deltaEspessura / espessura;
                   
                }
                
                else{
                    forcaParcial += tau * ( 2 - ( n * (espessura-alturaNeutra)/( 2 * tau * Math.tan(anguloRestrito)) ) / Math.tan(teta)) * deltaEspessura / espessura ; 
                                   
                }
            }
            
            if(forcaParcial<2*tau)
                forcaParcial = 2 * tau;
            return -forcaParcial;
        }
            
    }
    
    public static void grafico(){
        
        double dTeta = 0.001;
        colina = new GeneralPath();
        colina.moveTo( 0, 0 );
        
        for (alfa = 0; alfa < alfaInicial; alfa += dTeta){
            colina.lineTo((float) (arcoParcial(alfa)), (float) (forca(alfa)/(2*tau)));
            //System.out.print(arcoParcial(alfa));System.out.println(forca(alfa)/(2*tau));
            
        } 
        
    }
    
    public static double fatorGeometrico(){
        
        double fator = 0;
        double dTeta = 0.001;
        for (alfa = 0; alfa < alfaInicial; alfa += dTeta)
            fator += forca(alfa)/(2*tau) * (arcoParcial(alfa + dTeta) - arcoParcial(alfa));        
        
        fator = -fator / arcoContato;        
        return fator;   
        
    }
    
    public static void marcas(){
        
        marcas = new GeneralPath();
        if(flag == 1){            
            
            marcas.moveTo((float)(arcoParcial(pontoCriticoEntrada)), 0);
            marcas.lineTo((float)(arcoParcial(pontoCriticoEntrada)), (float)(-3));
            marcas.moveTo((float)(arcoParcial(pontoCriticoSaida)), 0);
            marcas.lineTo((float)(arcoParcial(pontoCriticoSaida)), (float)(-3));
            
        }
            
        
    }
    
    public static void arcoContato(){
        
        arcoContato = diametro / 2 * Math.sin(alfaInicial);
    }
    
    public static double arcoParcial(double alfa){
        
        return diametro / 2 * Math.sin(alfa);
    }
    
    public void setDiametro(double d){
        
        diametro = d;    
    }
    
    public void setEspessuraInicial(double eI){
        
        espessuraInicial = eI;
    }
    
    public void setEspessuraFinal(double eF){
        
        espessuraFinal = eF;
    }
    
    public void setMu(double m){
        
        mu = m;
    }
    
    public void alfaInicial(){
        
        alfaInicial = Math.acos( (diametro  - (espessuraInicial - espessuraFinal)) / diametro );        
        
    }
    
    public void alfaNeutro(){
        
        alfaNeutro = Math.asin(0.5 * Math.sin(alfaInicial) - ( 1 - Math.cos(alfaInicial)) / ( 2 * mu ));        
        //alfaNeutro += 2 / ( n / ( 2 * tau * Math.pow( Math.tan(anguloRestrito) , 2 )));
    }
    
    public double getAgarre(){
        
        return alfaInicial;
    }
    
    public static GeneralPath getColina(){
        
        return colina;
    }
    
    public static GeneralPath getMarcas(){
        
        return marcas;
    }
    
    public void alturaNeutra(){
        
        alturaNeutra = diametro * ( 1 - Math.cos(alfaNeutro) ) + espessuraFinal;
        
    }
    
    public void parametroN(){
        
        n = 2 * tau / espessuraMedia ;
    }
    
    public void espessuraMedia(){
        
        espessuraMedia = ( espessuraInicial + espessuraFinal ) / 2;
    }
    
    public void anguloRestrito(){
        
        if( arcoContato < espessuraMedia )
            anguloRestrito = alfaInicial;
        
        else            
            anguloRestrito = Math.asin( espessuraMedia / ( diametro / 2 ) );            
        
    } 
    
    
}
