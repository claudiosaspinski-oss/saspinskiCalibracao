/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public class CanalOval extends Canal{
    
    public double largura, segundoRaio;             
    
    /** Creates a new instance of CanalOval */
    public CanalOval() {
        
        /*Essa classe herda de Canal, e solicita todas os par�metros
     *necess�rias para definir um canal oval. S�o ent�o
     *calculadas as caracter�sticas do canal assim parametrizado.
     *O m�todo valorDeY(x) � fundamental pois � a fun��o que
     *associa a cada valor de x o y correspondente do canal.
     */
        
        largura = 0;
        profundidade = 0;
        raioFundo = ( Math.pow ( profundidade , 2 ) + Math.pow ( largura , 2 ) / 4 ) / 2 / profundidade;
        //diametro = 2 * raioFundo;
        tipo = CANALOVAL;
    }
    
    public CanalOval( double l , double p ) {
        
        largura = l;
        
        if ( p < l / 2 && p > 0 )
            profundidade = p;
        else
            profundidade = l / 2;
        
        raioFundo = ( Math.pow ( profundidade , 2 ) + Math.pow ( largura , 2 ) / 4 ) / 2 / profundidade;
        //diametro = 2 * raioFundo;
        //anguloSaida = Math.acos(largura/2/raioFundo);
        //segundoRaio = raioFundo;
        tipo = CANALOVAL;
                
    }   
    
    /*public CanalOval( double l , double p, double lF, double segR ) {
        
        largura = l;
        
        if ( p < l / 2 && p > 0 )
            profundidade = p;
        else
            profundidade = l / 2;        
        
        
        raioFundo = ( Math.pow ( profundidade , 2 ) + Math.pow ( largura , 2 ) / 4 ) / 2 / profundidade;
        diametro = 2 * raioFundo;
        anguloSaida = Math.acos(lF/2/raioFundo);
        
        if (segR > raioFundo - ( raioFundo - profundidade ) / Math.sin(anguloSaida) )
            segundoRaio = segR;
        else
            segundoRaio = raioFundo;
        numPontos = 4;
            
        tipo = CANALREDONDO;
                
    }*/
    
}