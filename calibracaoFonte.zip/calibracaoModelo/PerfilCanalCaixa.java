/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

public class PerfilCanalCaixa extends Perfil{
   
    private static double xVar, yVar, luz, raioLuz, xCentroM, xC, yC;
    private double largura, x0, y0, x1, y1;
    private static CanalCaixa canal;
    private Intercessao intercessao;    
    private PerfilCanalCaixaFrisado frisado;
    private PerfilCanalCaixaCheio cheio;
    private PerfilCanalCaixaMagro magro;
    private PerfilCanalCaixaChupado chupado;
   
    /** Creates a new instance of PerfilCanalCaixa */
    public PerfilCanalCaixa( CanalCaixa c , double larg , double luz$ , double raio ) {
        
     /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. Isso � feito na classe Entrada. Depois � calculada a largura do
     *perfil de sa�da na classe Passe.
     *Agora falta construir o perfil de sa�da do passe. Ele � a uni�o do trecho
     *de material em contato com o canal, que segue portanto as equa��es deste,
     *e um raio que liga o ponto de "descolamento" com o canal com o ponto 
     *correspondente � largura m�xima, situado entre os cilindros.
     *Como os canais s�o figuras geom�tricas formadas pela uni�o
     *de segmentos de reta e arcos de c�rculo, � preciso considerar caso a 
     *caso as possibilidades de intercess�o entre o perfil de entrada e a 
     *equa��o de cada trecho de canal para depois calcular o raio e assim
     *definir a equa��o do perfil de sa�da.
     *Nesse caso, verifica-se onde a intercess�o ocorreu, e aciona-se a classe
     *que lida com o trecho respectivo (fundo, raio, parede ou mesa do cilindro).    . 
     */
        
        canal = c;
        largura = larg;
        luz = luz$;
        raioLuz = raio;
        tipo = RESULTANTE;  
        xCentroM = largura / 2 - raioLuz;
        xInicio = largura / 2;
        yInicio = 0;
        xC = canal.pontos()[4];
        yC = canal.pontos()[5] - canal.raioFundo + luz / 2; 
        
        x0y0 = new double [32];
        
        cortaFrisando();   
        if ( xVar < canal.xFimCanal() )
            cortaNaParede();
        if ( xVar < canal.pontos()[6])
            cortaNoRaio();
        if ( xVar < canal.pontos()[4])
            cortaNoFundo();
        
        frisado = new PerfilCanalCaixaFrisado(); 
        cheio = new PerfilCanalCaixaCheio();
        magro = new PerfilCanalCaixaMagro();
        chupado = new PerfilCanalCaixaChupado();
        
    }
              
   
    public double valorDeYPos(double x){
           
        if ( xVar > canal.xFimCanal()){
            return frisado.valorDeYPos(x); }
        else if ( xVar > canal.pontos()[6])
            return cheio.valorDeYPos(x);
        else if ( xVar > canal.pontos()[4])
            return magro.valorDeYPos(x);
        else 
            return chupado.valorDeYPos(x);   
    }
    
    
    public double valorDeYNeg(double x){
               
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeYNeg(x);  
        else if ( xVar > canal.pontos()[6])
            return cheio.valorDeYNeg(x);
        else if ( xVar > canal.pontos()[4])
            return magro.valorDeYNeg(x);
        else 
            return chupado.valorDeYNeg(x); 
      
    }  
    
    public double valorDeR(double teta){
               
        if ( xVar > canal.xFimCanal())
            return frisado.valorDeR(teta);  
        else if ( xVar > canal.pontos()[6])
            return cheio.valorDeR(teta);
        else if ( xVar > canal.pontos()[4])
            return magro.valorDeR(teta);
        else 
            return chupado.valorDeR(teta); 
      
    }      
    
    
    public void cortaFrisando(){
        
        x0 = 0;
        x1 = 1;
        y0 = luz / 2;
        y1 = y0;
            
        intercessao = new Intercessao ( x0 ,y0 ,x1 ,y1 ,xCentroM ,0 ,raioLuz );
        
        if ( intercessao.getXMaior() != 9999 ){
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
        
        else{
            raioLuz = 2 * canal.profundidade + luz;
            xCentroM = largura / 2 - raioLuz;
            intercessao = new Intercessao ( x0 ,y0 ,x1 ,y1 ,xCentroM ,0 ,raioLuz );
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
            
    }
    
    public void cortaNaParede(){
        
        x0 = canal.pontos()[6];
        y0 = canal.pontos()[7] + luz / 2;
        x1 = canal.xFimCanal();
        y1 = canal.yFimCanal() + luz/2; 
        
        intercessao = new Intercessao ( x0, y0, x1, y1, xCentroM, 0, raioLuz );
        
        if ( intercessao.getXMaior() != 9999 ){
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
        
        else{
            
            xVar = canal.pontos()[6] - 0.001;           
        }    
        
    }
    
    public void cortaNoRaio(){
                        
        intercessao = new Intercessao ( xCentroM, 0, xC, yC, raioLuz, canal.raioFundo );
        if (intercessao.getXMenor() != 9999 && ( intercessao.getXMenor() < xVar && intercessao.getXMenor() >= canal.pontos()[4] )
        && intercessao.getYMaior() >= yVar){      
           
            xVar = intercessao.getXMenor();
            yVar = canal.valorDeY(xVar) + luz / 2;
        }
        else{
            xVar = canal.pontos()[4] - 0.001;
          
        }
    }
    
    public void cortaNoFundo(){
        
        x0 = 0;
        y0 = canal.profundidade + luz / 2;
        x1 = 1;
        y1 = y0;
        
        intercessao = new Intercessao( x0, y0, x1, y1, xCentroM, 0, raioLuz );
        
        if (intercessao.getXMaior() > 0 && intercessao.getXMaior() != 9999 ){
        xVar = intercessao.getXMaior();
        yVar = canal.valorDeY(xVar) + luz / 2;
        }
        
        else{
            
            raioLuz = 10000;
            xCentroM = largura / 2 - raioLuz;
            intercessao = new Intercessao( x0, y0, x1, y1, xCentroM, 0, raioLuz );
            xVar = intercessao.getXMaior();
            yVar = canal.valorDeY(xVar) + luz / 2;
           
        }
    }
    
  
    public double getLargura(){
        
        return largura;
        
    }   
    
    public static double getXVar(){
        
        return xVar;
    }
    
    public static double getYVar(){
        
        return yVar;
    }
    
    public static double getLuz(){
        
        return luz;
    }
    
    public static double getRaioLuz(){
        
        return raioLuz;
    }
    
    public static double getXCentroM(){
        
        return xCentroM;
    }
    
    public static double getXC(){
        
        return xC;
    }
    
    public static double getYC(){
        
        return yC;
    }
    
    public static CanalCaixa getCanalCaixa(){
        
        return canal;
    }
}