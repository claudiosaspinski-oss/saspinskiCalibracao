/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoModelo;

import java.awt.geom.*;
import javax.swing.*;

public class RotacaoPerfil {
    
    /*O modelo usa o m�todo dos ret�ngulos equivalentes. Para isso deve ser 
     *calculada a intercess�o entre o perfil de entrada e o canal dos 
     *cilindros. 
     *Para o c�lculo da intercess�o, e tamb�m das �reas, alturas e larguras
     *de entrada e sa�da, � preciso considerar se o perfil gerado num passe
     *anterior, ou que foi definido como se��o inicial de entrada, entra no
     *passe seguinte ap�s alguma rota��o. Por exemplo, um oval normalmente
     *entra "em p�" no passe redondo seguinte, o que significa uma rota��o de
     *90 graus em rela��o ao sentido da deforma��o anterior.
     *Essa classe gira um dado perfil em qualquer �ngulo entre 0 e 90 graus
     *para prepar�-lo para o passe seguinte.        
     */
    
    private Perfil perfil;
    private double teta, err;
    private GeneralPath desenhoPasse;
    private Equacao2Grau equacao;
   
    
    
    /** Creates a new instance of RotacaoPerfil */
    public RotacaoPerfil(Perfil p , double t) {
        
        perfil = p;
        teta = Math.PI/180*t;
        //rPontos();
        figuraPolarPerfil();
        
    }
    
    public void rPontos(){
        
        try{
            
        
        double [] vetor = new double [40];
        
        for ( int j = 0 ; j <= 19 ; j++ )
            vetor [j] = 0;
        
        for ( int i = 0 ; i <= 9 ; i++ ){
            
            vetor [2 * i] = perfil.pontos()[2 * i];
            perfil.pontos()[2 * i] = perfil.pontos()[2 * i + 1];
            perfil.pontos()[2 * i + 1] = -vetor [2 * i];
        }
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em rPontos() ","Erro em RotacaoPerfil.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    public double valorDeR( double alfa ){
        
        return perfil.valorDeR(alfa + teta);
    }   
       
    
    public Perfil getPerfil(){
        
        return perfil;
        
    }
    
    public void figuraPolarPerfil(){
        
        try{           
               
        desenhoPasse = new GeneralPath();             
            
            desenhoPasse.moveTo( (float) (valorDeR(0) * Math.cos(0)) , (float) (valorDeR(0) * Math.sin(0)) );            
            for (double i = 0 ; i <= 2*Math.PI ; i+=0.01 ){
                
                if ( i > 1000000 ){
                err = equacao.getDeterminante();
                break;                
            }                
            
            desenhoPasse.lineTo( (float) (valorDeR(i) * Math.cos(i)) , (float) (valorDeR(i) * Math.sin(i)) );
            
            }
            
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em figuraPolarPerfil() ","Erro em RotacaoPerfil.java",JOptionPane.ERROR_MESSAGE);
            
        }     
                  
    } 
    
    public GeneralPath getDesenhoPasse(){
        
         return desenhoPasse;
    }
    
    public double getLargura(){
        
        return 2 * valorDeR( 0 );
    }
    
    public double getAltura(){
        
        return 2 * valorDeR(Math.PI / 2);
    }
    
   
   
}