/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoVisual;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import calibracaoControle.*;
import calibracaoModelo.*;

public class DadosSaida extends JFrame{
    
    /*Essa classe � uma janela mostrando os resultados dos 
     *c�lculos. Tamb�m manda abrir um painel gr�fico mostrando a forma
     *do canal e do material laminado.
     */
    
    Container container;
    JPanel janelaSaida;
    JanelaGrafica janelaGrafica;
    DecimalFormat zeroDigito, umDigito, doisDigitos;
    JLabel larguraPasseLabel, espessuraPasseLabel, luzPasseLabel, areaPasseLabel,
            raioLuzPasseLabel, redAreaPasseLabel, alongamentoPasseLabel,
            agarrePasseLabel, diametroCilindroPasseLabel, diamTrabalhoPasseLabel,
            fatorCanalPasseLabel, temperaturaPasseLabel,  producaoHorariaLabel,
            rotacaoCilindroLabel, velocidadeLabel, forcaLabel, potenciaLabel,
            torqueLabel;
    JTextField larguraPasseField, espessuraPasseField, luzPasseField, areaPasseField,
            raioLuzPasseField, redAreaPasseField, alongamentoPasseField,
            agarrePasseField, diametroCilindroPasseField, diamTrabalhoPasseField,
            fatorCanalPasseField, temperaturaPasseField,  producaoHorariaPasseField,
            rotacaoCilindroPasseField, velocidadeField, forcaField, potenciaField,
            torqueField;
            
    
    /** Creates a new instance of DadosSaida */
    public DadosSaida() {
        
        super ( " Resultados do passe 1 "); 
        
        try{      
        
        container = getContentPane();
        BorderLayout layout = new BorderLayout();
        container.setLayout ( layout );  
        janelaSaida = new JPanel();
        janelaGrafica = new JanelaGrafica();        
        
        janelaSaida.setLayout ( new GridLayout( 18 , 2 ));  
        
        zeroDigito = new DecimalFormat ("0");
        umDigito = new DecimalFormat ("0.0");        
        doisDigitos = new DecimalFormat ("0.00");
        
        larguraPasseSaida();
        espessuraPasseSaida();
        luzPasseSaida();
        areaPasseSaida();
        raioLuzPasseSaida();
        redAreaPasseSaida();
        alongamentoPasseSaida();
        agarrePasseSaida();
        diametroCilindroPasseSaida();
        diamTrabalhoPasseSaida();
        fatorCanalPasseSaida();
        temperaturaPasseSaida();
        producaoHorariaPasseSaida();
        rotacaoCilindroPasseSaida();
        velocidadePasseSaida();
        forcaPasseSaida();
        torquePasseSaida();
        potenciaPasseSaida();            
        
        container.add(janelaGrafica, BorderLayout.CENTER);
        container.add(janelaSaida, BorderLayout.EAST);       
        
        setSize (800, 600 );
        setVisible (true);        
        
        }
        
        catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(this," Erro em DadosSaida() ","Erro em DadosSaida.java",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void larguraPasseSaida(){
        
        larguraPasseLabel = new JLabel( " Largura (mm) ");
        janelaSaida.add (larguraPasseLabel);
        larguraPasseField = new JTextField();
        larguraPasseField.setText( umDigito.format(TratadorDadosFisicosPasse.getPasse().getAlargamento()) );
        larguraPasseField.setEditable(false);
        janelaSaida.add (larguraPasseField); 
        
    }
    
    public void espessuraPasseSaida(){
        
        espessuraPasseLabel = new JLabel( " Espessura (mm) ");
        janelaSaida.add (espessuraPasseLabel);
        espessuraPasseField = new JTextField();
        espessuraPasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getPasse().getPerfilSaida().getAltura()));
        espessuraPasseField.setEditable(false);
        janelaSaida.add (espessuraPasseField);
        
    }
    
    public void luzPasseSaida(){
        
        luzPasseLabel = new JLabel( " Luz (mm) ");
        janelaSaida.add (luzPasseLabel);
        luzPasseField = new JTextField();
        luzPasseField.setEditable(false);
        luzPasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getLuz()));        
        janelaSaida.add (luzPasseField);  
        
    }
    
    public void areaPasseSaida(){
        
        areaPasseLabel = new JLabel( " �rea (mm) ");
        janelaSaida.add (areaPasseLabel);
        areaPasseField = new JTextField();
        areaPasseField.setText( zeroDigito.format(TratadorDadosFisicosPasse.getPasse().getArea()));
        areaPasseField.setEditable(false);
        janelaSaida.add (areaPasseField);
        
    }
    
    public void raioLuzPasseSaida(){
        
        raioLuzPasseLabel = new JLabel( " Raio na luz (mm) ");
        janelaSaida.add (raioLuzPasseLabel);
        raioLuzPasseField = new JTextField();
        raioLuzPasseField.setText( zeroDigito.format(TratadorDadosFisicosPasse.getPasse().raioNaLuz()));
        raioLuzPasseField.setEditable(false);
        janelaSaida.add (raioLuzPasseField);
        
    }
    
    public void redAreaPasseSaida(){
        
        redAreaPasseLabel = new JLabel( " Redu��o de �rea (%) ");
        janelaSaida.add (redAreaPasseLabel);
        redAreaPasseField = new JTextField();
        redAreaPasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getPasse().reducaoDeArea()));
        redAreaPasseField.setEditable(false);
        janelaSaida.add (redAreaPasseField);       
        
        
    }
    
    public void alongamentoPasseSaida(){
        
        alongamentoPasseLabel = new JLabel( " Alongamento ");
        janelaSaida.add (alongamentoPasseLabel);
        alongamentoPasseField = new JTextField();
        alongamentoPasseField.setText(doisDigitos.format(TratadorDadosFisicosPasse.getPasse().alongamento()));
        alongamentoPasseField.setEditable(false);
        janelaSaida.add (alongamentoPasseField);
        
    }
    
    public void agarrePasseSaida(){
        
        agarrePasseLabel = new JLabel( " �ngulo de agarre (graus) ");
        janelaSaida.add (agarrePasseLabel);
        agarrePasseField = new JTextField();
        agarrePasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getEntrada().agarre()*180/Math.PI));
        agarrePasseField.setEditable(false);
        janelaSaida.add (agarrePasseField);   
        
    }
    
    public void diametroCilindroPasseSaida(){
        
        diametroCilindroPasseLabel = new JLabel (" Di�metro do cilindro ");
        janelaSaida.add (diametroCilindroPasseLabel);
        diametroCilindroPasseField = new JTextField();        
        diametroCilindroPasseField.setEditable(false);
        diametroCilindroPasseField.setText ( umDigito.format(TratadorDadosFisicosPasse.getMaterial().getDiametroCilindro()) );
        janelaSaida.add (diametroCilindroPasseField);   
        
    }
    
    public void diamTrabalhoPasseSaida(){
        
        diamTrabalhoPasseLabel = new JLabel( " Di�metro de trabalho (mm)");
        janelaSaida.add (diamTrabalhoPasseLabel);
        diamTrabalhoPasseField = new JTextField();
        diamTrabalhoPasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getEntrada().diametroDeTrabalho()));
        diamTrabalhoPasseField.setEditable(false);
        janelaSaida.add (diamTrabalhoPasseField);        
        
    }
    
    public void fatorCanalPasseSaida(){
        
        fatorCanalPasseLabel = new JLabel( " Fator de canal (mm)");
        janelaSaida.add (fatorCanalPasseLabel);
        fatorCanalPasseField = new JTextField();
        fatorCanalPasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getEntrada().fatorDeCanal()));
        fatorCanalPasseField.setEditable(false);
        janelaSaida.add (fatorCanalPasseField);
        
    }
    
    public void temperaturaPasseSaida(){
        
        temperaturaPasseLabel = new JLabel(" Temperatura do passe (C) ");
        janelaSaida.add (temperaturaPasseLabel);
        temperaturaPasseField = new JTextField();
        temperaturaPasseField.setEditable(false);
        temperaturaPasseField.setText(zeroDigito.format(TratadorDadosFisicosPasse.getMaterial().getTemperatura()));        
        janelaSaida.add (temperaturaPasseField);      
        
    }
    
    public void producaoHorariaPasseSaida(){
        
        producaoHorariaLabel = new JLabel( " Produ��o hor�ria (t/h) ");
        janelaSaida.add (producaoHorariaLabel);
        producaoHorariaPasseField = new JTextField();
        producaoHorariaPasseField.setText(umDigito.format(TratadorDadosFisicosPasse.getPasse().producaoHoraria()));
        producaoHorariaPasseField.setEditable(false);
        janelaSaida.add (producaoHorariaPasseField);   
        
    }
    
    public void rotacaoCilindroPasseSaida(){
        
        rotacaoCilindroLabel = new JLabel( " Rota��o (RPM) ");
        janelaSaida.add (rotacaoCilindroLabel);
        rotacaoCilindroPasseField = new JTextField();
        rotacaoCilindroPasseField.setText(zeroDigito.format(TratadorDadosFisicosPasse.getPasse().rotacao()));
        rotacaoCilindroPasseField.setEditable(false);
        janelaSaida.add (rotacaoCilindroPasseField); 
        
    }
    
    public void velocidadePasseSaida(){
        
        velocidadeLabel = new JLabel( " Velocidade (m/s) ");
        janelaSaida.add (velocidadeLabel);
        velocidadeField = new JTextField();
        velocidadeField.setText(doisDigitos.format(TratadorDadosFisicosPasse.getPasse().velocidade()));
        velocidadeField.setEditable(false);
        janelaSaida.add (velocidadeField);  
        
    } 
    
    public void forcaPasseSaida(){
        
        forcaLabel = new JLabel( " For�a de lamina��o (Kgf) ");
        janelaSaida.add (forcaLabel);
        forcaField = new JTextField();
        forcaField.setText(zeroDigito.format(TratadorDadosFisicosPasse.getEsforcos().forca()));
        forcaField.setEditable(false);
        janelaSaida.add (forcaField);  
        
    }
    
    public void torquePasseSaida(){
        
        torqueLabel = new JLabel( " Torque (Kgf.m) ");
        janelaSaida.add (torqueLabel);
        torqueField = new JTextField();
        torqueField.setText(zeroDigito.format(TratadorDadosFisicosPasse.getEsforcos().torque()));
        torqueField.setEditable(false);
        janelaSaida.add (torqueField);
        
    }
    
    public void potenciaPasseSaida(){
        
        potenciaLabel = new JLabel( " Pot�ncia (Kw) ");
        janelaSaida.add (potenciaLabel);
        potenciaField = new JTextField();
        potenciaField.setText(zeroDigito.format(TratadorDadosFisicosPasse.getEsforcos().potencia()));
        potenciaField.setEditable(false);
        janelaSaida.add (potenciaField);   
        
    }  
    
}