/*Copyright 2007 Jose C. Bandeira R. Cardoso

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package calibracaoVisual;

import javax.swing.*;
import java.awt.*;
import calibracaoControle.*;
import calibracaoModelo.*;

public class JanelaGrafica extends JPanel{
    
    /* Essa classe � um painel gr�fico mostrando o canal
     *e o material laminado.
     */
    
    /** Creates a new instance of JanelaGrafica */
    public JanelaGrafica() {
    }
    
     public void paintComponent (Graphics g){
         
         try{    
            
        super.paintComponent ( g );  
        
        Graphics2D g2d = ( Graphics2D ) g; 
        double size1 = Math.max(TratadorDadosFisicosPasse.getRotacao().getAltura() , TratadorDadosFisicosPasse.getPasse().getPerfilSaida().getAltura());
        double size2 = Math.max (Math.abs( TratadorDadosFisicosPasse.getCanal().xFimCanal() - TratadorDadosFisicosPasse.getCanal().xInicioCanal() ), TratadorDadosFisicosPasse.getPasse().getAlargamento() );
        double size3 = Math.max( size1 , size2 );
        int escala = (int) ( 400.0 / size3 ); 
        g2d.translate ( 250 , 250 ); 
        g2d.scale( escala , escala );       
        g2d.setColor(Color.ORANGE); 
        float linha = (float) (1.0 / 100);
        g2d.setStroke(new BasicStroke(linha));
        g2d.draw (TratadorDadosFisicosPasse.getRotacao().getDesenhoPasse());
        g2d.setColor(Color.RED);
        g2d.draw (TratadorDadosFisicosPasse.getPasse().getPerfilSaida().figuraPolarPerfil());
        g2d.draw (TratadorDadosFisicosPasse.getPasse().raioVertice());
        g2d.setColor(Color.BLACK);
        g2d.translate(0,TratadorDadosFisicosPasse.getLuz()/2);                
        g2d.draw (TratadorDadosFisicosPasse.getCanal().figura());        
        g2d.rotate(Math.PI,0, -TratadorDadosFisicosPasse.getLuz()/2 );
        g2d.draw (TratadorDadosFisicosPasse.getCanal().figura());
        
         }
         
         catch ( Exception exception ){
            
            JOptionPane.showMessageDialog(null," Erro em paintComponent() ","Erro em JanelaGrafica.java",JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
    
    
}